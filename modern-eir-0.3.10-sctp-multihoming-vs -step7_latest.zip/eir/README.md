# Modern EIR — RestComm jSS7 + JDK SCTP / Windows TCP Test Mode

This version removes the external SCTP transport library from the EIR application and from
the patched M3UA transport boundary.

## Architecture

```text
EIR application
      |
     MAP
      |
    TCAP
      |
    SCCP
      |
    M3UA
      |
RestComm Java-SCTP transport adapter
      |
JDK com.sun.nio.sctp
      |
   SCTP/IP
      |
MSC / VLR / HLR
```

The SS7 protocol layers remain RestComm jSS7 8.0.0-179. The local patched M3UA API/implementation
uses the transport-neutral `org.restcomm.protocols.ss7.transport` boundary instead of the historical
external SCTP API.

## What changed

- Removed direct SCTP API/implementation dependencies from the EIR project.
- Removed `ManagementImpl`, `Association`, `AssociationListener`, `PayloadData` and
  `IpChannelType` imports from the EIR application.
- Added a Java 17 SCTP implementation using `com.sun.nio.sctp.SctpChannel` and
  `com.sun.nio.sctp.SctpServerChannel`.
- Patched RestComm jSS7 M3UA API/implementation to consume the new transport boundary.
- M3UA now receives and sends SCTP payloads through Netty `ByteBuf` objects supplied by
  the local Java-SCTP adapter.
- Removed the old M3UA SCTP OAM shell implementation from this standalone build because
  it was coupled to the removed transport API.
- Configuration supports SCTP and Windows TCP test mode; the command line selects the transport.

## Build

Requirements:

- JDK 17 or newer.
- Maven 3.8+.
- SCTP mode requires an operating system with SCTP support. TCP mode does not.

Build the complete reactor:

```bash
mvn clean verify

The Java-SCTP module is compiled with `--add-modules jdk.sctp`.
```

Run the EIR (SCTP):

```bat
mvn exec:java -Dexec.mainClass=com.example.eir.EirServerMain -Dexec.args="sctp"
```

For Windows testing, use TCP instead:

```bat
mvn exec:java -Dexec.mainClass=com.example.eir.EirServerMain -Dexec.args="tcp"
```

Run the MSC simulator in another terminal with the same transport selection.

The simulator sends three CheckIMEI requests after the SCTP association and M3UA
application server become active.

## Important dependency note

The EIR project has no dependency on `org.mobicents.protocols.sctp:sctp-api` or
`org.mobicents.protocols.sctp:sctp-impl`, and the patched M3UA source contains no imports
from those packages.

RestComm jSS7 8.0.0-179 itself historically uses a few legacy `org.mobicents.*` components
such as ASN/utility artifacts. Those are separate from the SCTP transport and are not used
as the SCTP implementation in this project.

## Windows TCP test topology

```text
MSC simulator                         EIR
127.0.0.1:2905                       127.0.0.1:2906
      |                                    |
      +-------- TCP test connection -------+
```

The TCP framing is private to this project and is only for local EIR/MSC simulator testing.
For real SIGTRAN interoperability, use SCTP mode on an SCTP-capable operating system.

## SCTP topology

```text
MSC simulator                         EIR
127.0.0.1:2905                       127.0.0.1:2906
      |                                    |
      +---------- SCTP association --------+
```

For a real deployment, replace the XML IP addresses and ports with the actual MSC/EIR
endpoints and ensure the network permits SCTP.


## 0.3.2 build layout

This release intentionally builds the patched RestComm M3UA API/implementation and the JDK SCTP transport as source directories from `../vendor`. The EIR can therefore be compiled directly from this directory without installing `restcomm-java-sctp` or a private `8.0.0-179-eir1` artifact.

Run:

```text
mvn clean compile -U
```

The SCTP implementation uses the JDK `jdk.sctp` module (`com.sun.nio.sctp`). No `org.mobicents.protocols.sctp` dependency is used.

## Multi-association EIR

The EIR transport is now configured from `config/initial/EIR/EIR-associations.xml`. Each
`<association>` creates one RestComm transport association and one M3UA ASP. Multiple
associations can be active in the same EIR process.

Example topology:

```text
                         EIR
                          |
                    RestComm jSS7
                          |
             +------------+------------+
             |                         |
          MSC01                       MSC02
       ASSOC/DPC 1                 ASSOC/DPC 2
       TCP/SCTP :2906              TCP/SCTP :2907
```

Use `mode="server"` when the MSC initiates the transport connection to the EIR, or
`mode="client"` when the EIR actively connects to the MSC. Both modes may be used
simultaneously in one EIR process.

For multiple associations to the same MSC, use separate association names and transport
endpoints. If the associations are redundant paths for the same MSC, give them the same
`asName` so they become multiple ASPs of one M3UA AS. If they represent different MSC
point codes, normally give them different `asName` values and `routeDpc` values so M3UA
routes each destination point code to its corresponding AS.

For Windows testing, each server-mode association should normally use a distinct local
TCP port. For production SIGTRAN use `sctp`; TCP is only the local integration-test
transport.


## SCTP multihoming (0.3.10)

SCTP mode now supports one logical association with multiple local IP addresses. See `SCTP-MULTIHOMING.md`. The remote alternate address is validated against the addresses advertised by the SCTP peer; no second M3UA association is created.
