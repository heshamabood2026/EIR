# Phase 1B Quick Reference

## Start the Server

```bash
cd eir/
export EIR_MANAGEMENT_ENABLED=true
export EIR_MANAGEMENT_PORT=8080
mvn exec:java -Dexec.mainClass="com.example.eir.EirServerMain"
```

## Quick Test Examples

### 1. Health Check (No Auth)
```bash
curl http://localhost:8080/api/metrics/health
```

### 2. Admin Login
```bash
TOKEN=$(curl -s -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}' \
  | jq -r '.token')

echo "Token: $TOKEN"
```

### 3. Get Equipment Metrics
```bash
curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:8080/api/metrics/equipment
```

### 4. Get Audit Logs
```bash
curl -H "Authorization: Bearer $TOKEN" \
  'http://localhost:8080/api/audit/logs?limit=10'
```

### 5. Logout
```bash
curl -X POST -H "Authorization: Bearer $TOKEN" \
  http://localhost:8080/api/auth/logout
```

## Demo Users

| Username | Password | Role |
|----------|----------|------|
| admin | admin123 | ADMIN (full access) |
| viewer | viewer123 | VIEWER (read-only) |

## All Endpoints (10 Total)

### Authentication
- `POST /api/auth/login` - Login with credentials
- `POST /api/auth/refresh` - Refresh JWT token
- `POST /api/auth/logout` - Logout and revoke token

### Metrics
- `GET /api/metrics/health` - Health check (no auth)
- `GET /api/metrics/equipment` - Equipment metrics
- `GET /api/metrics/database` - Database metrics
- `GET /api/metrics/pool` - Connection pool status

### Audit
- `GET /api/audit/logs` - Query audit logs with pagination
- `GET /api/audit/logs/{imei}` - Query logs by IMEI
- `GET /api/audit/metrics` - Audit statistics

## Environment Variables (Optional)

```bash
EIR_MANAGEMENT_ENABLED=true         # Default: true
EIR_MANAGEMENT_HOST=127.0.0.1       # Default: 127.0.0.1
EIR_MANAGEMENT_PORT=8080            # Default: 8080
EIR_JWT_SECRET=your-secret-key      # Default: "change-me-in-production"
EIR_JWT_EXPIRY_MINUTES=60           # Default: 60
EIR_IMEI_MASK_MODE=partial          # Default: partial (options: none, partial, full)
EIR_AUDIT_ENABLED=true              # Default: true
```

## Response Examples

### Login Response
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "expiresIn": 3600,
  "role": "ADMIN"
}
```

### Metrics Response
```json
{
  "totalRequests": 1250,
  "whitelisted": 1150,
  "blacklisted": 50,
  "greylisted": 45,
  "unknown": 5,
  "databaseErrors": 0,
  "avgLatencyMs": "2.50",
  "poolSaturation%": "50.0"
}
```

### Audit Log Response
```json
{
  "logs": [
    {
      "timestamp": "2024-01-01T12:00:00Z",
      "imei": "***334444",
      "status": "WHITELISTED",
      "reason": "Verified device",
      "source": "memory",
      "userId": "admin",
      "requestId": "req-123"
    }
  ],
  "total": 1250,
  "limit": 10,
  "offset": 0
}
```

## HTTP Status Codes

| Code | Meaning |
|------|---------|
| 200 | Success |
| 201 | Created |
| 400 | Bad Request |
| 401 | Unauthorized |
| 403 | Forbidden |
| 405 | Method Not Allowed |
| 500 | Server Error |

## Troubleshooting

### 401 Unauthorized
- Check if token is included in Authorization header
- Verify token is not expired
- Try login again to get a new token

### 403 Forbidden
- Check if your role has permission for this endpoint
- VIEWER role only has read access
- ADMIN role has full access

### 500 Server Error
- Check server logs for details
- Verify all required parameters are provided
- Check request JSON format

## Files

### Source Code
- `EirManagementServer.java` - Main server
- `AuthenticationHandler.java` - Auth endpoints
- `MetricsHandler.java` - Metrics endpoints
- `AuditHandler.java` - Audit endpoints
- `HttpRequest.java` - Request parsing
- `HttpResponse.java` - Response building

### Tests
- `test-rest-api.sh` - Linux/macOS tests
- `test-rest-api.ps1` - Windows tests

### Documentation
- `STEP7_PHASE1B_IMPLEMENTATION.md` - Full API reference
- `STEP7_PHASE1B_SUMMARY.md` - Implementation summary

## Build

```bash
# Compile
mvn clean compile

# Build JAR
mvn clean package -DskipTests

# Run tests
mvn test
```

## Next Phase

Phase 2 will add:
- Equipment CRUD endpoints
- Bulk import from CSV
- User management endpoints
- Real integration with CheckIMEI flow
