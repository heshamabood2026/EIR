#!/bin/bash

# Phase 1B REST API Test Script
# Tests all authentication, metrics, and audit endpoints

BASE_URL="http://localhost:8080/api"
ADMIN_USER="admin"
ADMIN_PASS="admin123"
VIEWER_USER="viewer"
VIEWER_PASS="viewer123"

echo "========================================="
echo "Phase 1B: REST API Endpoint Tests"
echo "========================================="
echo ""

# Test 1: Health Check (no auth required)
echo "Test 1: GET /api/metrics/health (no auth)"
curl -s -X GET "$BASE_URL/metrics/health" -H "Content-Type: application/json" | jq '.' || echo "Failed"
echo ""

# Test 2: Admin Login
echo "Test 2: POST /api/auth/login (admin)"
LOGIN_RESPONSE=$(curl -s -X POST "$BASE_URL/auth/login" \
  -H "Content-Type: application/json" \
  -d "{\"username\":\"$ADMIN_USER\",\"password\":\"$ADMIN_PASS\"}")
echo "$LOGIN_RESPONSE" | jq '.'
ADMIN_TOKEN=$(echo "$LOGIN_RESPONSE" | jq -r '.token')
echo "Admin Token: $ADMIN_TOKEN"
echo ""

# Test 3: Viewer Login
echo "Test 3: POST /api/auth/login (viewer)"
LOGIN_RESPONSE=$(curl -s -X POST "$BASE_URL/auth/login" \
  -H "Content-Type: application/json" \
  -d "{\"username\":\"$VIEWER_USER\",\"password\":\"$VIEWER_PASS\"}")
echo "$LOGIN_RESPONSE" | jq '.'
VIEWER_TOKEN=$(echo "$LOGIN_RESPONSE" | jq -r '.token')
echo "Viewer Token: $VIEWER_TOKEN"
echo ""

# Test 4: Invalid Login
echo "Test 4: POST /api/auth/login (invalid credentials)"
curl -s -X POST "$BASE_URL/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"username":"invalid","password":"wrong"}' | jq '.'
echo ""

# Test 5: Equipment Metrics (requires auth)
echo "Test 5: GET /api/metrics/equipment (with admin token)"
curl -s -X GET "$BASE_URL/metrics/equipment" \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H "Content-Type: application/json" | jq '.'
echo ""

# Test 6: Equipment Metrics without token
echo "Test 6: GET /api/metrics/equipment (no token - should fail)"
curl -s -X GET "$BASE_URL/metrics/equipment" \
  -H "Content-Type: application/json" | jq '.'
echo ""

# Test 7: Database Metrics
echo "Test 7: GET /api/metrics/database (with viewer token)"
curl -s -X GET "$BASE_URL/metrics/database" \
  -H "Authorization: Bearer $VIEWER_TOKEN" \
  -H "Content-Type: application/json" | jq '.'
echo ""

# Test 8: Pool Metrics
echo "Test 8: GET /api/metrics/pool (with admin token)"
curl -s -X GET "$BASE_URL/metrics/pool" \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H "Content-Type: application/json" | jq '.'
echo ""

# Test 9: Audit Logs Query
echo "Test 9: GET /api/audit/logs (with viewer token)"
curl -s -X GET "$BASE_URL/audit/logs?limit=10" \
  -H "Authorization: Bearer $VIEWER_TOKEN" \
  -H "Content-Type: application/json" | jq '.'
echo ""

# Test 10: Audit Metrics
echo "Test 10: GET /api/audit/metrics (with admin token)"
curl -s -X GET "$BASE_URL/audit/metrics" \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H "Content-Type: application/json" | jq '.'
echo ""

# Test 11: Token Refresh
echo "Test 11: POST /api/auth/refresh (with valid token)"
curl -s -X POST "$BASE_URL/auth/refresh" \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H "Content-Type: application/json" | jq '.'
echo ""

# Test 12: Logout
echo "Test 12: POST /api/auth/logout (with valid token)"
curl -s -X POST "$BASE_URL/auth/logout" \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H "Content-Type: application/json" | jq '.'
echo ""

# Test 13: Invalid Token
echo "Test 13: GET /api/metrics/equipment (with invalid token)"
curl -s -X GET "$BASE_URL/metrics/equipment" \
  -H "Authorization: Bearer invalid_token_123" \
  -H "Content-Type: application/json" | jq '.'
echo ""

echo "========================================="
echo "Tests Complete"
echo "========================================="
