package com.example.eir.auth;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for JWT token generation, validation, and revocation.
 */
class JwtTokenProviderTest {
    
    private JwtTokenProvider provider;
    private User testUser;
    
    @BeforeEach
    void setUp() {
        provider = new JwtTokenProvider("test-secret-key-32-chars-minimum", 60);
        testUser = User.create("testuser", "hashedpassword", Role.USER);
    }
    
    @Test
    void testGenerateToken() {
        String token = provider.generateToken(testUser);
        
        assertNotNull(token);
        assertTrue(token.contains("."));
        String[] parts = token.split("\\.");
        assertEquals(2, parts.length);
    }
    
    @Test
    void testValidateToken_Valid() {
        String token = provider.generateToken(testUser);
        String username = provider.validateToken(token);
        
        assertEquals("testuser", username);
    }
    
    @Test
    void testValidateToken_Invalid() {
        String username = provider.validateToken("invalid.token");
        assertNull(username);
    }
    
    @Test
    void testExtractRole() {
        String token = provider.generateToken(testUser);
        Role role = provider.extractRole(token);
        
        assertEquals(Role.USER, role);
    }
    
    @Test
    void testRevokeToken() {
        String token = provider.generateToken(testUser);
        assertNotNull(provider.validateToken(token));
        
        provider.revokeToken(token);
        assertNull(provider.validateToken(token));
    }
}
