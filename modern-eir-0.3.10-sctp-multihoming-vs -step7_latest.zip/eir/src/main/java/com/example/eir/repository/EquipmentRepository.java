package com.example.eir.repository;

import com.example.eir.domain.Equipment;

/**
 * Persistence boundary for equipment identities.
 */
public interface EquipmentRepository {

    /**
     * Returns the stored equipment, or null when no identity exists.
     */
    Equipment findByImei(String imei);

    /**
     * Compatibility helper retained for existing callers.
     */
    default boolean isAllowed(String imei) {
        Equipment equipment = findByImei(imei);
        return equipment != null && equipment.status() ==
                com.example.eir.domain.EirEquipmentStatus.WHITELISTED;
    }
}
