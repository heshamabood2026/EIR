package com.example.eir.auth;

import java.util.Optional;

/**
 * Repository interface for user authentication and management.
 * 
 * Implementations can be in-memory or database-backed.
 */
public interface UserRepository {
    
    /**
     * Save or update a user.
     */
    void save(User user);
    
    /**
     * Find user by username.
     */
    Optional<User> findByUsername(String username);
    
    /**
     * Check if user exists.
     */
    boolean existsByUsername(String username);
    
    /**
     * Authenticate user with password.
     * Returns user if credentials valid, empty otherwise.
     */
    Optional<User> authenticate(String username, String password);
}
