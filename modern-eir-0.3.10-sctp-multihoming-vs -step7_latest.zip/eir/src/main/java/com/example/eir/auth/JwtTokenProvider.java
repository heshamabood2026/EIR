package com.example.eir.auth;

import java.util.*;
import java.time.Instant;
import java.time.temporal.ChronoUnit;

/**
 * JWT Token generation and validation for equipment management API.
 * 
 * Generates signed tokens containing username and role.
 * Validates token signature, expiry, and structure.
 * 
 * IMPORTANT: This is a simplified JWT implementation for demonstration.
 * Production should use a proper JWT library (e.g., jsonwebtoken, jose4j).
 */
public final class JwtTokenProvider {
    
    private final String secret;
    private final int expiryMinutes;
    private final Set<String> blacklistedTokens;
    
    public JwtTokenProvider(String secret, int expiryMinutes) {
        this.secret = Objects.requireNonNull(secret, "secret");
        if (expiryMinutes <= 0) {
            throw new IllegalArgumentException("expiryMinutes must be > 0");
        }
        this.expiryMinutes = expiryMinutes;
        this.blacklistedTokens = Collections.synchronizedSet(new HashSet<>());
    }
    
    /**
     * Generate JWT token for authenticated user.
     * 
     * Token format (simplified): "header.payload.signature"
     * Payload contains: username, role, issuedAt, expiresAt
     * 
     * @return JWT token string
     */
    public String generateToken(User user) {
        long now = System.currentTimeMillis();
        long expiryTime = now + (expiryMinutes * 60000L);
        
        // Simplified token payload (in production, use Base64)
        String payload = String.format(
                "{\"username\":\"%s\",\"role\":\"%s\",\"iat\":%d,\"exp\":%d}",
                user.getUsername(),
                user.getRole().name(),
                now,
                expiryTime
        );
        
        // Simplified signature (in production, use HMAC-SHA256)
        String signature = generateSignature(payload);
        
        // Return token
        return Base64.getEncoder().encodeToString(payload.getBytes()) 
                + "." + signature;
    }
    
    /**
     * Validate JWT token and extract username.
     * 
     * Checks:
     * - Token format is valid
     * - Signature is correct
     * - Token is not expired
     * - Token is not blacklisted
     * 
     * @return username if valid, null if invalid
     */
    public String validateToken(String token) {
        if (token == null || token.isBlank()) {
            return null;
        }
        
        // Check blacklist
        if (blacklistedTokens.contains(token)) {
            return null;
        }
        
        try {
            String[] parts = token.split("\\.");
            if (parts.length != 2) {
                return null;
            }
            
            // Verify signature
            String expectedSignature = generateSignature(parts[0]);
            if (!expectedSignature.equals(parts[1])) {
                return null;
            }
            
            // Parse payload
            String payload = new String(Base64.getDecoder().decode(parts[0]));
            
            // Extract username (simplified parsing)
            if (!payload.contains("username")) {
                return null;
            }
            
            // Extract expiry and check
            if (payload.contains("\"exp\":")) {
                long expiry = Long.parseLong(
                        payload.substring(payload.indexOf("\"exp\":") + 6)
                        .split(",")[0]
                );
                if (System.currentTimeMillis() > expiry) {
                    return null; // Expired
                }
            }
            
            // Extract and return username
            int usernameStart = payload.indexOf("\"username\":\"") + 12;
            int usernameEnd = payload.indexOf("\"", usernameStart);
            return payload.substring(usernameStart, usernameEnd);
            
        } catch (Exception e) {
            return null; // Invalid token
        }
    }
    
    /**
     * Extract role from token.
     */
    public Role extractRole(String token) {
        try {
            String payload = new String(
                    Base64.getDecoder().decode(token.split("\\.")[0]));
            int roleStart = payload.indexOf("\"role\":\"") + 8;
            int roleEnd = payload.indexOf("\"", roleStart);
            String roleName = payload.substring(roleStart, roleEnd);
            return Role.valueOf(roleName);
        } catch (Exception e) {
            return null;
        }
    }
    
    /**
     * Revoke token by adding to blacklist (logout).
     */
    public void revokeToken(String token) {
        blacklistedTokens.add(token);
    }
    
    /**
     * Generate signature for token (simplified HMAC).
     */
    private String generateSignature(String payload) {
        try {
            javax.crypto.Mac mac = javax.crypto.Mac.getInstance("HmacSHA256");
            javax.crypto.spec.SecretKeySpec keySpec = 
                    new javax.crypto.spec.SecretKeySpec(
                            secret.getBytes(), 0, secret.getBytes().length, "HmacSHA256");
            mac.init(keySpec);
            byte[] result = mac.doFinal(payload.getBytes());
            return Base64.getEncoder().encodeToString(result);
        } catch (Exception e) {
            throw new RuntimeException("Token signing failed", e);
        }
    }
}
