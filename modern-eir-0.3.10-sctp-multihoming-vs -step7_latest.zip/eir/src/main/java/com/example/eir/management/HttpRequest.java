package com.example.eir.management;

import java.util.*;
import com.sun.net.httpserver.HttpExchange;

/**
 * Wrapper for HTTP request parsing and extraction.
 * Provides convenient methods to get body, query params, and headers.
 */
public final class HttpRequest {
    
    private final HttpExchange exchange;
    private String cachedBody;
    
    public HttpRequest(HttpExchange exchange) {
        this.exchange = exchange;
    }
    
    /**
     * Get request body as string.
     */
    public String getBody() {
        if (cachedBody != null) {
            return cachedBody;
        }
        
        try {
            byte[] bytes = new byte[exchange.getRequestBody().available()];
            if (bytes.length == 0) {
                bytes = new byte[1024];
                exchange.getRequestBody().read(bytes);
            } else {
                exchange.getRequestBody().read(bytes);
            }
            cachedBody = new String(bytes).trim();
            return cachedBody;
        } catch (Exception e) {
            return "";
        }
    }
    
    /**
     * Get query parameter value.
     */
    public String getQueryParam(String name) {
        String query = exchange.getRequestURI().getQuery();
        if (query == null || query.isBlank()) {
            return null;
        }
        
        for (String param : query.split("&")) {
            String[] parts = param.split("=");
            if (parts.length == 2 && parts[0].equals(name)) {
                try {
                    return java.net.URLDecoder.decode(parts[1], "UTF-8");
                } catch (Exception e) {
                    return null;
                }
            }
        }
        return null;
    }
    
    /**
     * Get header value.
     */
    public String getHeader(String name) {
        return exchange.getRequestHeaders().getFirst(name);
    }
    
    /**
     * Get Authorization Bearer token.
     */
    public String getAuthToken() {
        String auth = getHeader("Authorization");
        if (auth != null && auth.startsWith("Bearer ")) {
            return auth.substring(7);
        }
        return null;
    }
    
    /**
     * Get request path (without query string).
     */
    public String getPath() {
        String path = exchange.getRequestURI().getPath();
        return path.isEmpty() ? "/" : path;
    }
    
    /**
     * Get request method.
     */
    public String getMethod() {
        return exchange.getRequestMethod();
    }
}
