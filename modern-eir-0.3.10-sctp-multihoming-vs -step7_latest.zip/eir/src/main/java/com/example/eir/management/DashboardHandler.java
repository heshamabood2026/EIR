package com.example.eir.management;

import org.apache.log4j.Logger;
import com.sun.net.httpserver.HttpExchange;

/**
 * HTTP handler for serving the Management Dashboard HTML.
 * Serves the web UI for accessing the management API.
 */
public final class DashboardHandler {
    private static final Logger log = Logger.getLogger(DashboardHandler.class);
    
    private static final String HTML_CONTENT = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modern EIR - Management Dashboard</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .header {
            text-align: center;
            color: white;
            margin-bottom: 30px;
        }

        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
        }

        .header p {
            font-size: 1.1em;
            opacity: 0.9;
        }

        .login-section {
            background: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            max-width: 400px;
            margin: 0 auto 30px;
        }

        .login-section h2 {
            margin-bottom: 20px;
            color: #333;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #555;
            font-weight: 500;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1em;
            transition: border-color 0.3s;
        }

        .form-group input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 5px rgba(102, 126, 234, 0.3);
        }

        .login-btn {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 1em;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s;
        }

        .login-btn:hover {
            transform: translateY(-2px);
        }

        .login-btn:active {
            transform: translateY(0);
        }

        .message {
            padding: 12px;
            border-radius: 5px;
            margin-bottom: 15px;
            display: none;
        }

        .message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            display: block;
        }

        .message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
            display: block;
        }

        .dashboard {
            display: none;
        }

        .logout-section {
            text-align: right;
            margin-bottom: 20px;
        }

        .logout-btn {
            padding: 10px 20px;
            background: #dc3545;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
        }

        .logout-btn:hover {
            background: #c82333;
        }

        .token-display {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        .token-display h3 {
            margin-bottom: 10px;
            color: #333;
        }

        .token-value {
            background: #f5f5f5;
            padding: 10px;
            border-radius: 5px;
            word-break: break-all;
            font-family: monospace;
            font-size: 0.9em;
            max-height: 80px;
            overflow-y: auto;
        }

        .role-badge {
            display: inline-block;
            padding: 5px 15px;
            background: #667eea;
            color: white;
            border-radius: 20px;
            font-size: 0.9em;
            margin-left: 10px;
        }

        .tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .tab-btn {
            padding: 12px 20px;
            background: white;
            border: 2px solid #ddd;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
        }

        .tab-btn.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-color: transparent;
        }

        .tab-btn:hover {
            border-color: #667eea;
        }

        .tab-content {
            display: none;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        .tab-content.active {
            display: block;
        }

        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }

        .metric-card {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            padding: 20px;
            border-radius: 10px;
            text-align: center;
        }

        .metric-card h4 {
            color: #666;
            margin-bottom: 10px;
            font-size: 0.9em;
        }

        .metric-card .value {
            font-size: 2em;
            font-weight: bold;
            color: #333;
        }

        .refresh-btn {
            padding: 10px 20px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            margin-bottom: 15px;
        }

        .refresh-btn:hover {
            background: #218838;
        }

        .audit-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        .audit-table th {
            background: #f5f5f5;
            padding: 12px;
            text-align: left;
            border-bottom: 2px solid #ddd;
            font-weight: 600;
            color: #333;
        }

        .audit-table td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
        }

        .audit-table tr:hover {
            background: #f9f9f9;
        }

        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.85em;
            font-weight: 600;
        }

        .status-whitelisted {
            background: #d4edda;
            color: #155724;
        }

        .status-blacklisted {
            background: #f8d7da;
            color: #721c24;
        }

        .status-greylisted {
            background: #fff3cd;
            color: #856404;
        }

        .status-unknown {
            background: #e2e3e5;
            color: #383d41;
        }

        .health-status {
            padding: 15px;
            background: #d4edda;
            border-left: 4px solid #28a745;
            border-radius: 5px;
            margin-bottom: 15px;
        }

        .health-status.error {
            background: #f8d7da;
            border-left-color: #dc3545;
        }

        .loading {
            text-align: center;
            padding: 20px;
            color: #666;
        }

        .spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #667eea;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            animation: spin 1s linear infinite;
            margin: 0 auto 10px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        @media (max-width: 768px) {
            .header h1 {
                font-size: 1.8em;
            }

            .metrics-grid {
                grid-template-columns: 1fr;
            }

            .tabs {
                flex-direction: column;
            }

            .tab-btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🛡️ Modern EIR Management</h1>
            <p>Equipment Identity Register - REST API Dashboard</p>
        </div>

        <div id="loginSection" class="login-section">
            <h2>Login to Dashboard</h2>
            <div id="loginMessage" class="message"></div>
            
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" placeholder="admin or viewer" value="admin">
            </div>
            
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" placeholder="Password" value="admin123">
            </div>
            
            <button class="login-btn" onclick="login()">Login</button>
            
            <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #ddd; font-size: 0.9em; color: #666;">
                <p><strong>Demo Users:</strong></p>
                <p>👨‍💼 Admin: admin / admin123</p>
                <p>👁️ Viewer: viewer / viewer123</p>
            </div>
        </div>

        <div id="dashboardSection" class="dashboard">
            <div class="logout-section">
                <span id="userInfo" style="color: white; font-weight: 600;"></span>
                <button class="logout-btn" onclick="logout()">Logout</button>
            </div>

            <div class="token-display">
                <h3>JWT Token <span class="role-badge" id="roleBadge"></span></h3>
                <div class="token-value" id="tokenDisplay"></div>
            </div>

            <div class="tabs">
                <button class="tab-btn active" onclick="switchTab('health')">🏥 Health</button>
                <button class="tab-btn" onclick="switchTab('equipment')">📊 Equipment</button>
                <button class="tab-btn" onclick="switchTab('database')">🗄️ Database</button>
                <button class="tab-btn" onclick="switchTab('pool')">🏊 Pool</button>
                <button class="tab-btn" onclick="switchTab('audit')">📋 Audit</button>
            </div>

            <div id="health" class="tab-content active">
                <h3>Health Check</h3>
                <button class="refresh-btn" onclick="refreshHealth()">Refresh</button>
                <div id="healthContent" class="loading">
                    <div class="spinner"></div>
                    Loading...
                </div>
            </div>

            <div id="equipment" class="tab-content">
                <h3>Equipment Metrics</h3>
                <button class="refresh-btn" onclick="refreshEquipmentMetrics()">Refresh</button>
                <div id="equipmentContent" class="loading">
                    <div class="spinner"></div>
                    Loading...
                </div>
            </div>

            <div id="database" class="tab-content">
                <h3>Database Metrics</h3>
                <button class="refresh-btn" onclick="refreshDatabaseMetrics()">Refresh</button>
                <div id="databaseContent" class="loading">
                    <div class="spinner"></div>
                    Loading...
                </div>
            </div>

            <div id="pool" class="tab-content">
                <h3>Connection Pool Status</h3>
                <button class="refresh-btn" onclick="refreshPoolMetrics()">Refresh</button>
                <div id="poolContent" class="loading">
                    <div class="spinner"></div>
                    Loading...
                </div>
            </div>

            <div id="audit" class="tab-content">
                <h3>Audit Logs</h3>
                <button class="refresh-btn" onclick="refreshAuditLogs()">Refresh</button>
                <div>
                    <label>Limit: </label>
                    <input type="number" id="auditLimit" value="10" min="1" max="100" style="width: 60px;">
                    <label style="margin-left: 20px;">Status: </label>
                    <select id="auditStatusFilter" style="padding: 5px;">
                        <option value="">All</option>
                        <option value="WHITELISTED">WHITELISTED</option>
                        <option value="BLACKLISTED">BLACKLISTED</option>
                        <option value="GREYLISTED">GREYLISTED</option>
                        <option value="UNKNOWN">UNKNOWN</option>
                    </select>
                </div>
                <div id="auditContent" class="loading" style="margin-top: 15px;">
                    <div class="spinner"></div>
                    Loading...
                </div>
            </div>
        </div>
    </div>

    <script>
        const API_URL = '/api';
        let token = localStorage.getItem('managementToken');
        let userRole = localStorage.getItem('userRole');
        let username = localStorage.getItem('username');

        document.addEventListener('DOMContentLoaded', function() {
            if (token) {
                showDashboard();
                refreshHealth();
            }
        });

        async function login() {
            const usernameInput = document.getElementById('username').value;
            const passwordInput = document.getElementById('password').value;
            const messageDiv = document.getElementById('loginMessage');

            if (!usernameInput || !passwordInput) {
                showMessage(messageDiv, 'Please enter username and password', 'error');
                return;
            }

            try {
                const response = await fetch(`${API_URL}/auth/login`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        username: usernameInput,
                        password: passwordInput
                    })
                });

                const data = await response.json();

                if (response.ok) {
                    token = data.token;
                    userRole = data.role;
                    username = usernameInput;

                    localStorage.setItem('managementToken', token);
                    localStorage.setItem('userRole', userRole);
                    localStorage.setItem('username', username);

                    showMessage(messageDiv, `Login successful! Welcome ${username}`, 'success');
                    setTimeout(showDashboard, 1000);
                } else {
                    showMessage(messageDiv, data.error || 'Login failed', 'error');
                }
            } catch (error) {
                showMessage(messageDiv, 'Connection error: ' + error.message, 'error');
            }
        }

        function logout() {
            localStorage.removeItem('managementToken');
            localStorage.removeItem('userRole');
            localStorage.removeItem('username');
            token = null;
            showLoginForm();
        }

        function showDashboard() {
            document.getElementById('loginSection').style.display = 'none';
            document.getElementById('dashboardSection').style.display = 'block';
            document.getElementById('userInfo').textContent = `👤 ${username} [${userRole}]`;
            document.getElementById('roleBadge').textContent = userRole;
            document.getElementById('tokenDisplay').textContent = token;
        }

        function showLoginForm() {
            document.getElementById('loginSection').style.display = 'block';
            document.getElementById('dashboardSection').style.display = 'none';
        }

        function switchTab(tabName) {
            document.querySelectorAll('.tab-content').forEach(tab => {
                tab.classList.remove('active');
            });

            document.querySelectorAll('.tab-btn').forEach(btn => {
                btn.classList.remove('active');
            });

            document.getElementById(tabName).classList.add('active');
            event.target.classList.add('active');

            if (tabName === 'health') refreshHealth();
            else if (tabName === 'equipment') refreshEquipmentMetrics();
            else if (tabName === 'database') refreshDatabaseMetrics();
            else if (tabName === 'pool') refreshPoolMetrics();
            else if (tabName === 'audit') refreshAuditLogs();
        }

        async function refreshHealth() {
            const content = document.getElementById('healthContent');
            content.innerHTML = '<div class="loading"><div class="spinner"></div>Loading...</div>';

            try {
                const response = await fetch(`${API_URL}/metrics/health`);
                const data = await response.json();

                if (response.ok) {
                    content.innerHTML = `
                        <div class="health-status">
                            <p><strong>Status:</strong> ${data.status}</p>
                            <p><strong>Version:</strong> ${data.version}</p>
                            <p><strong>Timestamp:</strong> ${data.timestamp}</p>
                        </div>
                    `;
                } else {
                    content.innerHTML = `<div class="health-status error"><p>Error: ${data.error}</p></div>`;
                }
            } catch (error) {
                content.innerHTML = `<div class="health-status error"><p>Error: ${error.message}</p></div>`;
            }
        }

        async function refreshEquipmentMetrics() {
            const content = document.getElementById('equipmentContent');
            content.innerHTML = '<div class="loading"><div class="spinner"></div>Loading...</div>';

            try {
                const response = await fetch(`${API_URL}/metrics/equipment`, {
                    headers: { 'Authorization': `Bearer ${token}` }
                });

                const data = await response.json();

                if (response.ok) {
                    content.innerHTML = `
                        <div class="metrics-grid">
                            <div class="metric-card">
                                <h4>Total Requests</h4>
                                <div class="value">${data.totalRequests}</div>
                            </div>
                            <div class="metric-card">
                                <h4>Whitelisted</h4>
                                <div class="value">${data.whitelisted}</div>
                            </div>
                            <div class="metric-card">
                                <h4>Blacklisted</h4>
                                <div class="value">${data.blacklisted}</div>
                            </div>
                            <div class="metric-card">
                                <h4>Greylisted</h4>
                                <div class="value">${data.greylisted}</div>
                            </div>
                            <div class="metric-card">
                                <h4>Unknown</h4>
                                <div class="value">${data.unknown}</div>
                            </div>
                            <div class="metric-card">
                                <h4>DB Errors</h4>
                                <div class="value">${data.databaseErrors}</div>
                            </div>
                            <div class="metric-card">
                                <h4>Avg Latency (ms)</h4>
                                <div class="value">${data.avgLatencyMs}</div>
                            </div>
                            <div class="metric-card">
                                <h4>Pool Saturation</h4>
                                <div class="value">${data['poolSaturation%']}</div>
                            </div>
                        </div>
                    `;
                } else {
                    content.innerHTML = `<div class="health-status error"><p>Error: ${data.error}</p></div>`;
                }
            } catch (error) {
                content.innerHTML = `<div class="health-status error"><p>Error: ${error.message}</p></div>`;
            }
        }

        async function refreshDatabaseMetrics() {
            const content = document.getElementById('databaseContent');
            content.innerHTML = '<div class="loading"><div class="spinner"></div>Loading...</div>';

            try {
                const response = await fetch(`${API_URL}/metrics/database`, {
                    headers: { 'Authorization': `Bearer ${token}` }
                });

                const data = await response.json();

                if (response.ok) {
                    content.innerHTML = `
                        <div class="metrics-grid">
                            <div class="metric-card">
                                <h4>Total Requests</h4>
                                <div class="value">${data.totalRequests}</div>
                            </div>
                            <div class="metric-card">
                                <h4>Database Errors</h4>
                                <div class="value">${data.databaseErrors}</div>
                            </div>
                            <div class="metric-card">
                                <h4>Error Rate (%)</h4>
                                <div class="value">${data['errorRate%'].toFixed(2)}</div>
                            </div>
                            <div class="metric-card">
                                <h4>Min Latency (ms)</h4>
                                <div class="value">${data.minLatencyMs}</div>
                            </div>
                            <div class="metric-card">
                                <h4>Max Latency (ms)</h4>
                                <div class="value">${data.maxLatencyMs}</div>
                            </div>
                            <div class="metric-card">
                                <h4>Avg Latency (ms)</h4>
                                <div class="value">${data.avgLatencyMs}</div>
                            </div>
                        </div>
                    `;
                } else {
                    content.innerHTML = `<div class="health-status error"><p>Error: ${data.error}</p></div>`;
                }
            } catch (error) {
                content.innerHTML = `<div class="health-status error"><p>Error: ${error.message}</p></div>`;
            }
        }

        async function refreshPoolMetrics() {
            const content = document.getElementById('poolContent');
            content.innerHTML = '<div class="loading"><div class="spinner"></div>Loading...</div>';

            try {
                const response = await fetch(`${API_URL}/metrics/pool`, {
                    headers: { 'Authorization': `Bearer ${token}` }
                });

                const data = await response.json();

                if (response.ok) {
                    content.innerHTML = `
                        <div class="metrics-grid">
                            <div class="metric-card">
                                <h4>Connections Used</h4>
                                <div class="value">${data.poolUsed}</div>
                            </div>
                            <div class="metric-card">
                                <h4>Max Connections</h4>
                                <div class="value">${data.poolMax}</div>
                            </div>
                            <div class="metric-card">
                                <h4>Available</h4>
                                <div class="value">${data.available}</div>
                            </div>
                            <div class="metric-card">
                                <h4>Saturation (%)</h4>
                                <div class="value">${data['poolSaturation%']}</div>
                            </div>
                        </div>
                    `;
                } else {
                    content.innerHTML = `<div class="health-status error"><p>Error: ${data.error}</p></div>`;
                }
            } catch (error) {
                content.innerHTML = `<div class="health-status error"><p>Error: ${error.message}</p></div>`;
            }
        }

        async function refreshAuditLogs() {
            const content = document.getElementById('auditContent');
            content.innerHTML = '<div class="loading"><div class="spinner"></div>Loading...</div>';

            const limit = document.getElementById('auditLimit').value;
            const status = document.getElementById('auditStatusFilter').value;
            let url = `${API_URL}/audit/logs?limit=${limit}`;
            if (status) url += `&status=${status}`;

            try {
                const response = await fetch(url, {
                    headers: { 'Authorization': `Bearer ${token}` }
                });

                const data = await response.json();

                if (response.ok) {
                    if (data.logs && data.logs.length > 0) {
                        let html = `<table class="audit-table">
                            <thead>
                                <tr>
                                    <th>Timestamp</th>
                                    <th>IMEI</th>
                                    <th>Status</th>
                                    <th>Reason</th>
                                    <th>Source</th>
                                </tr>
                            </thead>
                            <tbody>`;

                        data.logs.forEach(log => {
                            const statusClass = `status-${log.status.toLowerCase()}`;
                            html += `<tr>
                                <td>${new Date(log.timestamp).toLocaleString()}</td>
                                <td><code>${log.imei}</code></td>
                                <td><span class="status-badge ${statusClass}">${log.status}</span></td>
                                <td>${log.reason}</td>
                                <td>${log.source}</td>
                            </tr>`;
                        });

                        html += `</tbody></table>`;
                        html += `<div style="text-align: center; padding: 15px; color: #666;">
                            Showing ${data.logs.length} of ${data.total} logs
                        </div>`;

                        content.innerHTML = html;
                    } else {
                        content.innerHTML = '<p style="color: #666; text-align: center; padding: 20px;">No audit logs found</p>';
                    }
                } else {
                    content.innerHTML = `<div class="health-status error"><p>Error: ${data.error}</p></div>`;
                }
            } catch (error) {
                content.innerHTML = `<div class="health-status error"><p>Error: ${error.message}</p></div>`;
            }
        }

        function showMessage(messageDiv, text, type) {
            messageDiv.textContent = text;
            messageDiv.className = `message ${type}`;
        }
    </script>
</body>
</html>
""";
    
    /**
     * Handle GET /dashboard
     * Serves the management dashboard HTML
     */
    public void handleDashboard(HttpExchange exchange) throws Exception {
        try {
            if (!"GET".equals(exchange.getRequestMethod())) {
                HttpResponse response = new HttpResponse(exchange);
                response.error(405, "Method not allowed").send();
                return;
            }
            
            // Set response headers
            exchange.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
            exchange.sendResponseHeaders(200, HTML_CONTENT.getBytes("UTF-8").length);
            
            // Write HTML content
            exchange.getResponseBody().write(HTML_CONTENT.getBytes("UTF-8"));
            exchange.getResponseBody().close();
            
            log.info("Dashboard served to client");
            
        } catch (Exception e) {
            log.error("Dashboard handler error", e);
            try {
                HttpResponse response = new HttpResponse(exchange);
                response.error(500, "Internal server error").send();
            } catch (Exception ex) {
                log.error("Error sending error response", ex);
            }
        }
    }
}
