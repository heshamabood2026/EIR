package com.example.eir;

import org.apache.log4j.Logger;
import org.restcomm.protocols.ss7.transport.Association;
import org.restcomm.protocols.ss7.transport.AssociationListener;
import org.restcomm.protocols.ss7.transport.PayloadData;
import org.restcomm.protocols.ss7.transport.Management;

import org.restcomm.protocols.ss7.indicator.NatureOfAddress;
import org.restcomm.protocols.ss7.indicator.RoutingIndicator;
import org.restcomm.protocols.ss7.m3ua.As;
import org.restcomm.protocols.ss7.m3ua.impl.M3UAManagementImpl;

import org.restcomm.protocols.ss7.sccp.impl.SccpStackImpl;

import org.restcomm.protocols.ss7.sccp.parameter.*;
import org.restcomm.protocols.ss7.tcap.TCAPStackImpl;
import org.restcomm.protocols.ss7.map.MAPStackImpl;
import org.restcomm.protocols.ss7.map.api.MAPApplicationContext;
import org.restcomm.protocols.ss7.map.api.MAPApplicationContextName;
import org.restcomm.protocols.ss7.map.api.MAPApplicationContextVersion;
import org.restcomm.protocols.ss7.map.api.MAPProvider;
import org.restcomm.protocols.ss7.map.api.MAPDialog;
import org.restcomm.protocols.ss7.map.api.MAPDialogListener;
import org.restcomm.protocols.ss7.map.api.MAPException;
import org.restcomm.protocols.ss7.map.api.MAPMessage;
import org.restcomm.protocols.ss7.map.api.dialog.*;
import org.restcomm.protocols.ss7.map.api.errors.MAPErrorMessage;
import org.restcomm.protocols.ss7.map.api.primitives.*;
import org.restcomm.protocols.ss7.map.api.service.mobility.MAPServiceMobilityListener;
import org.restcomm.protocols.ss7.map.api.service.mobility.authentication.*;
import org.restcomm.protocols.ss7.map.api.service.mobility.faultRecovery.*;
import org.restcomm.protocols.ss7.map.api.service.mobility.imei.*;
import org.restcomm.protocols.ss7.map.api.service.mobility.locationManagement.*;
import org.restcomm.protocols.ss7.map.api.service.mobility.oam.*;
import org.restcomm.protocols.ss7.map.api.service.mobility.subscriberInformation.*;
import org.restcomm.protocols.ss7.map.api.service.mobility.subscriberManagement.*;
import org.restcomm.protocols.ss7.tcap.asn.ApplicationContextName;
import org.restcomm.protocols.ss7.tcap.asn.comp.Problem;
import org.restcomm.protocols.ss7.ss7ext.Ss7ExtInterface;
import org.restcomm.protocols.ss7.indicator.NumberingPlan;

public final class MscSimulatorMain implements MAPDialogListener, MAPServiceMobilityListener {


    private static final Logger log = Logger.getLogger(MscSimulatorMain.class);

    private final java.util.concurrent.CountDownLatch associationUp =
            new java.util.concurrent.CountDownLatch(1);

    private Management transportManagement;
    private M3UAManagementImpl m3ua;
    private SccpStackImpl sccp;
    private TCAPStackImpl tcap;
    private MAPStackImpl map;
    private MAPProvider provider;
    private final EirConfig cfg;

    public MscSimulatorMain(EirConfig cfg) {
        this.cfg = cfg;
    }

    public static void main(String[] args) throws Exception {
        String transport = EirConfig.parseCommandLineType(args);
        EirConfig cfg = EirConfig.load("MSC", transport);

        MscSimulatorMain app = new MscSimulatorMain(cfg);
        Runtime.getRuntime().addShutdownHook(
                new Thread(app::stop, "msc-shutdown")
        );

        app.start();

        app.m3ua.startAsp(cfg.aspName);

        if (!app.associationUp.await(30, java.util.concurrent.TimeUnit.SECONDS)) {
            throw new IllegalStateException(
                    cfg.associationName + " did not reach communication-up state within 30 seconds"
            );
        }

        app.awaitApplicationServerActive(30, java.util.concurrent.TimeUnit.SECONDS);

        app.send("333333334444440");
        app.send("490154203237518");
        app.send("333333334444442");

        Thread.currentThread().join();
    }

    void start() throws Exception {
        transportManagement = TransportFactory.create(cfg.channelType, cfg.sctpName);
        transportManagement.setSingleThread(true);
        transportManagement.setConnectDelay(cfg.connectDelay);
        transportManagement.start();
        if (transportManagement instanceof org.restcomm.protocols.ss7.transport.RestCommTcpManagement tcp) {
            tcp.addAssociation(cfg.localIp, cfg.localPort, cfg.peerIp, cfg.peerPort,
                    cfg.associations.get(0).backupPeerAddress(), cfg.associations.get(0).backupPeerPort(),
                    cfg.associationName);
        } else if (transportManagement instanceof org.restcomm.protocols.ss7.transport.RestCommSctpManagement sctp) {
            AssociationConfig a = cfg.associations.get(0);
            transportManagement.addAssociation(cfg.localIp, cfg.localPort,
                    a.backupLocalAddress(), a.backupLocalPort(),
                    cfg.peerIp, cfg.peerPort,
                    a.backupPeerAddress(), a.backupPeerPort(), cfg.associationName);
        } else {
            transportManagement.addAssociation(cfg.localIp, cfg.localPort, cfg.peerIp, cfg.peerPort, cfg.associationName);
        }

        m3ua = new M3UAManagementImpl(
                cfg.m3uaName,
                "Modern-EIR-IMS-Simulator",
                null
        );
        m3ua.setTransportManagement(transportManagement);
        m3ua.start();

        Association mscAssociation = transportManagement.getAssociation(cfg.associationName);
        if (mscAssociation == null) {
            throw new IllegalStateException(
                    "Transport did not create association " + cfg.associationName);
        }

        final AssociationListener m3uaListener =
                mscAssociation.getAssociationListener();
        if (m3uaListener == null) {
            throw new IllegalStateException(
                    "M3UA did not install an AssociationListener on " + cfg.associationName);
        }

        mscAssociation.setAssociationListener(new AssociationListener() {
            @Override
            public void onCommunicationUp(Association association,
                                           int maxInboundStreams,
                                           int maxOutboundStreams) {
                log.info(cfg.associationName + " transport communication UP"
                        + " inboundStreams=" + maxInboundStreams
                        + " outboundStreams=" + maxOutboundStreams);
                m3uaListener.onCommunicationUp(association,
                        maxInboundStreams, maxOutboundStreams);
                associationUp.countDown();
            }

            @Override
            public void onCommunicationShutdown(Association association) {
                m3uaListener.onCommunicationShutdown(association);
                log.warn(cfg.associationName + " communication SHUTDOWN");
            }

            @Override
            public void onCommunicationLost(Association association) {
                m3uaListener.onCommunicationLost(association);
                log.warn(cfg.associationName + " communication LOST");
            }

            @Override
            public void onCommunicationRestart(Association association) {
                m3uaListener.onCommunicationRestart(association);
                log.info(cfg.associationName + " communication RESTART");
            }

            @Override
            public void onPayload(Association association, PayloadData payloadData) {
                m3uaListener.onPayload(association, payloadData);
            }

            @Override
            public void inValidStreamId(PayloadData payloadData) {
                m3uaListener.inValidStreamId(payloadData);
            }
        });

        sccp = new SccpStackImpl(
                cfg.role + "-SCCP",
                (Ss7ExtInterface) null
        );
        sccp.setMtp3UserPart(cfg.mtp3Id, m3ua);
        sccp.start();

        tcap = new TCAPStackImpl(
                cfg.role + "-TCAP",
                sccp.getSccpProvider(),
                cfg.localSsn
        );
        map = new MAPStackImpl(
                cfg.role + "-MAP",
                tcap.getProvider()
        );

        provider = map.getMAPProvider();
        provider.addMAPDialogListener(this);
        provider.getMAPServiceMobility().addMAPServiceListener(this);
        provider.getMAPServiceMobility().acivate();
        map.start();

        log.info("MSC simulator stack initialized; waiting for transport UP");
    }


    void send(String imei) throws MAPException {
        ParameterFactory pf = sccp.getSccpProvider().getParameterFactory();
        GlobalTitle0100 eirGt = pf.createGlobalTitle(cfg.remoteGt, 0, NumberingPlan.ISDN_TELEPHONY, null, NatureOfAddress.INTERNATIONAL);
        GlobalTitle0100 mscGt = pf.createGlobalTitle(cfg.localGt, 0, NumberingPlan.ISDN_TELEPHONY, null, NatureOfAddress.INTERNATIONAL);
        RoutingIndicator dpcSsnRouting = dpcSsnRoutingIndicator();
        SccpAddress orig = pf.createSccpAddress(
                dpcSsnRouting,
                mscGt, cfg.localSpc, cfg.localSsn);
        SccpAddress dest = pf.createSccpAddress(
                dpcSsnRouting,
                eirGt, cfg.remoteSpc, cfg.remoteSsn);
        MAPApplicationContext ctx = MAPApplicationContext.getInstance(MAPApplicationContextName.equipmentMngtContext, MAPApplicationContextVersion.version2);
        var dialog = provider.getMAPServiceMobility().createNewDialog(ctx, orig, null, dest, null);
        IMEI i = provider.getMAPParameterFactory().createIMEI(imei);
        log.info("Sending CheckIMEI imei=" + imei);
        dialog.addCheckImeiRequest(i, null, null);
        dialog.send();
    }

    private static RoutingIndicator dpcSsnRoutingIndicator() {
        for (RoutingIndicator indicator : RoutingIndicator.values()) {
            String name = indicator.name().toUpperCase(java.util.Locale.ROOT);
            if (name.contains("DPC") && name.contains("SSN")) {
                return indicator;
            }
        }
        throw new IllegalStateException(
                "This jSS7 build has no SCCP RoutingIndicator for DPC+SSN routing");
    }

    private void awaitApplicationServerActive(long timeout, java.util.concurrent.TimeUnit unit)
            throws InterruptedException {
        long deadline = System.nanoTime() + unit.toNanos(timeout);
        As applicationServer = m3ua.getAppServers().stream()
                .filter(as -> cfg.asName.equals(as.getName()))
                .findFirst()
                .orElseThrow(() -> new IllegalStateException(
                        "M3UA XML did not create application server " + cfg.asName));

        while (System.nanoTime() < deadline) {
            if (applicationServer.isUp()) {
                log.info(cfg.asName + " M3UA application server ACTIVE");
                return;
            }
            Thread.sleep(50);
        }

        throw new IllegalStateException(cfg.asName + " did not reach M3UA ACTIVE state within "
                + timeout + " " + unit.toString().toLowerCase(java.util.Locale.ROOT)
                + "; current state=" + applicationServer.getState().getName());
    }

    void stop() {
        try { if (map != null) map.stop(); } catch (Exception ignored) {}
        try { if (tcap != null) tcap.stop(); } catch (Exception ignored) {}
        try { if (sccp != null) sccp.stop(); } catch (Exception ignored) {}
        try { if (m3ua != null) m3ua.stop(); } catch (Exception ignored) {}
        try { if (transportManagement != null) transportManagement.stop(); } catch (Exception ignored) {}
    }

    @Override
    public void onCheckImeiResponse(CheckImeiResponse r) {
        log.info("RESPONSE dialog=" +
                r.getMAPDialog().getLocalDialogId() +
                " status=" + r.getEquipmentStatus());
    }

    @Override public void onCheckImeiRequest(CheckImeiRequest r) { }
    @Override public void onErrorComponent(MAPDialog d, Long id, MAPErrorMessage e) { log.error("MAP error " + e); }
    @Override public void onInvokeTimeout(MAPDialog d, Long id) { log.error("MAP timeout dialog=" + d.getLocalDialogId() + " invoke=" + id); }
    @Override public void onMAPMessage(MAPMessage m) { }

@Override public void onRejectComponent(MAPDialog d, Long id, Problem p, boolean isLocalOriginated) { log.error("MAP reject " + p); }
    @Override public void onDialogAccept(MAPDialog d, MAPExtensionContainer e) { }
    @Override public void onDialogClose(MAPDialog d) { log.debug("Dialog close " + d.getLocalDialogId()); }
    @Override public void onDialogDelimiter(MAPDialog d) { }
    @Override public void onDialogNotice(MAPDialog d, MAPNoticeProblemDiagnostic p) { log.error("Dialog notice " + p); }
    @Override public void onDialogProviderAbort(MAPDialog d, MAPAbortProviderReason r, MAPAbortSource s, MAPExtensionContainer e) { log.error("Provider abort " + r); }
    @Override public void onDialogRelease(MAPDialog d) { }
    @Override public void onDialogRequest(MAPDialog d, AddressString dest, AddressString orig, MAPExtensionContainer e) { }

    @Override public void onDialogTimeout(MAPDialog d) { log.error("Dialog timeout " + d.getLocalDialogId()); }
    @Override public void onDialogUserAbort(MAPDialog d, MAPUserAbortChoice r, MAPExtensionContainer e) { log.error("User abort " + r); }

    @Override
    public void onDialogReject(
            MAPDialog d,
            MAPRefuseReason r,
            ApplicationContextName a,
            MAPExtensionContainer e) {
        log.error("Dialog reject " + r);
    }

    @Override public void onDialogRequestEricsson(MAPDialog d, AddressString dest, AddressString orig, AddressString imsi, AddressString vlr) { }
    @Override
    public void onAnyTimeSubscriptionInterrogationRequest(
            org.restcomm.protocols.ss7.map.api.service.mobility.subscriberInformation.AnyTimeSubscriptionInterrogationRequest r) {
    }

    @Override
    public void onAnyTimeSubscriptionInterrogationResponse(
            org.restcomm.protocols.ss7.map.api.service.mobility.subscriberInformation.AnyTimeSubscriptionInterrogationResponse r) {
    }
    @Override public void onAnyTimeInterrogationRequest(AnyTimeInterrogationRequest r) { }
    @Override public void onAnyTimeInterrogationResponse(AnyTimeInterrogationResponse r) { }
    @Override public void onAuthenticationFailureReportRequest(AuthenticationFailureReportRequest r) { }
    @Override public void onAuthenticationFailureReportResponse(AuthenticationFailureReportResponse r) { }
    @Override public void onSendAuthenticationInfoRequest(SendAuthenticationInfoRequest r) { }
    @Override public void onSendAuthenticationInfoResponse(SendAuthenticationInfoResponse r) { }
    @Override public void onForwardCheckSSIndicationRequest(ForwardCheckSSIndicationRequest r) { }
    @Override public void onResetRequest(ResetRequest r) { }
    @Override public void onRestoreDataRequest(RestoreDataRequest r) { }
    @Override public void onRestoreDataResponse(RestoreDataResponse r) { }
    @Override public void onCancelLocationRequest(CancelLocationRequest r) { }
    @Override public void onCancelLocationResponse(CancelLocationResponse r) { }
    @Override public void onPurgeMSRequest(PurgeMSRequest r) { }
    @Override public void onPurgeMSResponse(PurgeMSResponse r) { }
    @Override public void onSendIdentificationRequest(SendIdentificationRequest r) { }
    @Override public void onSendIdentificationResponse(SendIdentificationResponse r) { }
    @Override public void onUpdateGprsLocationRequest(UpdateGprsLocationRequest r) { }
    @Override public void onUpdateGprsLocationResponse(UpdateGprsLocationResponse r) { }
    @Override public void onUpdateLocationRequest(UpdateLocationRequest r) { }
    @Override public void onUpdateLocationResponse(UpdateLocationResponse r) { }
    @Override public void onActivateTraceModeRequest_Mobility(ActivateTraceModeRequest_Mobility r) { }
    @Override public void onActivateTraceModeResponse_Mobility(ActivateTraceModeResponse_Mobility r) { }
    @Override public void onProvideSubscriberInfoRequest(ProvideSubscriberInfoRequest r) { }
    @Override public void onProvideSubscriberInfoResponse(ProvideSubscriberInfoResponse r) { }
    @Override public void onInsertSubscriberDataRequest(InsertSubscriberDataRequest r) { }
    @Override public void onInsertSubscriberDataResponse(InsertSubscriberDataResponse r) { }
    @Override public void onDeleteSubscriberDataRequest(DeleteSubscriberDataRequest r) { }
    @Override public void onDeleteSubscriberDataResponse(DeleteSubscriberDataResponse r) { }
}
