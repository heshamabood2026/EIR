package com.example.eir.management;

import com.example.eir.auth.*;
import com.example.eir.metrics.EquipmentMetrics;
import com.example.eir.audit.*;
import org.apache.log4j.Logger;
import java.io.IOException;
import java.net.InetSocketAddress;
import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;

/**
 * Lightweight HTTP management server for EIR provisioning and observability.
 * 
 * Uses JDK's built-in HttpServer to avoid heavy framework dependencies.
 * Supports equipment provisioning, authentication, metrics, and audit logging.
 * 
 * Endpoints (Phase 1B):
 * - POST   /api/auth/login              Login (get JWT token)
 * - POST   /api/auth/refresh            Refresh token
 * - POST   /api/auth/logout             Logout (revoke token)
 * - GET    /api/metrics/health          Health check
 * - GET    /api/metrics/equipment       Equipment metrics
 * - GET    /api/metrics/database        Database metrics
 * - GET    /api/metrics/pool            Connection pool status
 * - GET    /api/audit/logs              Query audit logs
 * - GET    /api/audit/logs/{imei}       Logs for specific IMEI
 * - GET    /api/audit/metrics           Audit statistics
 */
public final class EirManagementServer {
    private static final Logger log = Logger.getLogger(EirManagementServer.class);
    
    private final ManagementConfig config;
    private final AuthenticationHandler authHandler;
    private final MetricsHandler metricsHandler;
    private final AuditHandler auditHandler;
    private final DashboardHandler dashboardHandler;
    private HttpServer httpServer;
    
    public EirManagementServer(
            ManagementConfig config,
            UserRepository userRepository,
            JwtTokenProvider tokenProvider,
            EquipmentMetrics metrics,
            ImeiMasker imeiMasker) {
        this.config = config;
        this.authHandler = new AuthenticationHandler(userRepository, tokenProvider);
        this.metricsHandler = new MetricsHandler(tokenProvider, metrics);
        this.auditHandler = new AuditHandler(tokenProvider, imeiMasker);
        this.dashboardHandler = new DashboardHandler();
    }
    
    /**
     * Start the management API server.
     * Binds to configured host:port with graceful error handling.
     */
    public void start() throws IOException {
        if (!config.isEnabled()) {
            log.info("Management API disabled");
            return;
        }
        
        String host = config.getHost();
        int port = config.getPort();
        
        try {
            InetSocketAddress addr = new InetSocketAddress(host, port);
            httpServer = HttpServer.create(addr, 50);
            httpServer.setExecutor(java.util.concurrent.Executors.newFixedThreadPool(8));
            
            // Register handlers
            registerHandlers();
            
            httpServer.start();
            log.info("EIR Management API started on http://" + host + ":" + port + "/api");
            log.info("Dashboard available at http://" + host + ":" + port + "/dashboard");
        } catch (IOException e) {
            log.error("Failed to start management API", e);
            throw e;
        }
    }
    
    /**
     * Stop the management API server.
     */
    public void stop() {
        if (httpServer != null) {
            httpServer.stop(1);
            log.info("Management API stopped");
        }
    }
    
    private void registerHandlers() {
        // Dashboard
        httpServer.createContext("/dashboard", exchange -> {
            try {
                dashboardHandler.handleDashboard(exchange);
            } catch (Exception e) {
                log.error("Dashboard endpoint error", e);
                try {
                    new HttpResponse(exchange).error(500, "Internal server error").send();
                } catch (Exception ex) {
                    log.error("Error sending response", ex);
                }
            }
        });
        
        // Root redirect to dashboard
        httpServer.createContext("/", exchange -> {
            try {
                String path = new HttpRequest(exchange).getPath();
                if ("/".equals(path)) {
                    dashboardHandler.handleDashboard(exchange);
                } else {
                    new HttpResponse(exchange).error(404, "Not found").send();
                }
            } catch (Exception e) {
                log.error("Root endpoint error", e);
                try {
                    new HttpResponse(exchange).error(500, "Internal server error").send();
                } catch (Exception ex) {
                    log.error("Error sending response", ex);
                }
            }
        });
        
        // Authentication endpoints
        httpServer.createContext("/api/auth/login", exchange -> {
            try {
                authHandler.handleLogin(exchange);
            } catch (Exception e) {
                log.error("Login endpoint error", e);
                try {
                    new HttpResponse(exchange).error(500, "Internal server error").send();
                } catch (Exception ex) {
                    log.error("Error sending response", ex);
                }
            }
        });
        
        httpServer.createContext("/api/auth/refresh", exchange -> {
            try {
                authHandler.handleRefresh(exchange);
            } catch (Exception e) {
                log.error("Refresh endpoint error", e);
                try {
                    new HttpResponse(exchange).error(500, "Internal server error").send();
                } catch (Exception ex) {
                    log.error("Error sending response", ex);
                }
            }
        });
        
        httpServer.createContext("/api/auth/logout", exchange -> {
            try {
                authHandler.handleLogout(exchange);
            } catch (Exception e) {
                log.error("Logout endpoint error", e);
                try {
                    new HttpResponse(exchange).error(500, "Internal server error").send();
                } catch (Exception ex) {
                    log.error("Error sending response", ex);
                }
            }
        });
        
        // Metrics endpoints
        httpServer.createContext("/api/metrics/health", exchange -> {
            try {
                metricsHandler.handleHealth(exchange);
            } catch (Exception e) {
                log.error("Health endpoint error", e);
                try {
                    new HttpResponse(exchange).error(500, "Internal server error").send();
                } catch (Exception ex) {
                    log.error("Error sending response", ex);
                }
            }
        });
        
        httpServer.createContext("/api/metrics/equipment", exchange -> {
            try {
                metricsHandler.handleEquipmentMetrics(exchange);
            } catch (Exception e) {
                log.error("Equipment metrics endpoint error", e);
                try {
                    new HttpResponse(exchange).error(500, "Internal server error").send();
                } catch (Exception ex) {
                    log.error("Error sending response", ex);
                }
            }
        });
        
        httpServer.createContext("/api/metrics/database", exchange -> {
            try {
                metricsHandler.handleDatabaseMetrics(exchange);
            } catch (Exception e) {
                log.error("Database metrics endpoint error", e);
                try {
                    new HttpResponse(exchange).error(500, "Internal server error").send();
                } catch (Exception ex) {
                    log.error("Error sending response", ex);
                }
            }
        });
        
        httpServer.createContext("/api/metrics/pool", exchange -> {
            try {
                metricsHandler.handlePoolMetrics(exchange);
            } catch (Exception e) {
                log.error("Pool metrics endpoint error", e);
                try {
                    new HttpResponse(exchange).error(500, "Internal server error").send();
                } catch (Exception ex) {
                    log.error("Error sending response", ex);
                }
            }
        });
        
        // Audit endpoints
        httpServer.createContext("/api/audit/logs", exchange -> {
            try {
                String path = new HttpRequest(exchange).getPath();
                if (path.matches("/api/audit/logs/.*")) {
                    // Handle GET /api/audit/logs/{imei}
                    String imei = path.substring("/api/audit/logs/".length());
                    auditHandler.handleQueryImeiLogs(exchange, imei);
                } else {
                    // Handle GET /api/audit/logs
                    auditHandler.handleQueryLogs(exchange);
                }
            } catch (Exception e) {
                log.error("Audit logs endpoint error", e);
                try {
                    new HttpResponse(exchange).error(500, "Internal server error").send();
                } catch (Exception ex) {
                    log.error("Error sending response", ex);
                }
            }
        });
        
        httpServer.createContext("/api/audit/metrics", exchange -> {
            try {
                auditHandler.handleAuditMetrics(exchange);
            } catch (Exception e) {
                log.error("Audit metrics endpoint error", e);
                try {
                    new HttpResponse(exchange).error(500, "Internal server error").send();
                } catch (Exception ex) {
                    log.error("Error sending response", ex);
                }
            }
        });
        
        log.info("Management API handlers registered (Phase 1B complete: 10 endpoints + dashboard)");
    }
    
    public AuditHandler getAuditHandler() {
        return auditHandler;
    }
    
    public boolean isRunning() {
        return httpServer != null;
    }
}
