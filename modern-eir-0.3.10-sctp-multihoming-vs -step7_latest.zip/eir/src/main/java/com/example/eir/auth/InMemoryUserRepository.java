package com.example.eir.auth;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * In-memory user repository for equipment management authentication.
 * 
 * Stores users and provides login functionality.
 * Production should use database-backed repository.
 */
public final class InMemoryUserRepository implements UserRepository {
    
    private final Map<String, User> users = new ConcurrentHashMap<>();
    
    /**
     * Create demo repository with bootstrap admin user.
     * 
     * Default user:
     * - username: admin
     * - password: (hash of) "admin123"
     * - role: ADMIN
     */
    public static InMemoryUserRepository demo() {
        InMemoryUserRepository repo = new InMemoryUserRepository();
        
        // Bootstrap admin user with simple hash
        String adminHash = hashPassword("admin123");
        User admin = new User("admin", adminHash, Role.ADMIN, true, 
                java.time.Instant.now(), null);
        repo.save(admin);
        
        // Bootstrap viewer user
        String viewerHash = hashPassword("viewer123");
        User viewer = new User("viewer", viewerHash, Role.VIEWER, true,
                java.time.Instant.now(), null);
        repo.save(viewer);
        
        return repo;
    }
    
    @Override
    public void save(User user) {
        users.put(user.getUsername(), user);
    }
    
    @Override
    public Optional<User> findByUsername(String username) {
        return Optional.ofNullable(users.get(username));
    }
    
    @Override
    public boolean existsByUsername(String username) {
        return users.containsKey(username);
    }
    
    /**
     * Find user by username and verify password.
     * Returns user if credentials are valid, empty otherwise.
     */
    @Override
    public Optional<User> authenticate(String username, String password) {
        User user = users.get(username);
        if (user == null || !user.isEnabled()) {
            return Optional.empty();
        }
        
        if (verifyPassword(password, user.getPasswordHash())) {
            return Optional.of(user);
        }
        
        return Optional.empty();
    }
    
    /**
     * Simple password hashing (SHA-256 with salt prefix).
     * Production should use bcrypt or similar.
     */
    private static String hashPassword(String password) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(("salt" + password).getBytes());
            return Base64.getEncoder().encodeToString(hash);
        } catch (java.security.NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
    
    /**
     * Verify password against hash.
     */
    private static boolean verifyPassword(String password, String hash) {
        return hashPassword(password).equals(hash);
    }
}
