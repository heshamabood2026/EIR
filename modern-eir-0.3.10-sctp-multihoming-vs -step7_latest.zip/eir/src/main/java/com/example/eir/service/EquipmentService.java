package com.example.eir.service;

import com.example.eir.domain.Equipment;
import com.example.eir.domain.EquipmentDecision;
import com.example.eir.domain.EirEquipmentStatus;
import com.example.eir.exception.EquipmentRepositoryException;
import com.example.eir.repository.EquipmentRepository;

public final class EquipmentService {
    private static final String IMEI_PATTERN = "\\d{14,16}";

    private final EquipmentRepository repository;

    public EquipmentService(EquipmentRepository repository) {
        this.repository = repository;
    }

    public EquipmentDecision checkImei(String imei) {
        if (imei == null || !imei.matches(IMEI_PATTERN)) {
            return EquipmentDecision.invalidImei(imei);
        }

        try {
            Equipment equipment = repository.findByImei(imei);

            if (equipment == null) {
                return new EquipmentDecision(
                        imei,
                        EirEquipmentStatus.UNKNOWN,
                        repository.getClass().getSimpleName(),
                        "EQUIPMENT_NOT_FOUND",
                        null
                );
            }

            return EquipmentDecision.forEquipment(
                    equipment,
                    repository.getClass().getSimpleName()
            );
        } catch (EquipmentRepositoryException e) {
            return EquipmentDecision.databaseUnavailable(
                    imei,
                    repository.getClass().getSimpleName()
            );
        }
    }
}
