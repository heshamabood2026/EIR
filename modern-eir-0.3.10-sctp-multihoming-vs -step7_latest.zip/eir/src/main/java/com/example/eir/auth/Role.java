package com.example.eir.auth;

/**
 * User roles for equipment management API.
 * 
 * VIEWER: Read-only access to equipment and metrics
 * USER: Read + Create equipment records
 * ADMIN: Full access including delete and user management
 */
public enum Role {
    VIEWER(1, "View only"),
    USER(2, "View and create"),
    ADMIN(3, "Full access");
    
    private final int level;
    private final String description;
    
    Role(int level, String description) {
        this.level = level;
        this.description = description;
    }
    
    public int getLevel() { return level; }
    public String getDescription() { return description; }
    
    /**
     * Check if this role can perform an action required by minRole.
     * ADMIN can do everything, USER can read+write, VIEWER can read only.
     */
    public boolean canAccess(Role requiredRole) {
        return this.level >= requiredRole.level;
    }
}
