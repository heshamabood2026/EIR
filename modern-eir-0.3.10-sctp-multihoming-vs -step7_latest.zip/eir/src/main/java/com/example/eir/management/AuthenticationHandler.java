package com.example.eir.management;

import com.example.eir.auth.*;
import org.apache.log4j.Logger;
import com.sun.net.httpserver.HttpExchange;
import java.security.MessageDigest;
import java.util.Base64;

/**
 * HTTP handler for authentication endpoints.
 * Handles: login, token refresh, logout.
 */
public final class AuthenticationHandler {
    private static final Logger log = Logger.getLogger(AuthenticationHandler.class);
    
    private final UserRepository userRepository;
    private final JwtTokenProvider tokenProvider;
    
    public AuthenticationHandler(UserRepository userRepository, JwtTokenProvider tokenProvider) {
        this.userRepository = userRepository;
        this.tokenProvider = tokenProvider;
    }
    
    /**
     * Handle POST /api/auth/login
     * 
     * Request body: {"username":"admin","password":"admin123"}
     * Response: {"token":"...","expiresIn":3600,"role":"ADMIN"}
     */
    public void handleLogin(HttpExchange exchange) throws Exception {
        HttpRequest request = new HttpRequest(exchange);
        HttpResponse response = new HttpResponse(exchange);
        
        try {
            if (!"POST".equals(request.getMethod())) {
                response.error(405, "Method not allowed").send();
                return;
            }
            
            String body = request.getBody();
            if (body.isBlank()) {
                response.error(400, "Request body required").send();
                return;
            }
            
            // Simple JSON parsing (no library)
            String username = extractJsonField(body, "username");
            String password = extractJsonField(body, "password");
            
            if (username == null || username.isBlank() || password == null || password.isBlank()) {
                response.error(400, "username and password required").send();
                return;
            }
            
            // Authenticate user
            User user = userRepository.findByUsername(username).orElse(null);
            if (user == null) {
                log.warn("Login attempt for non-existent user: " + username);
                response.error(401, "Invalid credentials").send();
                return;
            }
            
            if (!user.isEnabled()) {
                log.warn("Login attempt for disabled user: " + username);
                response.error(401, "User is disabled").send();
                return;
            }
            
            // Verify password
            if (!verifyPassword(password, user.getPasswordHash())) {
                log.warn("Failed login attempt for user: " + username);
                response.error(401, "Invalid credentials").send();
                return;
            }
            
            // Generate token
            String token = tokenProvider.generateToken(user);
            String responseJson = String.format(
                    "{\"token\":\"%s\",\"expiresIn\":3600,\"role\":\"%s\"}",
                    token, user.getRole().name()
            );
            
            response.status(200).json(responseJson).send();
            log.info("User logged in: " + username);
            
        } catch (Exception e) {
            log.error("Login handler error", e);
            response.error(500, "Internal server error").send();
        }
    }
    
    /**
     * Handle POST /api/auth/refresh
     * 
     * Request header: Authorization: Bearer <token>
     * Response: {"token":"...","expiresIn":3600}
     */
    public void handleRefresh(HttpExchange exchange) throws Exception {
        HttpRequest request = new HttpRequest(exchange);
        HttpResponse response = new HttpResponse(exchange);
        
        try {
            if (!"POST".equals(request.getMethod())) {
                response.error(405, "Method not allowed").send();
                return;
            }
            
            String token = request.getAuthToken();
            if (token == null) {
                response.error(401, "Missing authorization header").send();
                return;
            }
            
            // Validate existing token
            String username = tokenProvider.validateToken(token);
            if (username == null) {
                response.error(401, "Invalid or expired token").send();
                return;
            }
            
            // Get user and generate new token
            User user = userRepository.findByUsername(username).orElse(null);
            if (user == null || !user.isEnabled()) {
                response.error(401, "User not found or disabled").send();
                return;
            }
            
            String newToken = tokenProvider.generateToken(user);
            String responseJson = String.format(
                    "{\"token\":\"%s\",\"expiresIn\":3600}",
                    newToken
            );
            
            response.status(200).json(responseJson).send();
            log.info("Token refreshed for user: " + username);
            
        } catch (Exception e) {
            log.error("Refresh handler error", e);
            response.error(500, "Internal server error").send();
        }
    }
    
    /**
     * Handle POST /api/auth/logout
     * 
     * Request header: Authorization: Bearer <token>
     * Response: {"message":"Logged out successfully"}
     */
    public void handleLogout(HttpExchange exchange) throws Exception {
        HttpRequest request = new HttpRequest(exchange);
        HttpResponse response = new HttpResponse(exchange);
        
        try {
            if (!"POST".equals(request.getMethod())) {
                response.error(405, "Method not allowed").send();
                return;
            }
            
            String token = request.getAuthToken();
            if (token == null) {
                response.error(401, "Missing authorization header").send();
                return;
            }
            
            // Revoke token
            tokenProvider.revokeToken(token);
            
            String responseJson = "{\"message\":\"Logged out successfully\"}";
            response.status(200).json(responseJson).send();
            
            log.info("User logged out");
            
        } catch (Exception e) {
            log.error("Logout handler error", e);
            response.error(500, "Internal server error").send();
        }
    }
    
    /**
     * Extract JSON field value (simple parsing, no library).
     */
    private static String extractJsonField(String json, String fieldName) {
        String pattern = "\"" + fieldName + "\":\"";
        int start = json.indexOf(pattern);
        if (start == -1) {
            return null;
        }
        
        start += pattern.length();
        int end = json.indexOf("\"", start);
        if (end == -1) {
            return null;
        }
        
        return json.substring(start, end);
    }
    
    /**
     * Hash password using SHA-256 (production should use bcrypt).
     * Uses salt prefix for basic security.
     */
    private static String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(("salt" + password).getBytes());
            return Base64.getEncoder().encodeToString(hash);
        } catch (Exception e) {
            throw new RuntimeException("Password hashing failed", e);
        }
    }
    
    /**
     * Verify password against hash.
     */
    private static boolean verifyPassword(String password, String hash) {
        return hashPassword(password).equals(hash);
    }
}
