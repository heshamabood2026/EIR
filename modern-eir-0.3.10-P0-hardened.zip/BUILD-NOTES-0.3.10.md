# Modern EIR 0.3.10 build notes

This release fixes TCP server listener handling for the SCTP-multihoming-compatible configuration.

## Changes

1. `EirStack` no longer creates a second TCP listener when `backupLocalAddress:backupLocalPort` is identical to the primary local endpoint.
2. Distinct TCP backup local endpoints still create a second listener for the same logical association.
3. `RestCommTcpManagement.addServer()` now rejects two differently named listeners configured for the same local endpoint before a bind is attempted.
4. TCP/SCTP server startup rolls back listeners that were already started if a later listener fails.
5. Added regression coverage for duplicate TCP listener endpoints.

## Expected Windows behavior

The common configuration:

`localAddress=127.0.0.1 localPort=2906`

`backupLocalAddress=127.0.0.1 backupLocalPort=2906`

uses one TCP listener. It must not produce a second `ServerSocket` bind attempt.

A genuinely different TCP backup listener, for example `127.0.0.1:2907`, remains supported.
