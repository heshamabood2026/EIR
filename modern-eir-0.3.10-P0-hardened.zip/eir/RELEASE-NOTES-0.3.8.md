# Modern EIR 0.3.8 — SCTP Multihoming

This release adds SCTP multihoming to the RestComm Java-SCTP fork while preserving the existing TCP implementation.

## Implemented

- One logical M3UA association can bind a primary and secondary local IP address to one JDK `SctpChannel`.
- One SCTP server can bind a primary and secondary local IP address to one `SctpServerChannel`.
- SCTP remote alternate addresses are validated from the peer address set learned by the SCTP association.
- No second M3UA ASP/AS is created for the backup path.
- Primary/backup peer ports must match in SCTP mode.
- Existing TCP primary/backup behavior remains unchanged.
- Added configuration and management tests for the single-association/multihoming model.

## Important platform note

JDK SCTP requires an SCTP-capable operating system/provider. Windows commonly reports `SCTP not supported on this platform`; use Linux or another supported SCTP environment for the live SCTP test. Windows remains supported for TCP testing.

## Live SCTP test topology

Use two IP addresses on each endpoint, with the same SCTP port on both addresses:

- EIR: `10.10.10.20:2906` + `10.10.10.21:2906`
- MSC: `10.20.20.20:2905` + `10.20.20.21:2905`

Configure the EIR server association with both local addresses and the MSC client association with both local addresses. The EIR's `backupPeerAddress` should point to the MSC's alternate address, and the MSC's `backupPeerAddress` should point to the EIR's alternate address.

After the association reaches `COMM_UP`, verify the SCTP channel reports both local and remote addresses. Then make the primary path unavailable and verify SCTP changes the active path without creating a new M3UA association.
