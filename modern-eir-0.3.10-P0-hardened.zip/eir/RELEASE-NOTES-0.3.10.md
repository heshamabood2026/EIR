# Modern EIR 0.3.10

## TCP listener role/lifecycle fix

- A TCP server association whose `backupLocalAddress:backupLocalPort` is identical to its primary local endpoint now uses a single listener instead of attempting a second bind.
- Distinct TCP backup local endpoints still create a second listener and bind the same logical association to both listeners.
- TCP/SCTP server startup now rolls back listeners already started if a later listener fails, preventing orphaned listener threads after startup errors.
- This preserves SCTP multihoming semantics: identical local address/port values are not treated as a second transport endpoint in TCP mode.
