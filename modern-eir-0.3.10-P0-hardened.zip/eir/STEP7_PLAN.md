# Step 7: Management, Observability & Operational Safety - Implementation Plan

**Date:** 2026-08-31  
**Status:** Planning Phase  
**Scope:** REST API + Auth → Metrics → Audit Logging → IMEI Masking

---

## Overview

Step 7 adds operational management and observability to the EIR system. Given that Modern EIR is a telecommunications protocol-focused application (SS7/SIGTRAN) without embedded web frameworks, we'll implement this in phases:

### Phase 1: REST API + Authentication (THIS PHASE)
- Lightweight REST endpoint using `com.sun.net.httpserver.HttpServer` (JDK built-in)
- JWT authentication
- Basic role-based access control
- Equipment management endpoints

### Phase 2: Metrics Collection
- Micrometer integration (JVM metrics)
- Custom equipment/database metrics
- Pool saturation, timeouts, latency

### Phase 3: Audit Logging
- Structured audit trail
- IMEI masking (configurable)
- Query interface

---

## Architecture Decision

Given the project constraints:
- ✅ No Spring Boot (avoids heavy dependency)
- ✅ Uses JDK 17 `com.sun.net.httpserver.HttpServer`
- ✅ Minimal framework overhead
- ✅ Easy to extend or migrate to Spring Boot later
- ✅ Keeps application focused on SS7 protocols

---

## Implementation Plan

### Phase 1A: Core REST Infrastructure

**New Classes:**
1. `EirManagementServer` - Lightweight HTTP server (port 8080 by default)
2. `EquipmentManagementHandler` - Handler for `/api/equipment/*` endpoints
3. `JwtTokenProvider` - JWT token generation and validation
4. `AuthenticationFilter` - Request interceptor for token validation
5. `ManagementServerConfig` - Configuration for management API

**Endpoints (Phase 1A):**
```
POST   /api/equipment                 # Create equipment
GET    /api/equipment/{imei}          # Query equipment
PUT    /api/equipment/{imei}          # Update equipment
DELETE /api/equipment/{imei}          # Delete equipment
POST   /api/equipment/bulk-import     # Bulk import CSV
```

### Phase 1B: Authentication

**New Classes:**
1. `User` - User entity (username, role, password hash)
2. `Role` - Enum (ADMIN, USER, VIEWER)
3. `AuthenticationHandler` - Handler for `/api/auth/login`
4. `UserRepository` - User persistence (in-memory or JDBC)

**Endpoints (Phase 1B):**
```
POST   /api/auth/login                # Get JWT token
POST   /api/auth/refresh              # Refresh token
POST   /api/auth/logout               # Revoke token
```

### Phase 2: Metrics Collection

**New Classes:**
1. `MetricsCollector` - Singleton metrics aggregator
2. `RequestMetrics` - Track request counts and statuses
3. `EquipmentMetrics` - Database latency, query counts
4. `PoolMetrics` - Connection pool saturation
5. `TimeoutMetrics` - MAP timeouts, errors

**Endpoints:**
```
GET    /api/metrics/health            # Application health
GET    /api/metrics/equipment          # Equipment metrics
GET    /api/metrics/database           # Database metrics
GET    /api/metrics/pool               # Connection pool status
GET    /api/metrics/requests           # Request statistics
```

### Phase 3: Audit Logging

**New Classes:**
1. `AuditLog` - Domain entity
2. `AuditRepository` - Audit log storage
3. `AuditService` - Write audit records
4. `ImeiMasker` - Configurable IMEI masking
5. `AuditQueryService` - Query audit logs

**Endpoints:**
```
GET    /api/audit/logs                 # Query audit logs
GET    /api/audit/logs/{imei}          # Logs for specific IMEI
GET    /api/audit/metrics              # Audit statistics
```

---

## Configuration

### application.properties (NEW SETTINGS)

```properties
# Management API
eir.management.enabled=true
eir.management.port=8080
eir.management.host=127.0.0.1

# JWT Configuration
eir.jwt.secret=changeme-production-secret-key
eir.jwt.expiry-minutes=60

# Metrics Configuration
eir.metrics.enabled=true
eir.metrics.export-interval-seconds=60

# Audit Logging
eir.audit.enabled=true
eir.audit.storage=database  # or memory
eir.audit.retention-days=90

# IMEI Masking
eir.imei.mask-mode=partial  # none, partial, full
eir.imei.mask-chars=****    # what to show instead
```

---

## Database Schema Extensions

### audit_logs table
```sql
CREATE TABLE audit_logs (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    timestamp DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    imei VARCHAR(16) NOT NULL,
    status ENUM('WHITELISTED', 'BLACKLISTED', 'GREYLISTED', 'UNKNOWN') NOT NULL,
    reason VARCHAR(100) NOT NULL,
    source VARCHAR(50) NOT NULL,
    user_id BIGINT,
    api_request_id VARCHAR(36),
    INDEX idx_timestamp (timestamp),
    INDEX idx_imei (imei),
    INDEX idx_status (status)
);

CREATE TABLE users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('ADMIN', 'USER', 'VIEWER') NOT NULL DEFAULT 'VIEWER',
    enabled BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_username (username)
);
```

---

## Security Considerations

### 1. Authentication
- JWT tokens with expiry
- Password hashing (bcrypt)
- Token blacklist on logout

### 2. Authorization
- Role-based access control
- VIEWER: read-only access
- USER: read + create equipment
- ADMIN: full access including delete

### 3. IMEI Masking
- Configurable masking levels
- Mask in logs: `equipment check for ****3344`
- Mask in audit: full IMEI with role checks
- Mask in responses: based on user role

### 4. API Security
- HTTPS only (in production)
- Rate limiting per user
- Request signing/validation

---

## Testing Strategy

### Phase 1A Tests
- REST endpoint tests (mock HTTP requests)
- Request/response serialization
- Error handling (400, 404, 500)

### Phase 1B Tests
- JWT token generation/validation
- User authentication
- Role-based access control

### Phase 2 Tests
- Metrics collection accuracy
- Thread safety of metrics
- Metrics export/query

### Phase 3 Tests
- Audit log recording
- IMEI masking in different scenarios
- Audit query filtering

---

## Implementation Timeline

**Phase 1A (REST API):** 2-3 hours
- HTTP server setup
- Basic endpoints
- CRUD operations
- Error handling

**Phase 1B (Authentication):** 2-3 hours
- JWT implementation
- User management
- Role-based authorization
- Token validation

**Phase 2 (Metrics):** 2-3 hours
- Metrics collection framework
- Database metrics
- Pool metrics
- Metrics endpoints

**Phase 3 (Audit & Masking):** 2-3 hours
- Audit logging infrastructure
- IMEI masking
- Audit query interface
- Retention policies

---

## Deployment Impact

### New Dependencies (to add)
- None for Phase 1A-1B (using JDK built-in)
- Micrometer core (optional, for Phase 2)
- bcrypt (for password hashing)

### Configuration Changes
- New management API properties
- JWT secret must be set (environment variable)
- User bootstrap/migration

### Production Checklist
- [ ] Generate strong JWT secret
- [ ] Bootstrap admin user
- [ ] Enable HTTPS/TLS (separate proxy)
- [ ] Configure rate limiting
- [ ] Set up audit log rotation
- [ ] Test IMEI masking in logs
- [ ] Validate permission model

---

## Rollback Strategy

- Management API can be disabled via `eir.management.enabled=false`
- No SS7 functionality affected
- Database schema backward compatible
- Existing equipment checks continue unaffected

---

## Integration Points

### With Existing Code
1. `EquipmentService` - Existing business logic used
2. `EquipmentRepository` - Query/update via existing interface
3. `EirStack` - Lifecycle management
4. `EirConfig` - Configuration integration

### No Changes to
- ✓ EirMapListener
- ✓ Protocol layers (SCTP, M3UA, SCCP, TCAP, MAP)
- ✓ Equipment domain model
- ✓ Existing test suite

---

## Success Criteria

- ✅ REST API endpoints operational
- ✅ Authentication working (JWT + roles)
- ✅ Metrics collected and queryable
- ✅ Audit logs recorded and queryable
- ✅ IMEI masking configurable
- ✅ All tests passing
- ✅ Production-ready security
- ✅ Zero breaking changes to SS7 stack

---

## Next Consideration

After Phase 1-3 complete, optional enhancements:
- **Phase 4:** Web UI Dashboard
- **Phase 5:** WebSocket for real-time metrics
- **Phase 6:** Elasticsearch integration for audit logs
- **Phase 7:** Grafana/Prometheus integration

---

**Ready to proceed with Phase 1A? Confirm and I'll start implementation.**
