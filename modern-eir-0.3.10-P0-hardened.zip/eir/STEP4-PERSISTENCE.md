# Step 4 — Persistence and database integration

## Application configuration

`src/main/resources/application.properties` contains database and operational
settings only. SCTP/M3UA/SCCP/TCAP topology remains in the existing XML files.

Environment variables override the corresponding properties:

- `EIR_DB_ENABLED`
- `EIR_DB_URL`
- `EIR_DB_USER`
- `EIR_DB_PASSWORD`
- `EIR_DB_POOL_SIZE`
- `EIR_DB_CONNECTION_TIMEOUT_MS`
- `EIR_DB_VALIDATION_TIMEOUT_MS`
- `EIR_DB_QUERY_TIMEOUT_SECONDS`

Production database passwords must be supplied through `EIR_DB_PASSWORD`;
no database password is stored in XML.

## Database lifecycle

`EirStack` creates exactly one `Database` instance when persistence is enabled.
`Database` creates exactly one HikariCP `HikariDataSource`, exposes its
`DataSource`, and closes it during application shutdown.

`JdbcEquipmentRepository` receives the `DataSource` by constructor injection
and obtains pooled connections with `dataSource.getConnection()`. It does not
call `DriverManager` and does not create a pool per request.

The configured query timeout is applied to each prepared statement.

## Database outage behavior

HikariCP is configured with `initializationFailTimeout=-1`, so a temporary
database outage does not prevent the EIR process from starting. A failed
repository lookup raises `EquipmentRepositoryException`, which the existing
`EquipmentService` converts to the Step 3 `DATABASE_UNAVAILABLE` decision.
The existing fail-closed MAP policy then returns `blackListed`.

## Schema

`db/schema.sql` creates `equipment_identity` with IMEI, status, timestamps and
optional audit metadata, matching `JdbcEquipmentRepository`.
