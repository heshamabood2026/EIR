# Windows TCP test mode

The project supports two transport modes selected on the command line:

- `sctp`: JDK `com.sun.nio.sctp` transport. Use this on Linux/Unix hosts with SCTP support.
- `tcp`: local RestComm TCP test transport. Use this on Windows when the JDK reports that SCTP is unsupported.

## Start the EIR

From the `eir` directory:

```bat
mvn exec:java -Dexec.mainClass=com.example.eir.EirServerMain -Dexec.args="tcp"
```

The EIR listens on `127.0.0.1:2906`.

## Start the MSC simulator

Open a second command window in the same `eir` directory:

```bat
mvn exec:java -Dexec.mainClass=com.example.eir.MscSimulatorMain -Dexec.args="tcp"
```

The MSC simulator binds `127.0.0.1:2905` and connects to the EIR on `127.0.0.1:2906`.

## Important interoperability note

TCP mode is a **test transport for this EIR + MSC simulator pair**. It is not a standards-compliant replacement for SIGTRAN M3UA over SCTP and should not be used to connect the EIR directly to a real MSC/VLR/HLR that expects SCTP.

The TCP adapter uses a small private frame header to preserve the M3UA payload, virtual stream number, PPID and unordered flag needed by the patched RestComm M3UA layer. Both endpoints in this project understand that framing.

For production SIGTRAN connectivity, run the same project with:

```bat
mvn exec:java -Dexec.mainClass=com.example.eir.EirServerMain -Dexec.args="sctp"
```

on an operating system that provides SCTP to the JDK.
