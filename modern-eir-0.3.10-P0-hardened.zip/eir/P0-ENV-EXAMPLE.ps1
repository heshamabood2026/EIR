# P0 security settings for local/test deployment.
# Do not commit real secrets to source control.
$env:EIR_JWT_SECRET = '<generate-a-random-secret-at-least-32-bytes>'
$env:EIR_BOOTSTRAP_ADMIN_PASSWORD = '<strong-admin-password>'
$env:EIR_BOOTSTRAP_VIEWER_PASSWORD = '<strong-viewer-password>'

# Optional: disable the HTTP management API for pure SS7 testing.
# $env:EIR_MANAGEMENT_ENABLED = 'false'
