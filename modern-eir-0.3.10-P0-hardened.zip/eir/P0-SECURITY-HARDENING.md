# P0 Security Hardening

Implemented in 0.3.10 P0 hardening:

- Standards-compliant three-part JWT using JJWT HS256.
- JWT secret is mandatory when management API is enabled and must be at least 32 UTF-8 bytes.
- Passwords use PBKDF2-HMAC-SHA256 with a random per-password salt.
- Database bootstrap users are opt-in through environment variables; predictable credentials are never created automatically.
- Database password is no longer stored in `application.properties`.
- Dashboard and API test scripts no longer contain default passwords.
- JDBC list query timeout is applied before query execution.
- IMEI masker test corrected to the documented last-four-digits policy.
- Added an opt-in real TCP/M3UA/SCCP/TCAP/MAP CheckIMEI end-to-end test.

## Required environment for management API

Set a strong secret before starting EIR with management enabled:

`EIR_JWT_SECRET=<at-least-32-byte-random-secret>`

For a fresh DB, optionally provision bootstrap accounts once:

`EIR_BOOTSTRAP_ADMIN_PASSWORD=<strong-admin-password>`

`EIR_BOOTSTRAP_VIEWER_PASSWORD=<strong-viewer-password>`

Bootstrap variables are only used when the corresponding username does not already exist. Existing users are not overwritten.

For an existing database created by an older build, existing SHA-256 password hashes are not accepted by the new PBKDF2 verifier. Reset those management-user passwords using the account-management provisioning path or a controlled database migration before enabling management login.

## TCP CheckIMEI E2E

The test binds the configured integration ports 2905/2906 and is therefore opt-in:

`mvn -DEIR_RUN_E2E=true test -Dtest=CheckImeiTcpEndToEndTest`

The test uses an injected in-memory equipment repository, so it does not require MySQL. It validates the actual transport/protocol/application round trip for whitelisted, blacklisted, greylisted, and unknown IMEIs.
