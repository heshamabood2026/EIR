#!/usr/bin/env bash
# P0 security settings for local/test deployment.
# Do not commit real secrets to source control.
export EIR_JWT_SECRET='<generate-a-random-secret-at-least-32-bytes>'
export EIR_BOOTSTRAP_ADMIN_PASSWORD='<strong-admin-password>'
export EIR_BOOTSTRAP_VIEWER_PASSWORD='<strong-viewer-password>'

# Optional: disable the HTTP management API for pure SS7 testing.
# export EIR_MANAGEMENT_ENABLED=false
