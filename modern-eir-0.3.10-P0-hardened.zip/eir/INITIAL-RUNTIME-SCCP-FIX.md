# Initial/runtime lifecycle + SCCP routing fix

## Initial/runtime lifecycle

`config/initial/<ROLE>/` is the authoritative configuration.
`config/runtime/<ROLE>/` is a fresh working copy created at each process start.
jSS7 reads and mutates only the runtime copy. Runtime lifecycle changes such as
`MSC_ASP started=true` are therefore not written into the initial templates.

## SCCP routing fix

The simulator-created MAP dialog previously used
`ROUTING_BASED_ON_GLOBAL_TITLE`. In this standalone build the SCCP stack is
constructed with a null `Ss7ExtInterface`, and the runtime explicitly reported
that GT routing is unsupported.

The simulator now uses `DPC+SSN routing indicator` while retaining the configured
point codes and SSNs:

MSC 1/8 -> EIR 2/146

This matches the SCCP SAP/DPC XML topology and removes the dependency on GT
translation for the lab CheckIMEI path.
