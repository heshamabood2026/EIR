# Step 3 — EIR Domain Model and Policy

## Domain model

`Equipment` now contains:
- IMEI
- `EirEquipmentStatus`
- `createdAt`
- `updatedAt`
- optional immutable audit metadata

Statuses:
- `WHITELISTED`
- `BLACKLISTED`
- `GREYLISTED`
- `UNKNOWN`

Invalid IMEI is not a persisted equipment status. It becomes an `UNKNOWN`
decision with reason `INVALID_IMEI`.

## MAP response policy

This implementation uses a fail-closed CheckIMEI policy:

| Condition | Domain decision | MAP response |
|---|---|---|
| WHITELISTED | WHITELISTED | `whiteListed` |
| BLACKLISTED | BLACKLISTED | `blackListed` |
| GREYLISTED | GREYLISTED | `blackListed` |
| UNKNOWN / not found | UNKNOWN | `blackListed` |
| Invalid IMEI | UNKNOWN + `INVALID_IMEI` | `blackListed` |
| Database outage | UNKNOWN + `DATABASE_UNAVAILABLE` | `blackListed` |

Only explicitly whitelisted equipment is accepted.

## Adapter boundary

`EirMapListener` remains responsible for converting the protocol-neutral
`EirMapResponse` to RestComm MAP `EquipmentStatus`. The domain policy has no
dependency on MAP classes.

## Compatibility

The three existing simulator identities remain:
- `333333334444440` — WHITELISTED
- `490154203237518` — WHITELISTED
- `333333334444442` — BLACKLISTED

The existing SS7/SCTP/M3UA/SCCP/TCAP configuration was not changed.
