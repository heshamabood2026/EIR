# Runtime fixes 0.2.4-runtimefix2

## EIR

The server-side association is created but not started until after the
RestComm M3UA ASP factory has been created. The M3UA implementation installs
the required `AssociationListener`; starting the association before that
produces `NullPointerException: AssociationListener is null`.

The EIR runs as the server/IPSP side and does not call `startAsp()`.

## MSC

The MSC does not replace the M3UA `AssociationListener`. It wraps the listener
installed by `AspFactoryImpl` and delegates every callback to it.

This is critical: replacing that listener prevents M3UA from receiving the
transport `communicationUp` callback and can leave its ASP FSM in `UP_SENT`.

The simulator waits for transport communication-up, then calls:

`m3ua.startAsp("MSC_ASP")`

and only then sends CheckIMEI.

## Test

Start EIR first:

mvn -pl eir exec:java -Dexec.mainClass=com.example.eir.EirServerMain

Then MSC:

mvn -pl eir exec:java -Dexec.mainClass=com.example.eir.MscSimulatorMain

Expected order:

EIR:
  Server started
  EIR_ASSOC started

MSC:
  MSC_ASSOC TCP connected
  MSC_ASSOC communication UP
  M3UA ASPUP/ASPAC
  CheckIMEI requests
  CheckIMEI responses


## XML lifecycle isolation

The XML configuration is separated into immutable initial templates and
runtime working copies:

`config/initial/<ROLE>/` -> `config/runtime/<ROLE>/`

The runtime directory is refreshed from the initial directory on every process
start, before jSS7 loads any management configuration. jSS7 is therefore free
to persist runtime lifecycle state without changing the authoritative initial
templates. In particular, the MSC M3UA ASP may change its runtime
`started` state; that change is intentionally confined to `config/runtime/MSC/`.
