# SCTP multihoming in Modern EIR 0.3.10

SCTP failover now uses **one SCTP association with multiple IP addresses**. This is intentionally different from the TCP primary/backup implementation.

## Configuration

For a client association:

```xml
<association name="MSC01_ASSOC" mode="client"
    localAddress="10.10.10.20" localPort="2905"
    backupLocalAddress="10.10.10.21" backupLocalPort="2905"
    peerAddress="10.20.20.20" peerPort="2905"
    backupPeerAddress="10.20.20.21" backupPeerPort="2905"/>
```

The two local addresses are bound to the same `SctpChannel`. The peer's alternate addresses are learned from the SCTP INIT/INIT-ACK exchange. `backupPeerAddress` is therefore an expected/validation address, not a second `connect()` attempt.

For a server association, the EIR server binds the primary local address and then adds the backup local address to the same `SctpServerChannel`.

## Important constraints

* Primary and backup addresses for SCTP multihoming use the **same SCTP port**.
* Both local addresses must exist on the same host and be routable.
* The remote endpoint must actually advertise its alternate address; configuring `backupPeerAddress` alone cannot make a non-multihomed remote SCTP node multihomed.
* No second M3UA ASP/AS is created for the backup path.
* TCP remains unchanged and continues to use separate primary/backup TCP connections.

## Failover model

```text
One M3UA ASP/AS
      |
One SCTP association
      |
  +---+------------------+
  |                      |
Primary path          Backup path
10.10.10.20:2905     10.10.10.21:2905
  |                      |
  +------ SCTP ----------+
         path failover
```

On Windows, the JDK SCTP provider may report `SCTP not supported on this platform`. Use Linux/another SCTP-capable host for the live multihoming test; the project can still be compiled and its configuration tests run on Windows.
