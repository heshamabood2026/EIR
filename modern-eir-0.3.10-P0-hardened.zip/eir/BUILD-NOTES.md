# Build notes — RestComm jSS7 transport modes

## Transport boundary

The EIR and patched RestComm M3UA modules use `org.restcomm.protocols.ss7.transport` rather
than the historical external SCTP API.

Two implementations are available:

- `RestCommSctpManagement` — JDK `com.sun.nio.sctp` implementation for production SCTP hosts.
- `RestCommTcpManagement` — ordinary Java TCP implementation for Windows/local integration tests.

## TCP test mode

The TCP implementation preserves M3UA payload boundaries and the transport metadata needed
by M3UA (PPID, virtual stream number and unordered flag) using a small private frame header.
Both the included EIR and MSC simulator understand this framing.

This mode is deliberately a test harness. It does not claim to implement M3UA over TCP for
interoperability with arbitrary SIGTRAN equipment.

## M3UA changes

The supplied RestComm jSS7 M3UA source was patched so that its transport references use the
new transport-neutral package. M3UA protocol logic, SCCP, TCAP and MAP remain RestComm jSS7.

## Runtime order

1. Create the selected transport management implementation.
2. Start transport management.
3. Configure the EIR server or MSC client association.
4. Start the EIR TCP/SCTP listener when running the EIR.
5. Start RestComm jSS7 M3UA.
6. Start SCCP, TCAP and MAP.
7. M3UA starts the configured ASP/association according to the XML profile.

## Validation

Build:

```text
mvn clean compile -U
```

Verify removal of the old SCTP transport:

```bat
mvn dependency:tree | findstr /I "sctp-api sctp-impl protocols.sctp"
```

and source references:

```bat
findstr /S /I "org.mobicents.protocols.sctp org.mobicents.protocols.api" *.java
```

Neither command should find the removed SCTP transport references in this project.

- 0.3.3 fix: Windows TCP transport classes are compiled from the EIR source tree directly, avoiding Maven source-root/incremental compilation ambiguity in vendor/restcomm-sctp.
