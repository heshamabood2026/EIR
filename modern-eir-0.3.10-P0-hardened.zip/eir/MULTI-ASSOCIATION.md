# Multi-association EIR — 0.3.4

This release adds first-class multi-association configuration to the EIR without changing
MAP/TCAP business logic.

## Supported topology

One EIR process can now configure multiple transport associations. Each association has:

- transport mode: `server` or `client`
- local address/port
- peer address/port
- association name
- M3UA ASP name
- M3UA AS name
- routing context
- ASP ID
- remote point code / SSN
- M3UA route DPC

### Multiple associations to one MSC

Use separate association names and endpoints. For redundant paths to the same MSC, use the
same `asName` so the associations become multiple ASPs of one M3UA AS. Use the same remote
point code and route DPC for those paths.

### Multiple MSCs

Normally give each MSC a distinct `asName` and `routeDpc`/remote SPC. The generated M3UA
configuration creates one AS per distinct `asName` and a route for each DPC. SCCP resources
and MTP3 destination mappings are generated for all configured remote point codes.

### Server and client simultaneously

The EIR process can mix `mode="server"` and `mode="client"` associations. Server mode
creates a listening endpoint and waits for the MSC. Client mode creates an outgoing
association and is explicitly started after M3UA installs its association listener.

## Configuration

Edit:

`config/initial/EIR/EIR-associations.xml`

Example:

```xml
<associations>
    <association name="MSC01_ASSOC"
                 mode="server"
                 localAddress="10.10.0.10"
                 localPort="2906"
                 peerAddress="10.20.0.1"
                 peerPort="2905"
                 serverName="MSC01_SERVER"
                 aspName="MSC01_ASP"
                 asName="MSC01_AS"
                 routingContext="100"
                 aspid="3"
                 remoteSpc="1"
                 remoteSsn="8"
                 routeDpc="1"
                 started="true"/>

    <association name="MSC02_ASSOC"
                 mode="server"
                 localAddress="10.10.0.10"
                 localPort="2907"
                 peerAddress="10.20.0.2"
                 peerPort="2905"
                 serverName="MSC02_SERVER"
                 aspName="MSC02_ASP"
                 asName="MSC02_AS"
                 routingContext="101"
                 aspid="4"
                 remoteSpc="2"
                 remoteSsn="8"
                 routeDpc="2"
                 started="true"/>
</associations>
```

For Windows testing use `tcp` and distinct local ports. For production use `sctp` on an
SCTP-capable operating system.


### MSC simulator configuration

The MSC simulator now loads `config/initial/MSC/MSC-associations.xml` rather than the EIR association file. This prevents the simulator from looking for `config/runtime/MSC/EIR-SCTP_sctp.xml`. The simulator can therefore be run independently with `mvn exec:java -Dexec.mainClass=com.example.eir.MscSimulatorMain -Dexec.args="tcp"`.
## Unit tests

`MultiAssociationConfigurationTest` covers the two multi-association topologies:

1. **Same MSC, multiple transport ports** — two distinct transport associations use different EIR listener ports but the same peer IP/MSC point code and the same M3UA AS. The generated configuration must contain two ASPs, one AS, and one DPC route.
2. **Different MSC nodes** — two associations use different peer addresses/point codes and separate M3UA AS names. The generated configuration must contain two ASPs, two AS entries, and two DPC routes.

Run all tests with:

```bat
mvn clean test -U
```
