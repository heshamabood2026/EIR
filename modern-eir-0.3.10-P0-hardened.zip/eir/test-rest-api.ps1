# Phase 1B REST API Test Script (Windows PowerShell)
# Tests all authentication, metrics, and audit endpoints

$BASE_URL = "http://localhost:8080/api"
$ADMIN_USER = "admin"
$ADMIN_PASS = $env:EIR_BOOTSTRAP_ADMIN_PASSWORD
$VIEWER_USER = "viewer"
$VIEWER_PASS = $env:EIR_BOOTSTRAP_VIEWER_PASSWORD

Write-Host "=========================================" -ForegroundColor Green
Write-Host "Phase 1B: REST API Endpoint Tests" -ForegroundColor Green
Write-Host "=========================================" -ForegroundColor Green
Write-Host ""

# Helper function to make requests
function Invoke-ApiRequest {
    param(
        [string]$Method,
        [string]$Path,
        [string]$Body,
        [string]$Token
    )
    
    $headers = @{"Content-Type" = "application/json"}
    if ($Token) {
        $headers["Authorization"] = "Bearer $Token"
    }
    
    $url = "$BASE_URL$Path"
    
    try {
        if ($Body) {
            $response = Invoke-RestMethod -Uri $url -Method $Method -Headers $headers -Body $Body
        } else {
            $response = Invoke-RestMethod -Uri $url -Method $Method -Headers $headers
        }
        return $response
    } catch {
        Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
        return $null
    }
}

# Test 1: Health Check (no auth required)
Write-Host "Test 1: GET /api/metrics/health (no auth)" -ForegroundColor Cyan
try {
    $response = Invoke-RestMethod -Uri "$BASE_URL/metrics/health" -Method GET -Headers @{"Content-Type" = "application/json"}
    Write-Host ($response | ConvertTo-Json) -ForegroundColor White
} catch {
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

# Test 2: Admin Login
Write-Host "Test 2: POST /api/auth/login (admin)" -ForegroundColor Cyan
$loginBody = @{
    username = $ADMIN_USER
    password = $ADMIN_PASS
} | ConvertTo-Json

try {
    $response = Invoke-RestMethod -Uri "$BASE_URL/auth/login" -Method POST `
        -Headers @{"Content-Type" = "application/json"} -Body $loginBody
    Write-Host ($response | ConvertTo-Json) -ForegroundColor White
    $ADMIN_TOKEN = $response.token
    Write-Host "Admin Token: $ADMIN_TOKEN" -ForegroundColor Yellow
} catch {
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

# Test 3: Viewer Login
Write-Host "Test 3: POST /api/auth/login (viewer)" -ForegroundColor Cyan
$viewerLoginBody = @{
    username = $VIEWER_USER
    password = $VIEWER_PASS
} | ConvertTo-Json

try {
    $response = Invoke-RestMethod -Uri "$BASE_URL/auth/login" -Method POST `
        -Headers @{"Content-Type" = "application/json"} -Body $viewerLoginBody
    Write-Host ($response | ConvertTo-Json) -ForegroundColor White
    $VIEWER_TOKEN = $response.token
    Write-Host "Viewer Token: $VIEWER_TOKEN" -ForegroundColor Yellow
} catch {
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

# Test 4: Invalid Login
Write-Host "Test 4: POST /api/auth/login (invalid credentials)" -ForegroundColor Cyan
$invalidBody = @{
    username = "invalid"
    password = "wrong"
} | ConvertTo-Json

try {
    $response = Invoke-RestMethod -Uri "$BASE_URL/auth/login" -Method POST `
        -Headers @{"Content-Type" = "application/json"} -Body $invalidBody -ErrorAction Stop
    Write-Host ($response | ConvertTo-Json) -ForegroundColor White
} catch {
    Write-Host "Expected error: $($_.Exception.Message)" -ForegroundColor Yellow
}
Write-Host ""

# Test 5: Equipment Metrics (requires auth)
Write-Host "Test 5: GET /api/metrics/equipment (with admin token)" -ForegroundColor Cyan
if ($ADMIN_TOKEN) {
    try {
        $response = Invoke-RestMethod -Uri "$BASE_URL/metrics/equipment" -Method GET `
            -Headers @{"Authorization" = "Bearer $ADMIN_TOKEN"; "Content-Type" = "application/json"}
        Write-Host ($response | ConvertTo-Json) -ForegroundColor White
    } catch {
        Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    }
} else {
    Write-Host "Skipped: No admin token" -ForegroundColor Yellow
}
Write-Host ""

# Test 6: Equipment Metrics without token
Write-Host "Test 6: GET /api/metrics/equipment (no token - should fail)" -ForegroundColor Cyan
try {
    $response = Invoke-RestMethod -Uri "$BASE_URL/metrics/equipment" -Method GET `
        -Headers @{"Content-Type" = "application/json"} -ErrorAction Stop
    Write-Host ($response | ConvertTo-Json) -ForegroundColor White
} catch {
    Write-Host "Expected error: $($_.Exception.Message)" -ForegroundColor Yellow
}
Write-Host ""

# Test 7: Database Metrics
Write-Host "Test 7: GET /api/metrics/database (with viewer token)" -ForegroundColor Cyan
if ($VIEWER_TOKEN) {
    try {
        $response = Invoke-RestMethod -Uri "$BASE_URL/metrics/database" -Method GET `
            -Headers @{"Authorization" = "Bearer $VIEWER_TOKEN"; "Content-Type" = "application/json"}
        Write-Host ($response | ConvertTo-Json) -ForegroundColor White
    } catch {
        Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    }
} else {
    Write-Host "Skipped: No viewer token" -ForegroundColor Yellow
}
Write-Host ""

# Test 8: Pool Metrics
Write-Host "Test 8: GET /api/metrics/pool (with admin token)" -ForegroundColor Cyan
if ($ADMIN_TOKEN) {
    try {
        $response = Invoke-RestMethod -Uri "$BASE_URL/metrics/pool" -Method GET `
            -Headers @{"Authorization" = "Bearer $ADMIN_TOKEN"; "Content-Type" = "application/json"}
        Write-Host ($response | ConvertTo-Json) -ForegroundColor White
    } catch {
        Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    }
} else {
    Write-Host "Skipped: No admin token" -ForegroundColor Yellow
}
Write-Host ""

# Test 9: Audit Logs Query
Write-Host "Test 9: GET /api/audit/logs (with viewer token)" -ForegroundColor Cyan
if ($VIEWER_TOKEN) {
    try {
        $response = Invoke-RestMethod -Uri "$BASE_URL/audit/logs?limit=10" -Method GET `
            -Headers @{"Authorization" = "Bearer $VIEWER_TOKEN"; "Content-Type" = "application/json"}
        Write-Host ($response | ConvertTo-Json) -ForegroundColor White
    } catch {
        Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    }
} else {
    Write-Host "Skipped: No viewer token" -ForegroundColor Yellow
}
Write-Host ""

# Test 10: Audit Metrics
Write-Host "Test 10: GET /api/audit/metrics (with admin token)" -ForegroundColor Cyan
if ($ADMIN_TOKEN) {
    try {
        $response = Invoke-RestMethod -Uri "$BASE_URL/audit/metrics" -Method GET `
            -Headers @{"Authorization" = "Bearer $ADMIN_TOKEN"; "Content-Type" = "application/json"}
        Write-Host ($response | ConvertTo-Json) -ForegroundColor White
    } catch {
        Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    }
} else {
    Write-Host "Skipped: No admin token" -ForegroundColor Yellow
}
Write-Host ""

# Test 11: Token Refresh
Write-Host "Test 11: POST /api/auth/refresh (with valid token)" -ForegroundColor Cyan
if ($ADMIN_TOKEN) {
    try {
        $response = Invoke-RestMethod -Uri "$BASE_URL/auth/refresh" -Method POST `
            -Headers @{"Authorization" = "Bearer $ADMIN_TOKEN"; "Content-Type" = "application/json"}
        Write-Host ($response | ConvertTo-Json) -ForegroundColor White
        if ($response.token) {
            Write-Host "New token generated: $(($response.token).Substring(0, 20))..." -ForegroundColor Yellow
        }
    } catch {
        Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    }
} else {
    Write-Host "Skipped: No admin token" -ForegroundColor Yellow
}
Write-Host ""

# Test 12: Logout
Write-Host "Test 12: POST /api/auth/logout (with valid token)" -ForegroundColor Cyan
if ($ADMIN_TOKEN) {
    try {
        $response = Invoke-RestMethod -Uri "$BASE_URL/auth/logout" -Method POST `
            -Headers @{"Authorization" = "Bearer $ADMIN_TOKEN"; "Content-Type" = "application/json"}
        Write-Host ($response | ConvertTo-Json) -ForegroundColor White
    } catch {
        Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    }
} else {
    Write-Host "Skipped: No admin token" -ForegroundColor Yellow
}
Write-Host ""

Write-Host "=========================================" -ForegroundColor Green
Write-Host "Tests Complete" -ForegroundColor Green
Write-Host "=========================================" -ForegroundColor Green
