# EIR / MSC SS7 configuration

The configuration supports SCTP and TCP test mode.

- `EIR-SCTP_sctp.xml`: EIR listens on `127.0.0.1:2906` and accepts the configured MSC peer.
- `MSC-SCTP_sctp.xml`: MSC simulator connects from `127.0.0.1:2905` to the EIR listener.
- M3UA, SCCP, TCAP and MAP configuration remains XML-driven and is consumed by RestComm jSS7.

The command-line transport selects `sctp` or `tcp`; the same endpoint XML supplies addresses and ports.
SCTP uses the JDK `com.sun.nio.sctp` API. TCP mode uses the local RestComm TCP test transport and is
intended for Windows/local EIR-to-MSC simulator testing. It is not a standards-compliant M3UA-over-TCP
interoperability layer for real SIGTRAN peers.
