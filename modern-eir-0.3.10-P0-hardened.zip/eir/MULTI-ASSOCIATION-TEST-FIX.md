# 0.3.6 Multi-Association Test Fix

The 0.3.5 multi-association tests used a broad substring assertion for
`remoteSpc`, which counted the same SPC in both the `<remoteSsns>` and
`<remoteSpcs>` sections of the generated SCCP resource XML.

The implementation was not changed for this fix. The tests now scope the
assertion to the `<remoteSpcs>` value by matching `remoteSpcFlag`, so each
remote SPC is counted exactly once.

Expected topologies:

1. Same MSC, two transport associations:
   - 2 transport associations / ASP factories
   - 1 M3UA AS
   - 1 DPC route
   - 1 remote SPC entry

2. Two different MSC nodes:
   - 2 transport associations / ASP factories
   - 2 M3UA ASs
   - 2 DPC routes
   - 2 remote SPC entries
