# Modern EIR 0.3.9

## SCTP multihoming API fix

- Promoted the 9-argument SCTP multihoming `addAssociation(...)` overload into the RestComm Java-SCTP `Management` contract.
- This removes the EIR-level type mismatch when the transport is referenced through `Management`.
- The overload models one SCTP association with primary/secondary local addresses and primary/secondary peer addresses.
- The existing 5-argument `addAssociation(...)` API remains unchanged for backward compatibility.
- TCP behavior is unchanged.

## Platform note

The Windows JDK normally does not provide a usable SCTP provider. The SCTP unit tests validate configuration and management semantics, while live SCTP transport testing should be performed on a platform with SCTP support.
