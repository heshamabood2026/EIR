# TCP primary/backup endpoint failover

Version 0.3.7 adds primary/backup endpoint support to the Windows TCP transport.

## Client mode

`peerAddress` + `peerPort` are the primary remote endpoint.
`backupPeerAddress` + `backupPeerPort` are optional. A client association:

1. tries the primary endpoint first;
2. if it fails, tries the backup endpoint;
3. if both fail, waits `connectDelay`;
4. retries from the primary endpoint.

The logical association and M3UA ASP/AS identity do not change during failover.

## Server mode

`localAddress` + `localPort` are the primary EIR listening endpoint.
`backupLocalAddress` + `backupLocalPort` optionally add a second listener for the
same logical association. The same transport association object is registered on both
listeners, so an MSC can reconnect to either EIR endpoint without creating a second
M3UA ASP/AS configuration.

For inbound TCP, the remote source port is normally ephemeral, so peer matching uses
the configured peer IP addresses rather than assuming the configured remote port is
the TCP source port.

## Example

MSC simulator (client):

```xml
<association name="MSC_ASSOC" mode="client"
    localAddress="127.0.0.1" localPort="2905"
    peerAddress="127.0.0.1" peerPort="2906"
    backupPeerAddress="127.0.0.1" backupPeerPort="2907"
    .../>
```

EIR (server):

```xml
<association name="MSC01_ASSOC" mode="server"
    localAddress="127.0.0.1" localPort="2906"
    backupLocalAddress="127.0.0.1" backupLocalPort="2907"
    peerAddress="127.0.0.1" peerPort="2905"
    .../>
```

This gives a Windows test topology of primary EIR port 2906 and backup EIR port 2907.
The SCTP implementation is intentionally unchanged in this version and will be handled
as a separate follow-up.
