package com.example.eir.audit;

/**
 * IMEI masking utility for operational safety.
 * 
 * Masks IMEIs in logs and audit records according to configured policy.
 * Supports three modes:
 * - NONE: No masking (full IMEI shown)
 * - PARTIAL: Show last 4 digits only (e.g., ****3344)
 * - FULL: Completely hide (e.g., ****-MASKED-****)
 * 
 * Example usage:
 * String masked = ImeiMasker.mask("333333334444440", "PARTIAL");
 * // Result: "****334444440" (shows last 7)
 */
public final class ImeiMasker {
    
    private final MaskMode mode;
    
    public enum MaskMode {
        NONE,      // Full IMEI shown
        PARTIAL,   // Last 4 digits shown
        FULL       // Complete masking
    }
    
    public ImeiMasker(String modeString) {
        this.mode = parseMaskMode(modeString);
    }
    
    public ImeiMasker(MaskMode mode) {
        this.mode = mode;
    }
    
    /**
     * Mask IMEI according to configured policy.
     */
    public String mask(String imei) {
        if (imei == null || imei.isBlank()) {
            return "INVALID";
        }
        
        return switch (mode) {
            case NONE -> imei;
            case PARTIAL -> maskPartial(imei);
            case FULL -> "****-MASKED-****";
        };
    }
    
    /**
     * Mask keeping last 4 digits visible.
     * Example: "333333334444440" -> "***333444"
     */
    private String maskPartial(String imei) {
        if (imei.length() <= 4) {
            return "*".repeat(imei.length());
        }
        
        int maskLength = imei.length() - 4;
        String masked = "*".repeat(maskLength);
        String visible = imei.substring(maskLength);
        return masked + visible;
    }
    
    /**
     * Parse mask mode from string (case-insensitive).
     */
    private static MaskMode parseMaskMode(String modeString) {
        if (modeString == null || modeString.isBlank()) {
            return MaskMode.PARTIAL; // Default
        }
        
        return switch (modeString.toUpperCase()) {
            case "NONE" -> MaskMode.NONE;
            case "FULL" -> MaskMode.FULL;
            default -> MaskMode.PARTIAL;
        };
    }
    
    public MaskMode getMode() {
        return mode;
    }
}
