package com.example.eir.management;

import com.example.eir.auth.JwtTokenProvider;
import com.example.eir.auth.Role;
import com.example.eir.auth.User;
import com.example.eir.auth.UserRepository;
import com.sun.net.httpserver.HttpExchange;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Management handler for creating and listing dashboard users.
 */
public final class AccountsManagementHandler {
    private final JwtTokenProvider tokenProvider;
    private final UserRepository userRepository;

    public AccountsManagementHandler(JwtTokenProvider tokenProvider, UserRepository userRepository) {
        this.tokenProvider = tokenProvider;
        this.userRepository = userRepository;
    }

    public void handleListUsers(HttpExchange exchange) throws Exception {
        HttpRequest request = new HttpRequest(exchange);
        HttpResponse response = new HttpResponse(exchange);
        if (!"GET".equals(request.getMethod())) {
            response.error(405, "Method not allowed").send();
            return;
        }
        if (!authorized(request, response, Role.SUPER_ADMIN)) {
            return;
        }
        response.status(200).json(toJson(userRepository.findAll())).send();
    }

    public void handleCreateUser(HttpExchange exchange) throws Exception {
        HttpRequest request = new HttpRequest(exchange);
        HttpResponse response = new HttpResponse(exchange);
        if (!"POST".equals(request.getMethod())) {
            response.error(405, "Method not allowed").send();
            return;
        }
        if (!authorized(request, response, Role.SUPER_ADMIN)) {
            return;
        }

        String body = request.getBody();
        String username = extractJsonField(body, "username");
        String password = extractJsonField(body, "password");
        String roleName = extractJsonField(body, "role");
        if (username == null || password == null || roleName == null) {
            response.error(400, "username, password, and role are required").send();
            return;
        }

        Role role = Role.fromValue(roleName);
        if (userRepository.existsByUsername(username)) {
            response.error(409, "Username already exists").send();
            return;
        }

        String passwordHash = com.example.eir.auth.PasswordHasher.hash(password);
        User user = User.create(username, passwordHash, role);
        userRepository.save(user);
        response.status(201).json(toJson(user)).send();
    }

    public void handleDeleteUser(HttpExchange exchange, String username) throws Exception {
        HttpRequest request = new HttpRequest(exchange);
        HttpResponse response = new HttpResponse(exchange);
        if (!"DELETE".equals(request.getMethod())) {
            response.error(405, "Method not allowed").send();
            return;
        }
        if (!authorized(request, response, Role.SUPER_ADMIN)) {
            return;
        }
        if ("admin".equalsIgnoreCase(username)) {
            response.error(400, "Cannot delete the bootstrap admin account").send();
            return;
        }
        userRepository.deleteByUsername(username);
        response.status(200).json("{\"message\":\"User deleted\"}").send();
    }

    private boolean authorized(HttpRequest request, HttpResponse response, Role requiredRole) throws Exception {
        String token = request.getAuthToken();
        if (token == null || token.isBlank()) {
            response.error(401, "Missing bearer token").send();
            return false;
        }
        String username = tokenProvider.validateToken(token);
        if (username == null) {
            response.error(401, "Invalid or expired token").send();
            return false;
        }
        Role userRole = tokenProvider.extractRole(token);
        if (userRole == null || !userRole.canAccess(requiredRole)) {
            response.error(403, "Forbidden").send();
            return false;
        }
        return true;
    }

    private static String toJson(List<User> users) {
        if (users == null || users.isEmpty()) {
            return "[]";
        }
        List<String> items = new ArrayList<>();
        for (User user : users) {
            items.add(toJson(user));
        }
        return "[" + String.join(",", items) + "]";
    }

    private static String toJson(User user) {
        return String.format(Locale.ROOT,
                "{\"username\":\"%s\",\"role\":\"%s\",\"enabled\":%s}",
                user.getUsername(),
                user.getRole().name(),
                user.isEnabled());
    }

    private static String extractJsonField(String json, String fieldName) {
        if (json == null || json.isBlank()) {
            return null;
        }
        String pattern = "\"" + fieldName + "\":\"";
        int start = json.indexOf(pattern);
        if (start < 0) {
            return null;
        }
        start += pattern.length();
        int end = json.indexOf('"', start);
        if (end < 0) {
            return null;
        }
        return json.substring(start, end);
    }

}
