package com.example.eir.domain;

/**
 * Protocol-neutral outcome used by the MAP adapter.
 */
public enum EirMapResponse {
    WHITELISTED,
    BLACKLISTED
}
