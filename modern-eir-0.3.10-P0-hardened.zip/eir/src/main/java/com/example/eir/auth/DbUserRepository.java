package com.example.eir.auth;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import javax.sql.DataSource;

/**
 * Database-backed user repository for management authentication.
 */
public final class DbUserRepository implements UserRepository {
    private final DataSource dataSource;

    public DbUserRepository(DataSource dataSource) {
        this.dataSource = dataSource;
        initializeSchema();
        ensureBootstrapUsers();
    }

    @Override
    public void save(User user) {
        String sql = "INSERT INTO management_users (username, password_hash, role_name, enabled, created_at, updated_at) "
                + "VALUES (?, ?, ?, ?, ?, ?) "
                + "ON DUPLICATE KEY UPDATE password_hash = VALUES(password_hash), role_name = VALUES(role_name), "
                + "enabled = VALUES(enabled), updated_at = VALUES(updated_at)";

        try (Connection c = dataSource.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPasswordHash());
            ps.setString(3, user.getRole().name());
            ps.setBoolean(4, user.isEnabled());
            ps.setTimestamp(5, Timestamp.from(user.getCreatedAt() != null ? user.getCreatedAt() : Instant.now()));
            ps.setTimestamp(6, Timestamp.from(Instant.now()));
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to save management user", e);
        }
    }

    @Override
    public Optional<User> findByUsername(String username) {
        String sql = "SELECT username, password_hash, role_name, enabled, created_at, updated_at FROM management_users WHERE username = ?";
        try (Connection c = dataSource.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return Optional.empty();
                }
                return Optional.of(readUser(rs));
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to load management user", e);
        }
    }

    @Override
    public List<User> findAll() {
        String sql = "SELECT username, password_hash, role_name, enabled, created_at, updated_at FROM management_users ORDER BY username";
        List<User> users = new ArrayList<>();
        try (Connection c = dataSource.getConnection(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                users.add(readUser(rs));
            }
            return users;
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to list management users", e);
        }
    }

    @Override
    public void deleteByUsername(String username) {
        String sql = "DELETE FROM management_users WHERE username = ?";
        try (Connection c = dataSource.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to delete management user", e);
        }
    }

    @Override
    public boolean existsByUsername(String username) {
        return findByUsername(username).isPresent();
    }

    @Override
    public Optional<User> authenticate(String username, String password) {
        Optional<User> user = findByUsername(username);
        if (user.isEmpty() || !user.get().isEnabled()) {
            return Optional.empty();
        }
        if (verifyPassword(password, user.get().getPasswordHash())) {
            return user;
        }
        return Optional.empty();
    }

    private User readUser(ResultSet rs) throws SQLException {
        String username = rs.getString("username");
        String passwordHash = rs.getString("password_hash");
        Role role = Role.fromValue(rs.getString("role_name"));
        boolean enabled = rs.getBoolean("enabled");
        Timestamp createdAt = rs.getTimestamp("created_at");
        Timestamp updatedAt = rs.getTimestamp("updated_at");
        return new User(username, passwordHash, role, enabled,
                createdAt == null ? Instant.now() : createdAt.toInstant(),
                updatedAt == null ? null : updatedAt.toInstant());
    }

    private void initializeSchema() {
        String sqlRoles = "CREATE TABLE IF NOT EXISTS management_roles ("
                + "role_name VARCHAR(64) NOT NULL PRIMARY KEY, "
                + "description VARCHAR(255) NOT NULL)";
        String sqlUsers = "CREATE TABLE IF NOT EXISTS management_users ("
                + "username VARCHAR(64) NOT NULL PRIMARY KEY, "
                + "password_hash VARCHAR(255) NOT NULL, "
                + "role_name VARCHAR(64) NOT NULL, "
                + "enabled TINYINT(1) NOT NULL DEFAULT 1, "
                + "created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, "
                + "updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, "
                + "FOREIGN KEY (role_name) REFERENCES management_roles(role_name))";

        try (Connection c = dataSource.getConnection();
             PreparedStatement rolesStmt = c.prepareStatement(sqlRoles);
             PreparedStatement usersStmt = c.prepareStatement(sqlUsers)) {
            rolesStmt.executeUpdate();
            usersStmt.executeUpdate();
            seedRoles();
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to initialize management DB schema", e);
        }
    }

    private void seedRoles() {
        String sql = "INSERT INTO management_roles (role_name, description) VALUES (?, ?) ON DUPLICATE KEY UPDATE description = VALUES(description)";
        Role[] roles = Role.values();
        try (Connection c = dataSource.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            for (Role role : roles) {
                ps.setString(1, role.name());
                ps.setString(2, role.getDescription());
                ps.addBatch();
            }
            ps.executeBatch();
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to seed management roles", e);
        }
    }

    private void ensureBootstrapUsers() {
        String adminPassword = System.getenv("EIR_BOOTSTRAP_ADMIN_PASSWORD");
        String viewerPassword = System.getenv("EIR_BOOTSTRAP_VIEWER_PASSWORD");

        // Bootstrap accounts are opt-in. Never create predictable credentials
        // automatically on every startup. Existing users are left untouched.
        if (adminPassword != null && !adminPassword.isBlank() && !existsByUsername("admin")) {
            save(User.create("admin", PasswordHasher.hash(adminPassword), Role.SUPER_ADMIN));
        }
        if (viewerPassword != null && !viewerPassword.isBlank() && !existsByUsername("viewer")) {
            save(User.create("viewer", PasswordHasher.hash(viewerPassword), Role.VIEWER));
        }
    }

    private static boolean verifyPassword(String password, String hash) {
        return PasswordHasher.verify(password, hash);
    }

}
