package com.example.eir.management;

import com.example.eir.auth.JwtTokenProvider;
import com.example.eir.auth.Role;
import com.sun.net.httpserver.HttpExchange;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Reads and updates the application properties and XML configuration files.
 */
public final class ConfigFilesHandler {
    private final JwtTokenProvider tokenProvider;

    public ConfigFilesHandler(JwtTokenProvider tokenProvider) {
        this.tokenProvider = tokenProvider;
    }

    public void handleProperties(HttpExchange exchange) throws Exception {
        HttpRequest request = new HttpRequest(exchange);
        HttpResponse response = new HttpResponse(exchange);
        if (!authorized(request, response, Role.SUPER_ADMIN)) {
            return;
        }

        if ("GET".equals(request.getMethod())) {
            response.status(200).json(readAppProperties()).send();
            return;
        }
        if ("PUT".equals(request.getMethod())) {
            String body = request.getBody();
            String content = extractJsonField(body, "content");
            if (content == null) {
                response.error(400, "content is required").send();
                return;
            }
            writeAppProperties(content);
            response.status(200).json("{\"message\":\"application.properties updated\"}").send();
            return;
        }
        response.error(405, "Method not allowed").send();
    }

    public void handleEirConfig(HttpExchange exchange) throws Exception {
        handleConfigList(exchange, "EIR");
    }

    public void handleMscConfig(HttpExchange exchange) throws Exception {
        handleConfigList(exchange, "MSC");
    }

    public void handleConfigFile(HttpExchange exchange, String role, String path) throws Exception {
        HttpRequest request = new HttpRequest(exchange);
        HttpResponse response = new HttpResponse(exchange);
        if (!authorized(request, response, Role.SUPER_ADMIN)) {
            return;
        }
        Path file = resolveFile(role, path);
        if (file == null || !Files.exists(file)) {
            response.error(404, "File not found").send();
            return;
        }
        if ("GET".equals(request.getMethod())) {
            String content = Files.readString(file, StandardCharsets.UTF_8);
            response.status(200).json("{\"path\":\"" + relativePath(file.toString()) + "\",\"content\":" + jsonEscape(content) + "}").send();
            return;
        }
        if ("PUT".equals(request.getMethod())) {
            String body = request.getBody();
            String content = extractJsonField(body, "content");
            if (content == null) {
                response.error(400, "content is required").send();
                return;
            }
            Files.writeString(file, content, StandardCharsets.UTF_8);
            response.status(200).json("{\"message\":\"Config saved\"}").send();
            return;
        }
        response.error(405, "Method not allowed").send();
    }

    private void handleConfigList(HttpExchange exchange, String role) throws Exception {
        HttpRequest request = new HttpRequest(exchange);
        HttpResponse response = new HttpResponse(exchange);
        if (!authorized(request, response, Role.SUPER_ADMIN)) {
            return;
        }
        if (!"GET".equals(request.getMethod())) {
            response.error(405, "Method not allowed").send();
            return;
        }
        Path root = resolveRoot(role);
        List<String> files = new ArrayList<>();
        if (root != null && Files.exists(root)) {
            try (var stream = Files.walk(root)) {
                stream.filter(Files::isRegularFile)
                        .sorted(Comparator.naturalOrder())
                        .forEach(path -> files.add(relativePath(path.toString())));
            }
        }
        response.status(200).json("[\"" + String.join("\",\"", files) + "\"]").send();
    }

    private String readAppProperties() throws IOException {
        Path file = Paths.get(System.getProperty("user.dir"), "src", "main", "resources", "application.properties");
        if (!Files.exists(file)) {
            file = Paths.get("src", "main", "resources", "application.properties");
        }
        if (!Files.exists(file)) {
            return "[]";
        }
        return "{\"path\":\"application.properties\",\"content\":" + jsonEscape(Files.readString(file, StandardCharsets.UTF_8)) + "}";
    }

    private void writeAppProperties(String content) throws IOException {
        Path file = Paths.get(System.getProperty("user.dir"), "src", "main", "resources", "application.properties");
        if (!Files.exists(file.getParent())) {
            Files.createDirectories(file.getParent());
        }
        Files.writeString(file, content, StandardCharsets.UTF_8);
    }

    private boolean authorized(HttpRequest request, HttpResponse response, Role requiredRole) throws Exception {
        String token = request.getAuthToken();
        if (token == null || token.isBlank()) {
            response.error(401, "Missing bearer token").send();
            return false;
        }
        String username = tokenProvider.validateToken(token);
        if (username == null) {
            response.error(401, "Invalid or expired token").send();
            return false;
        }
        Role userRole = tokenProvider.extractRole(token);
        if (userRole == null || !userRole.canAccess(requiredRole)) {
            response.error(403, "Forbidden").send();
            return false;
        }
        return true;
    }

    private static String extractJsonField(String json, String fieldName) {
        if (json == null || json.isBlank()) {
            return null;
        }
        String pattern = "\"" + fieldName + "\":\"";
        int start = json.indexOf(pattern);
        if (start < 0) {
            return null;
        }
        start += pattern.length();
        int end = json.indexOf('"', start);
        if (end < 0) {
            return null;
        }
        return json.substring(start, end);
    }

    private static String jsonEscape(String value) {
        return value == null ? "\"\"" : "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }

    private Path resolveRoot(String role) {
        String project = Paths.get(System.getProperty("user.dir")).normalize().toString();
        Path base = Paths.get(project, "config", "initial", role);
        if (Files.exists(base)) {
            return base;
        }
        return Paths.get(project, "config", role);
    }

    private Path resolveFile(String role, String relativePath) {
        if (relativePath == null || relativePath.isBlank()) {
            return null;
        }
        Path root = resolveRoot(role);
        if (root == null || !Files.exists(root)) {
            return null;
        }
        Path file = root.resolve(relativePath.replace("\\", "/")).normalize();
        if (!file.startsWith(root)) {
            return null;
        }
        return file;
    }

    private String relativePath(String absolute) {
        Path project = Paths.get(System.getProperty("user.dir")).normalize();
        Path p = Paths.get(absolute).normalize();
        if (p.startsWith(project)) {
            return project.relativize(p).toString().replace('\\', '/');
        }
        return p.toString().replace('\\', '/');
    }
}
