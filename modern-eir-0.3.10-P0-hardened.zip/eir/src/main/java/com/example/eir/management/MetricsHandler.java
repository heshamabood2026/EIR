package com.example.eir.management;

import com.example.eir.auth.*;
import com.example.eir.metrics.EquipmentMetrics;
import com.example.eir.audit.ImeiMasker;
import org.apache.log4j.Logger;
import com.sun.net.httpserver.HttpExchange;
import java.util.*;

/**
 * HTTP handler for metrics and health check endpoints.
 * Handles: health check, equipment metrics, database metrics.
 */
public final class MetricsHandler {
    private static final Logger log = Logger.getLogger(MetricsHandler.class);
    
    private final JwtTokenProvider tokenProvider;
    private final EquipmentMetrics metrics;
    
    public MetricsHandler(JwtTokenProvider tokenProvider, EquipmentMetrics metrics) {
        this.tokenProvider = tokenProvider;
        this.metrics = metrics;
    }
    
    /**
     * Handle GET /api/metrics/health
     * 
     * Response: {"status":"UP","timestamp":"2024-01-01T00:00:00Z","version":"0.3.10"}
     */
    public void handleHealth(HttpExchange exchange) throws Exception {
        HttpRequest request = new HttpRequest(exchange);
        HttpResponse response = new HttpResponse(exchange);
        
        try {
            if (!"GET".equals(request.getMethod())) {
                response.error(405, "Method not allowed").send();
                return;
            }
            
            String responseJson = String.format(
                    "{\"status\":\"UP\",\"timestamp\":\"%s\",\"version\":\"0.3.10\"}",
                    java.time.Instant.now()
            );
            
            response.status(200).json(responseJson).send();
            
        } catch (Exception e) {
            log.error("Health check error", e);
            response.error(500, "Internal server error").send();
        }
    }
    
    /**
     * Handle GET /api/metrics/equipment
     * 
     * Requires: Authorization header with valid JWT token (VIEWER role minimum)
     * Response: {
     *   "totalRequests": 1250,
     *   "whitelisted": 1150,
     *   "blacklisted": 50,
     *   "greylisted": 45,
     *   "unknown": 5,
     *   "databaseErrors": 0,
     *   "avgLatencyMs": 2.5,
     *   "poolSaturation%": 42.5
     * }
     */
    public void handleEquipmentMetrics(HttpExchange exchange) throws Exception {
        HttpRequest request = new HttpRequest(exchange);
        HttpResponse response = new HttpResponse(exchange);
        
        try {
            if (!"GET".equals(request.getMethod())) {
                response.error(405, "Method not allowed").send();
                return;
            }
            
            // Verify authorization
            String token = request.getAuthToken();
            if (token == null || tokenProvider.validateToken(token) == null) {
                response.error(401, "Unauthorized").send();
                return;
            }
            
            // Verify role is at least VIEWER
            Role role = tokenProvider.extractRole(token);
            if (role == null || !role.canAccess(Role.VIEWER)) {
                response.error(403, "Forbidden").send();
                return;
            }
            
            // Get metrics
            Map<String, Object> metricsMap = metrics.toMap();
            String metricsJson = mapToJson(metricsMap);
            
            response.status(200).json(metricsJson).send();
            
        } catch (Exception e) {
            log.error("Equipment metrics error", e);
            response.error(500, "Internal server error").send();
        }
    }
    
    /**
     * Handle GET /api/metrics/database
     * 
     * Response: {
     *   "totalRequests": 1250,
     *   "databaseErrors": 2,
     *   "errorRate%": 0.16,
     *   "minLatencyMs": 1.2,
     *   "maxLatencyMs": 15.8,
     *   "avgLatencyMs": 2.5
     * }
     */
    public void handleDatabaseMetrics(HttpExchange exchange) throws Exception {
        HttpRequest request = new HttpRequest(exchange);
        HttpResponse response = new HttpResponse(exchange);
        
        try {
            if (!"GET".equals(request.getMethod())) {
                response.error(405, "Method not allowed").send();
                return;
            }
            
            // Verify authorization
            String token = request.getAuthToken();
            if (token == null || tokenProvider.validateToken(token) == null) {
                response.error(401, "Unauthorized").send();
                return;
            }
            
            Role role = tokenProvider.extractRole(token);
            if (role == null || !role.canAccess(Role.VIEWER)) {
                response.error(403, "Forbidden").send();
                return;
            }
            
            // Get metrics
            Map<String, Object> metricsMap = metrics.toMap();
            long totalRequests = (long) metricsMap.get("totalRequests");
            long databaseErrors = (long) metricsMap.get("databaseErrors");
            double errorRate = totalRequests == 0 ? 0 : (double) databaseErrors / totalRequests * 100;
            
            String responseJson = String.format(
                    "{\"totalRequests\":%d,\"databaseErrors\":%d,\"errorRate%%\":%.2f," +
                    "\"minLatencyMs\":%s,\"maxLatencyMs\":%s,\"avgLatencyMs\":%s}",
                    totalRequests, databaseErrors, errorRate,
                    metricsMap.get("minLatencyMs"),
                    metricsMap.get("maxLatencyMs"),
                    metricsMap.get("avgLatencyMs")
            );
            
            response.status(200).json(responseJson).send();
            
        } catch (Exception e) {
            log.error("Database metrics error", e);
            response.error(500, "Internal server error").send();
        }
    }
    
    /**
     * Handle GET /api/metrics/pool
     * 
     * Response: {
     *   "poolUsed": 5,
     *   "poolMax": 10,
     *   "poolSaturation%": 50.0,
     *   "available": 5
     * }
     */
    public void handlePoolMetrics(HttpExchange exchange) throws Exception {
        HttpRequest request = new HttpRequest(exchange);
        HttpResponse response = new HttpResponse(exchange);
        
        try {
            if (!"GET".equals(request.getMethod())) {
                response.error(405, "Method not allowed").send();
                return;
            }
            
            // Verify authorization
            String token = request.getAuthToken();
            if (token == null || tokenProvider.validateToken(token) == null) {
                response.error(401, "Unauthorized").send();
                return;
            }
            
            Role role = tokenProvider.extractRole(token);
            if (role == null || !role.canAccess(Role.VIEWER)) {
                response.error(403, "Forbidden").send();
                return;
            }
            
            // Get metrics
            Map<String, Object> metricsMap = metrics.toMap();
            long poolUsed = (long) metricsMap.get("poolUsed");
            long poolMax = (long) metricsMap.get("poolMax");
            
            String responseJson = String.format(
                    "{\"poolUsed\":%d,\"poolMax\":%d,\"poolSaturation%%\":%s,\"available\":%d}",
                    poolUsed, poolMax, metricsMap.get("poolSaturation%"), (poolMax - poolUsed)
            );
            
            response.status(200).json(responseJson).send();
            
        } catch (Exception e) {
            log.error("Pool metrics error", e);
            response.error(500, "Internal server error").send();
        }
    }
    
    /**
     * Convert map to JSON (simple implementation).
     */
    private static String mapToJson(Map<String, Object> map) {
        StringBuilder sb = new StringBuilder("{");
        boolean first = true;
        
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            if (!first) sb.append(",");
            sb.append("\"").append(entry.getKey()).append("\":");
            
            Object value = entry.getValue();
            if (value instanceof String) {
                sb.append("\"").append(value).append("\"");
            } else if (value instanceof Number) {
                sb.append(value);
            } else {
                sb.append("\"").append(value).append("\"");
            }
            
            first = false;
        }
        
        sb.append("}");
        return sb.toString();
    }
}
