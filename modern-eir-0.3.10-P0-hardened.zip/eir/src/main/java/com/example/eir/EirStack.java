package com.example.eir;

import com.example.eir.db.Database;
import com.example.eir.management.*;
import com.example.eir.auth.*;
import com.example.eir.audit.*;
import com.example.eir.metrics.EquipmentMetrics;
import com.example.eir.repository.EquipmentRepository;
import com.example.eir.repository.InMemoryEquipmentRepository;
import com.example.eir.repository.JdbcEquipmentRepository;
import com.example.eir.service.EquipmentService;
import org.apache.log4j.Logger;
import org.restcomm.protocols.ss7.map.MAPStackImpl;
import org.restcomm.protocols.ss7.map.api.MAPProvider;
import org.restcomm.protocols.ss7.m3ua.impl.M3UAManagementImpl;
import org.restcomm.protocols.ss7.sccp.impl.SccpStackImpl;
import org.restcomm.protocols.ss7.ss7ext.Ss7ExtInterface;
import org.restcomm.protocols.ss7.tcap.TCAPStackImpl;
import org.restcomm.protocols.ss7.transport.Association;
import org.restcomm.protocols.ss7.transport.Management;

/** EIR SS7 stack: RestComm jSS7 protocols over selectable SCTP or Windows TCP test transport. */
public final class EirStack {
    private static final Logger log = Logger.getLogger(EirStack.class);

    private final EirConfig cfg;
    private Management transportManagement;
    private M3UAManagementImpl m3ua;
    private SccpStackImpl sccp;
    private TCAPStackImpl tcap;
    private MAPStackImpl map;
    private Database database;
    private EirManagementServer managementServer;
    private EquipmentMetrics metrics;
    private AuditHandler auditHandler;
    private EquipmentService equipmentService;
    private final EquipmentRepository injectedRepository;

    public EirStack(EirConfig cfg) {
        this(cfg, null);
    }

    /** Test/integration constructor allowing a controlled repository implementation. */
    public EirStack(EirConfig cfg, EquipmentRepository repository) {
        this.cfg = cfg;
        this.injectedRepository = repository;
    }

    public void start() throws Exception {
        start(true);
    }

    /** Start the SS7 stack, optionally without the management HTTP server. */
    public void start(boolean startManagement) throws Exception {
        transportManagement = TransportFactory.create(cfg.channelType, cfg.sctpName);
        transportManagement.setSingleThread(true);
        transportManagement.setConnectDelay(cfg.connectDelay);
        transportManagement.start();

        configureAssociations();

        m3ua = new M3UAManagementImpl(cfg.m3uaName, "Modern-EIR", null);
        m3ua.setTransportManagement(transportManagement);
        m3ua.start();

        // Client associations are explicitly started after M3UA has installed its
        // AssociationListener. Server associations are started by the transport/M3UA
        // integration when the configured peer connects.
        for (AssociationConfig association : cfg.associations) {
            if (association.isClient() && association.started()) {
                transportManagement.startAssociation(association.name());
            }
        }

        sccp = new SccpStackImpl("EIR-SCCP", (Ss7ExtInterface) null);
        sccp.setMtp3UserPart(cfg.mtp3Id, m3ua);
        sccp.start();

        initMap();
        
        // Initialize management API (Phase 1B: REST endpoints)
        initManagementServer();
        
        log.info("EIR RestComm jSS7 stack started over " + cfg.channelType.toUpperCase(java.util.Locale.ROOT));
    }


    private void configureAssociations() throws Exception {
        java.util.Map<String, String> servers = new java.util.LinkedHashMap<>();
        for (AssociationConfig a : cfg.associations) {
            if (a.isServer()) {
                String primaryServer = a.serverName();
                String previous = servers.putIfAbsent(primaryServer, a.localAddress() + ":" + a.localPort());
                if (previous == null) {
                    transportManagement.addServer(primaryServer, a.localAddress(), a.localPort());
                } else if (!previous.equals(a.localAddress() + ":" + a.localPort())) {
                    throw new IllegalArgumentException("Server " + primaryServer
                            + " is configured with multiple primary local endpoints: " + previous
                            + " and " + a.localAddress() + ":" + a.localPort());
                }
                if (transportManagement instanceof org.restcomm.protocols.ss7.transport.RestCommTcpManagement tcp) {
                    tcp.addServerAssociation(a.peerAddress(), a.peerPort(), a.backupPeerAddress(), a.backupPeerPort(),
                            primaryServer, a.name());
                    if (a.hasBackupLocal()) {
                        String primaryEndpoint = endpoint(a.localAddress(), a.localPort());
                        String backupEndpoint = endpoint(a.backupLocalAddress(), a.backupLocalPort());
                        if (primaryEndpoint.equals(backupEndpoint)) {
                            // A TCP backup listener is only needed when the backup local endpoint
                            // is actually different. The common SCTP-style configuration may
                            // carry the same local address/port as a placeholder; creating a
                            // second ServerSocket for it would fail with "Address already in use".
                            log.info("TCP association " + a.name() + " has identical primary/backup local endpoint "
                                    + backupEndpoint + "; using one listener");
                        } else {
                            String backupServer = primaryServer + "_BACKUP";
                            String existingEndpoint = servers.get(backupServer);
                            if (existingEndpoint == null) {
                                servers.put(backupServer, backupEndpoint);
                                transportManagement.addServer(backupServer, a.backupLocalAddress(), a.backupLocalPort());
                            } else if (!existingEndpoint.equals(backupEndpoint)) {
                                throw new IllegalArgumentException("Server " + backupServer
                                        + " is configured with multiple backup local endpoints: "
                                        + existingEndpoint + " and " + backupEndpoint);
                            }
                            tcp.bindAssociationToServer(a.name(), backupServer);
                        }
                    }
                } else if (transportManagement instanceof org.restcomm.protocols.ss7.transport.RestCommSctpManagement sctp) {
                    if (a.hasBackupLocal()) {
                        if (a.backupLocalPort() != a.localPort()) {
                            throw new IllegalArgumentException("SCTP association " + a.name()
                                    + " backupLocalPort must equal localPort for multihoming");
                        }
                    }
                    transportManagement.addServerAssociation(a.peerAddress(), a.peerPort(), primaryServer, a.name());
                    if (a.hasBackupLocal()) sctp.bindServerAddress(primaryServer, a.backupLocalAddress());
                } else {
                    transportManagement.addServerAssociation(a.peerAddress(), a.peerPort(), primaryServer, a.name());
                }
            } else {
                if (transportManagement instanceof org.restcomm.protocols.ss7.transport.RestCommTcpManagement tcp) {
                    tcp.addAssociation(a.localAddress(), a.localPort(), a.peerAddress(), a.peerPort(),
                            a.backupPeerAddress(), a.backupPeerPort(), a.name());
                } else if (transportManagement instanceof org.restcomm.protocols.ss7.transport.RestCommSctpManagement sctp) {
                    transportManagement.addAssociation(a.localAddress(), a.localPort(),
                            a.backupLocalAddress(), a.backupLocalPort(),
                            a.peerAddress(), a.peerPort(),
                            a.backupPeerAddress(), a.backupPeerPort(), a.name());
                } else {
                    transportManagement.addAssociation(a.localAddress(), a.localPort(), a.peerAddress(), a.peerPort(), a.name());
                }
            }
        }
        java.util.List<String> startedServers = new java.util.ArrayList<>();
        try {
            for (String serverName : servers.keySet()) {
                transportManagement.startServer(serverName);
                startedServers.add(serverName);
            }
        } catch (Exception startupFailure) {
            for (int i = startedServers.size() - 1; i >= 0; i--) {
                try {
                    transportManagement.stopServer(startedServers.get(i));
                } catch (Exception cleanupFailure) {
                    log.warn("Unable to clean up TCP/SCTP server " + startedServers.get(i), cleanupFailure);
                }
            }
            throw startupFailure;
        }
        log.info("Configured " + cfg.associations.size() + " EIR transport association(s): "
                + cfg.associations.stream().map(AssociationConfig::name).collect(java.util.stream.Collectors.joining(", ")));
    }

    private static String endpoint(String address, int port) {
        return address + ":" + port;
    }

    private void initMap() throws Exception {
        if (equipmentService == null) {
            equipmentService = createEquipmentService();
        }
        tcap = new TCAPStackImpl("EIR-TCAP", sccp.getSccpProvider(), cfg.localSsn);
        map = new MAPStackImpl("EIR-MAP", tcap.getProvider());
        MAPProvider provider = map.getMAPProvider();
        EirMapListener listener = new EirMapListener(equipmentService);
        provider.addMAPDialogListener(listener);
        provider.getMAPServiceMobility().addMAPServiceListener(listener);
        provider.getMAPServiceMobility().acivate();
        map.start();
    }
    
    /**
     * Initialize management API server (Phase 1B: REST endpoints).
     * Includes authentication, metrics collection, and audit logging.
     */
    private void initManagementServer() throws Exception {
        if (equipmentService == null) {
            equipmentService = createEquipmentService();
        }

        // Create management configuration from environment
        ManagementConfig mgmtConfig = ManagementConfig.fromEnvironment();

        // Initialize metrics collection
        metrics = new EquipmentMetrics();

        // Initialize JWT token provider
        String jwtSecret = mgmtConfig.getJwtSecret();
        JwtTokenProvider tokenProvider = new JwtTokenProvider(jwtSecret, mgmtConfig.getJwtExpiryMinutes());

        // Use DB-backed users when the application DB is enabled; otherwise fall back to the in-memory demo repository.
        UserRepository userRepository = (database != null && database.dataSource() != null)
                ? new DbUserRepository(database.dataSource())
                : InMemoryUserRepository.demo();

        // Initialize IMEI masker
        ImeiMasker imeiMasker = new ImeiMasker(mgmtConfig.getImeiMaskMode());

        // Create management server with all handlers
        managementServer = new EirManagementServer(mgmtConfig, userRepository, tokenProvider, metrics, imeiMasker, equipmentService);
        auditHandler = managementServer.getAuditHandler();

        // Start management server
        managementServer.start();
    }

    private EquipmentService createEquipmentService() {
        EquipmentRepository repository;
        if (injectedRepository != null) {
            repository = injectedRepository;
            log.info("EIR using injected equipment repository (integration/test mode)");
        } else if (cfg.dbEnabled) {
            database = new Database(cfg.dbUrl, cfg.dbUser, cfg.dbPassword,
                    cfg.dbPoolSize, cfg.dbConnectionTimeoutMs,
                    cfg.dbValidationTimeoutMs, cfg.dbQueryTimeoutSeconds);
            repository = new JdbcEquipmentRepository(database.dataSource(), cfg.dbQueryTimeoutSeconds);
            log.info("EIR database enabled; HikariCP pool initialized");
        } else {
            repository = InMemoryEquipmentRepository.demo();
            log.info("EIR database disabled; using in-memory demo repository");
        }
        equipmentService = new EquipmentService(repository);
        return equipmentService;
    }

    public void stop() {
        try { if (managementServer != null) managementServer.stop(); } catch (Exception e) { log.warn("Management server stop failed", e); }
        try { if (map != null) map.stop(); } catch (Exception e) { log.warn("MAP stop failed", e); }
        try { if (tcap != null) tcap.stop(); } catch (Exception e) { log.warn("TCAP stop failed", e); }
        try { if (sccp != null) sccp.stop(); } catch (Exception e) { log.warn("SCCP stop failed", e); }
        try { if (m3ua != null) m3ua.stop(); } catch (Exception e) { log.warn("M3UA stop failed", e); }
        try { if (transportManagement != null) transportManagement.stop(); } catch (Exception e) { log.warn("Transport stop failed", e); }
        try { if (database != null) database.close(); } catch (Exception e) { log.warn("Database stop failed", e); }
    }
    
    public EquipmentMetrics getMetrics() {
        return metrics;
    }
    
    public AuditHandler getAuditHandler() {
        return auditHandler;
    }
}
