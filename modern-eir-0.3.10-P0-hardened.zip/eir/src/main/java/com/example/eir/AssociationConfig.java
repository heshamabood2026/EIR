package com.example.eir;

/** One EIR-to-MSC logical transport/M3UA association definition.
 *
 * <p>For SCTP, backup local addresses are additional addresses on the same
 * SCTP association (multihoming); they are not a second M3UA association.</p>
 */
public record AssociationConfig(
        String name,
        String mode,
        String localAddress,
        int localPort,
        String backupLocalAddress,
        int backupLocalPort,
        String peerAddress,
        int peerPort,
        String backupPeerAddress,
        int backupPeerPort,
        String serverName,
        String aspName,
        String asName,
        long routingContext,
        int aspid,
        int routeDpc,
        int remoteSpc,
        int remoteSsn,
        boolean started) {

    public boolean isServer() {
        return "server".equalsIgnoreCase(mode);
    }

    public boolean isClient() {
        return "client".equalsIgnoreCase(mode);
    }

    public boolean hasBackupPeer() {
        return backupPeerAddress != null && !backupPeerAddress.isBlank() && backupPeerPort > 0;
    }

    public boolean hasBackupLocal() {
        return backupLocalAddress != null && !backupLocalAddress.isBlank() && backupLocalPort > 0;
    }

    public AssociationConfig {
        if (name == null || name.isBlank()) throw new IllegalArgumentException("Association name is required");
        if (!"server".equalsIgnoreCase(mode) && !"client".equalsIgnoreCase(mode)) throw new IllegalArgumentException("Association " + name + " mode must be server or client");
        if (serverName == null || serverName.isBlank()) serverName = name + "_SERVER";
        if (aspName == null || aspName.isBlank()) aspName = name + "_ASP";
        if (asName == null || asName.isBlank()) asName = name + "_AS";
        if (localAddress == null || localAddress.isBlank()) localAddress = "127.0.0.1";
        if (backupLocalAddress != null && backupLocalAddress.isBlank()) backupLocalAddress = null;
        if (backupLocalPort < 0) backupLocalPort = 0;
        if ((backupLocalAddress == null) != (backupLocalPort == 0)) {
            throw new IllegalArgumentException("Association " + name + " backup local endpoint requires both backupLocalAddress and backupLocalPort");
        }
        if (peerAddress == null || peerAddress.isBlank()) peerAddress = "127.0.0.1";
        if (backupPeerAddress != null && backupPeerAddress.isBlank()) backupPeerAddress = null;
        if (backupPeerPort < 0) backupPeerPort = 0;
        if ((backupPeerAddress == null) != (backupPeerPort == 0)) {
            throw new IllegalArgumentException("Association " + name + " backup peer requires both backupPeerAddress and backupPeerPort");
        }
        if (routingContext <= 0) routingContext = 100L + Math.max(0, aspid);
        if (aspid <= 0) aspid = 1;
        if (routeDpc <= 0) routeDpc = remoteSpc;
    }
}
