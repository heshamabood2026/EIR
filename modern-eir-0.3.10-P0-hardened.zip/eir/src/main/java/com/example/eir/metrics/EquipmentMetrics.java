package com.example.eir.metrics;

import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

/**
 * Metrics collection for equipment identity checks.
 * 
 * Thread-safe collection of:
 * - Request counts
 * - Response status distribution
 * - Database latency (min/max/avg)
 * - Connection pool saturation
 * - Equipment decision distribution
 */
public final class EquipmentMetrics {
    
    private final AtomicLong totalRequests = new AtomicLong(0);
    private final AtomicLong whitelistedCount = new AtomicLong(0);
    private final AtomicLong blacklistedCount = new AtomicLong(0);
    private final AtomicLong greylistedCount = new AtomicLong(0);
    private final AtomicLong unknownCount = new AtomicLong(0);
    private final AtomicLong databaseErrors = new AtomicLong(0);
    
    // Latency tracking (milliseconds)
    private final AtomicLong totalLatency = new AtomicLong(0);
    private final AtomicLong minLatency = new AtomicLong(Long.MAX_VALUE);
    private final AtomicLong maxLatency = new AtomicLong(0);
    
    // Connection pool metrics
    private final AtomicLong poolConnectionsUsed = new AtomicLong(0);
    private final AtomicLong poolConnectionsMax = new AtomicLong(0);
    
    /**
     * Record successful equipment check.
     */
    public void recordCheck(String status, long latencyMs) {
        totalRequests.incrementAndGet();
        
        switch (status) {
            case "WHITELISTED" -> whitelistedCount.incrementAndGet();
            case "BLACKLISTED" -> blacklistedCount.incrementAndGet();
            case "GREYLISTED" -> greylistedCount.incrementAndGet();
            case "UNKNOWN" -> unknownCount.incrementAndGet();
        }
        
        recordLatency(latencyMs);
    }
    
    /**
     * Record database error.
     */
    public void recordDatabaseError(long latencyMs) {
        totalRequests.incrementAndGet();
        databaseErrors.incrementAndGet();
        recordLatency(latencyMs);
    }
    
    /**
     * Record database query latency.
     */
    private void recordLatency(long latencyMs) {
        totalLatency.addAndGet(latencyMs);
        minLatency.getAndUpdate(v -> Math.min(v, latencyMs));
        maxLatency.getAndUpdate(v -> Math.max(v, latencyMs));
    }
    
    /**
     * Update connection pool usage.
     */
    public void updatePoolUsage(long used, long max) {
        poolConnectionsUsed.set(used);
        poolConnectionsMax.set(max);
    }
    
    /**
     * Get average latency in milliseconds.
     */
    public double getAverageLatency() {
        long total = totalRequests.get();
        if (total == 0) return 0;
        return (double) totalLatency.get() / total;
    }
    
    /**
     * Get pool saturation percentage.
     */
    public double getPoolSaturation() {
        long max = poolConnectionsMax.get();
        if (max == 0) return 0;
        return (double) poolConnectionsUsed.get() / max * 100;
    }
    
    /**
     * Export metrics as map.
     */
    public Map<String, Object> toMap() {
        Map<String, Object> metrics = new ConcurrentHashMap<>();
        
        metrics.put("totalRequests", totalRequests.get());
        metrics.put("whitelisted", whitelistedCount.get());
        metrics.put("blacklisted", blacklistedCount.get());
        metrics.put("greylisted", greylistedCount.get());
        metrics.put("unknown", unknownCount.get());
        metrics.put("databaseErrors", databaseErrors.get());
        
        metrics.put("minLatencyMs", minLatency.get());
        metrics.put("maxLatencyMs", maxLatency.get());
        metrics.put("avgLatencyMs", String.format("%.2f", getAverageLatency()));
        
        metrics.put("poolUsed", poolConnectionsUsed.get());
        metrics.put("poolMax", poolConnectionsMax.get());
        metrics.put("poolSaturation%", String.format("%.1f", getPoolSaturation()));
        
        return metrics;
    }
}
