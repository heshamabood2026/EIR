package com.example.eir.management;

import com.example.eir.auth.JwtTokenProvider;
import com.example.eir.auth.Role;
import com.example.eir.domain.Equipment;
import com.example.eir.service.EquipmentService;
import com.sun.net.httpserver.HttpExchange;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * HTTP handler for equipment provisioning and bulk import operations.
 */
public final class EquipmentManagementHandler {
    private final JwtTokenProvider tokenProvider;
    private final EquipmentService equipmentService;

    public EquipmentManagementHandler(JwtTokenProvider tokenProvider, EquipmentService equipmentService) {
        this.tokenProvider = tokenProvider;
        this.equipmentService = equipmentService;
    }

    public void handleList(HttpExchange exchange) throws Exception {
        HttpRequest request = new HttpRequest(exchange);
        HttpResponse response = new HttpResponse(exchange);
        if (!"GET".equals(request.getMethod())) {
            response.error(405, "Method not allowed").send();
            return;
        }

        if (!authorized(request, response, Role.VIEWER)) {
            return;
        }

        List<Equipment> equipment = equipmentService.listEquipment();
        response.status(200).json(toJson(equipment)).send();
    }

    public void handleGet(HttpExchange exchange, String imei) throws Exception {
        HttpRequest request = new HttpRequest(exchange);
        HttpResponse response = new HttpResponse(exchange);
        if (!"GET".equals(request.getMethod())) {
            response.error(405, "Method not allowed").send();
            return;
        }

        if (!authorized(request, response, Role.VIEWER)) {
            return;
        }

        Equipment equipment = equipmentService.getEquipment(imei);
        if (equipment == null) {
            response.error(404, "Equipment not found").send();
            return;
        }

        response.status(200).json(toJson(equipment)).send();
    }

    public void handleCreate(HttpExchange exchange) throws Exception {
        HttpRequest request = new HttpRequest(exchange);
        HttpResponse response = new HttpResponse(exchange);
        if (!"POST".equals(request.getMethod())) {
            response.error(405, "Method not allowed").send();
            return;
        }

        if (!authorized(request, response, Role.USER)) {
            return;
        }

        Equipment equipment = parseEquipment(request.getBody());
        if (equipment == null) {
            response.error(400, "Request body must include imei and status").send();
            return;
        }

        try {
            Equipment created = equipmentService.createEquipment(equipment.imei(), equipment.status().name());
            response.status(201).json(toJson(created)).send();
        } catch (IllegalArgumentException ex) {
            response.error(400, ex.getMessage()).send();
        }
    }

    public void handleUpdate(HttpExchange exchange, String imei) throws Exception {
        HttpRequest request = new HttpRequest(exchange);
        HttpResponse response = new HttpResponse(exchange);
        if (!"PUT".equals(request.getMethod())) {
            response.error(405, "Method not allowed").send();
            return;
        }

        if (!authorized(request, response, Role.USER)) {
            return;
        }

        String body = request.getBody();
        String statusText = extractJsonField(body, "status");
        if (statusText == null || statusText.isBlank()) {
            response.error(400, "status is required").send();
            return;
        }

        try {
            Equipment updated = equipmentService.updateEquipment(imei, statusText);
            response.status(200).json(toJson(updated)).send();
        } catch (IllegalArgumentException ex) {
            response.error(404, ex.getMessage()).send();
        }
    }

    public void handleDelete(HttpExchange exchange, String imei) throws Exception {
        HttpRequest request = new HttpRequest(exchange);
        HttpResponse response = new HttpResponse(exchange);
        if (!"DELETE".equals(request.getMethod())) {
            response.error(405, "Method not allowed").send();
            return;
        }

        if (!authorized(request, response, Role.ADMIN)) {
            return;
        }

        try {
            equipmentService.deleteEquipment(imei);
            response.status(200).json("{\"message\":\"Equipment deleted\"}").send();
        } catch (IllegalArgumentException ex) {
            response.error(404, ex.getMessage()).send();
        }
    }

    public void handleBulkImport(HttpExchange exchange) throws Exception {
        HttpRequest request = new HttpRequest(exchange);
        HttpResponse response = new HttpResponse(exchange);
        if (!"POST".equals(request.getMethod())) {
            response.error(405, "Method not allowed").send();
            return;
        }

        if (!authorized(request, response, Role.USER)) {
            return;
        }

        String body = request.getBody();
        List<String> entries = splitObjects(body);
        if (entries.isEmpty()) {
            response.error(400, "Request body must include a JSON array of equipment records").send();
            return;
        }

        List<Equipment> imported = new ArrayList<>();
        for (String entry : entries) {
            Equipment equipment = parseEquipment(entry);
            if (equipment == null) {
                response.error(400, "Each equipment record must include imei and status").send();
                return;
            }
            imported.add(equipment);
        }

        List<Equipment> saved = equipmentService.bulkImport(imported);
        response.status(200).json(toJson(saved)).send();
    }

    private boolean authorized(HttpRequest request, HttpResponse response, Role requiredRole) throws Exception {
        String token = request.getAuthToken();
        if (token == null || token.isBlank()) {
            response.error(401, "Missing bearer token").send();
            return false;
        }

        String username = tokenProvider.validateToken(token);
        if (username == null) {
            response.error(401, "Invalid or expired token").send();
            return false;
        }

        Role userRole = tokenProvider.extractRole(token);
        if (userRole == null || !userRole.canAccess(requiredRole)) {
            response.error(403, "Forbidden").send();
            return false;
        }
        return true;
    }

    private static Equipment parseEquipment(String body) {
        String imei = extractJsonField(body, "imei");
        String status = extractJsonField(body, "status");
        if (imei == null || status == null) {
            return null;
        }
        return new Equipment(
                imei,
                com.example.eir.domain.EirEquipmentStatus.valueOf(status.trim().toUpperCase(Locale.ROOT)),
                java.time.Instant.now(),
                java.time.Instant.now(),
                java.util.Map.of()
        );
    }

    private static String toJson(List<Equipment> equipment) {
        if (equipment == null || equipment.isEmpty()) {
            return "[]";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for (int i = 0; i < equipment.size(); i++) {
            if (i > 0) {
                sb.append(',');
            }
            sb.append(toJson(equipment.get(i)));
        }
        sb.append("]");
        return sb.toString();
    }

    private static String toJson(Equipment equipment) {
        return String.format(
                "{\"imei\":\"%s\",\"status\":\"%s\",\"createdAt\":\"%s\",\"updatedAt\":\"%s\"}",
                equipment.imei(),
                equipment.status(),
                equipment.createdAt(),
                equipment.updatedAt()
        );
    }

    private static List<String> splitObjects(String body) {
        String trimmed = body == null ? "" : body.trim();
        if (trimmed.isEmpty()) {
            return List.of();
        }

        int start = trimmed.indexOf('[');
        int end = trimmed.lastIndexOf(']');
        if (start >= 0 && end > start) {
            trimmed = trimmed.substring(start + 1, end);
        }

        if (trimmed.isBlank()) {
            return List.of();
        }

        List<String> items = new ArrayList<>();
        int depth = 0;
        int objectStart = -1;
        for (int i = 0; i < trimmed.length(); i++) {
            char ch = trimmed.charAt(i);
            if (ch == '{') {
                if (depth == 0) {
                    objectStart = i;
                }
                depth++;
            } else if (ch == '}') {
                depth--;
                if (depth == 0 && objectStart >= 0) {
                    items.add(trimmed.substring(objectStart + 1, i));
                    objectStart = -1;
                }
            }
        }
        return items;
    }

    private static String extractJsonField(String json, String fieldName) {
        if (json == null || json.isBlank()) {
            return null;
        }
        String pattern = "\"" + fieldName + "\":\"";
        int start = json.indexOf(pattern);
        if (start == -1) {
            return null;
        }
        start += pattern.length();
        int end = json.indexOf('"', start);
        if (end == -1) {
            return null;
        }
        return json.substring(start, end);
    }
}
