package com.example.eir.management;

import com.example.eir.auth.*;
import com.example.eir.audit.*;
import org.apache.log4j.Logger;
import com.sun.net.httpserver.HttpExchange;
import java.util.*;

/**
 * HTTP handler for audit logging endpoints.
 * Handles: querying audit logs, audit statistics.
 */
public final class AuditHandler {
    private static final Logger log = Logger.getLogger(AuditHandler.class);
    
    private final JwtTokenProvider tokenProvider;
    private final ImeiMasker imeiMasker;
    private final List<AuditLog> auditLogs;
    
    public AuditHandler(JwtTokenProvider tokenProvider, ImeiMasker imeiMasker) {
        this.tokenProvider = tokenProvider;
        this.imeiMasker = imeiMasker;
        this.auditLogs = Collections.synchronizedList(new ArrayList<>());
    }
    
    /**
     * Add audit log entry (called by EquipmentService).
     */
    public void addAuditLog(AuditLog log) {
        auditLogs.add(log);
        
        // Keep only last 10000 entries in memory
        if (auditLogs.size() > 10000) {
            auditLogs.remove(0);
        }
    }
    
    /**
     * Handle GET /api/audit/logs
     * 
     * Query parameters:
     * - limit: max results (default 100)
     * - offset: pagination offset (default 0)
     * - status: filter by status (optional)
     * - imei: filter by IMEI (optional)
     * 
     * Response: {"logs":[...], "total":1250, "limit":100, "offset":0}
     */
    public void handleQueryLogs(HttpExchange exchange) throws Exception {
        HttpRequest request = new HttpRequest(exchange);
        HttpResponse response = new HttpResponse(exchange);
        
        try {
            if (!"GET".equals(request.getMethod())) {
                response.error(405, "Method not allowed").send();
                return;
            }
            
            // Verify authorization (VIEWER minimum)
            String token = request.getAuthToken();
            if (token == null || tokenProvider.validateToken(token) == null) {
                response.error(401, "Unauthorized").send();
                return;
            }
            
            Role role = tokenProvider.extractRole(token);
            if (role == null || !role.canAccess(Role.VIEWER)) {
                response.error(403, "Forbidden").send();
                return;
            }
            
            // Parse pagination
            int limit = 100;
            int offset = 0;
            
            String limitParam = request.getQueryParam("limit");
            String offsetParam = request.getQueryParam("offset");
            
            if (limitParam != null) {
                try {
                    limit = Math.min(Integer.parseInt(limitParam), 1000);
                } catch (NumberFormatException ignored) {}
            }
            
            if (offsetParam != null) {
                try {
                    offset = Math.max(Integer.parseInt(offsetParam), 0);
                } catch (NumberFormatException ignored) {}
            }
            
            // Filter logs
            String statusFilter = request.getQueryParam("status");
            String imeiFilter = request.getQueryParam("imei");
            
            List<AuditLog> filtered = new ArrayList<>();
            for (AuditLog log : auditLogs) {
                if (statusFilter != null && !log.getStatus().equals(statusFilter)) {
                    continue;
                }
                if (imeiFilter != null && !log.getImei().equals(imeiFilter)) {
                    continue;
                }
                filtered.add(log);
            }
            
            // Reverse to get newest first
            Collections.reverse(filtered);
            
            // Paginate
            int end = Math.min(offset + limit, filtered.size());
            List<AuditLog> page = filtered.subList(offset, end);
            
            // Build response with masked IMEIs
            StringBuilder sb = new StringBuilder("{\"logs\":[");
            boolean first = true;
            for (AuditLog al : page) {
                if (!first) sb.append(",");
                sb.append(auditLogToJson(al));
                first = false;
            }
            sb.append("],\"total\":").append(filtered.size());
            sb.append(",\"limit\":").append(limit);
            sb.append(",\"offset\":").append(offset).append("}");
            
            response.status(200).json(sb.toString()).send();
            
        } catch (Exception e) {
            log.error("Audit query error", e);
            response.error(500, "Internal server error").send();
        }
    }
    
    /**
     * Handle GET /api/audit/logs/{imei}
     * 
     * Query parameters:
     * - limit: max results (default 100)
     * - offset: pagination offset (default 0)
     * 
     * Response: {"logs":[...], "imei":"...", "total":25}
     */
    public void handleQueryImeiLogs(HttpExchange exchange, String imei) throws Exception {
        HttpRequest request = new HttpRequest(exchange);
        HttpResponse response = new HttpResponse(exchange);
        
        try {
            if (!"GET".equals(request.getMethod())) {
                response.error(405, "Method not allowed").send();
                return;
            }
            
            // Verify authorization
            String token = request.getAuthToken();
            if (token == null || tokenProvider.validateToken(token) == null) {
                response.error(401, "Unauthorized").send();
                return;
            }
            
            Role role = tokenProvider.extractRole(token);
            if (role == null || !role.canAccess(Role.VIEWER)) {
                response.error(403, "Forbidden").send();
                return;
            }
            
            // Parse pagination
            int limit = 100;
            int offset = 0;
            
            String limitParam = request.getQueryParam("limit");
            String offsetParam = request.getQueryParam("offset");
            
            if (limitParam != null) {
                try {
                    limit = Math.min(Integer.parseInt(limitParam), 1000);
                } catch (NumberFormatException ignored) {}
            }
            
            if (offsetParam != null) {
                try {
                    offset = Math.max(Integer.parseInt(offsetParam), 0);
                } catch (NumberFormatException ignored) {}
            }
            
            // Filter logs for IMEI
            List<AuditLog> filtered = new ArrayList<>();
            for (AuditLog log : auditLogs) {
                if (log.getImei().equals(imei)) {
                    filtered.add(log);
                }
            }
            
            // Reverse to get newest first
            Collections.reverse(filtered);
            
            // Paginate
            int end = Math.min(offset + limit, filtered.size());
            List<AuditLog> page = filtered.subList(offset, end);
            
            // Build response
            StringBuilder sb = new StringBuilder("{\"logs\":[");
            boolean first = true;
            for (AuditLog al : page) {
                if (!first) sb.append(",");
                sb.append(auditLogToJson(al));
                first = false;
            }
            sb.append("],\"imei\":\"").append(imei).append("\",\"total\":")
                    .append(filtered.size()).append("}");
            
            response.status(200).json(sb.toString()).send();
            
        } catch (Exception e) {
            log.error("Audit IMEI query error", e);
            response.error(500, "Internal server error").send();
        }
    }
    
    /**
     * Handle GET /api/audit/metrics
     * 
     * Response: {
     *   "totalAuditRecords": 5250,
     *   "whitelistedCount": 4800,
     *   "blacklistedCount": 300,
     *   "greylistedCount": 150,
     *   "unique_imeis": 2500
     * }
     */
    public void handleAuditMetrics(HttpExchange exchange) throws Exception {
        HttpRequest request = new HttpRequest(exchange);
        HttpResponse response = new HttpResponse(exchange);
        
        try {
            if (!"GET".equals(request.getMethod())) {
                response.error(405, "Method not allowed").send();
                return;
            }
            
            // Verify authorization
            String token = request.getAuthToken();
            if (token == null || tokenProvider.validateToken(token) == null) {
                response.error(401, "Unauthorized").send();
                return;
            }
            
            Role role = tokenProvider.extractRole(token);
            if (role == null || !role.canAccess(Role.VIEWER)) {
                response.error(403, "Forbidden").send();
                return;
            }
            
            // Calculate metrics
            long whitelisted = 0, blacklisted = 0, greylisted = 0;
            Set<String> uniqueImeis = new HashSet<>();
            
            for (AuditLog al : auditLogs) {
                switch (al.getStatus()) {
                    case "WHITELISTED" -> whitelisted++;
                    case "BLACKLISTED" -> blacklisted++;
                    case "GREYLISTED" -> greylisted++;
                }
                uniqueImeis.add(al.getImei());
            }
            
            String responseJson = String.format(
                    "{\"totalAuditRecords\":%d,\"whitelistedCount\":%d," +
                    "\"blacklistedCount\":%d,\"greylistedCount\":%d,\"unique_imeis\":%d}",
                    auditLogs.size(), whitelisted, blacklisted, greylisted, uniqueImeis.size()
            );
            
            response.status(200).json(responseJson).send();
            
        } catch (Exception e) {
            log.error("Audit metrics error", e);
            response.error(500, "Internal server error").send();
        }
    }
    
    /**
     * Convert audit log to JSON with masked IMEI.
     */
    private String auditLogToJson(AuditLog al) {
        String maskedImei = imeiMasker.mask(al.getImei());
        return String.format(
                "{\"timestamp\":\"%s\",\"imei\":\"%s\",\"status\":\"%s\"," +
                "\"reason\":\"%s\",\"source\":\"%s\",\"userId\":\"%s\",\"requestId\":\"%s\"}",
                al.getTimestamp(),
                maskedImei,
                al.getStatus(),
                escapeJson(al.getReason()),
                al.getSource(),
                al.getUserId() != null ? al.getUserId() : "",
                al.getRequestId() != null ? al.getRequestId() : ""
        );
    }
    
    /**
     * Escape JSON special characters.
     */
    private static String escapeJson(String text) {
        if (text == null) return "";
        return text
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r");
    }
}
