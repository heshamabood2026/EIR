package com.example.eir.repository;

import com.example.eir.domain.Equipment;
import com.example.eir.domain.EirEquipmentStatus;
import com.example.eir.exception.EquipmentRepositoryException;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * In-memory equipment repository for fast access and testing.
 * Supports failure simulation for testing fail-closed and MAP-error policies.
 *
 * Thread-safe for concurrent access via ConcurrentHashMap.
 * Prepared statements pattern: simulated via direct Map lookups (in-memory doesn't use JDBC).
 * Exception wrapping: can simulate failures via simulateFailure() for test scenarios.
 * EquipmentService applies fail-closed policy: databaseUnavailable() when exception thrown.
 */
public final class InMemoryEquipmentRepository implements EquipmentRepository {
    private final Map<String, Equipment> equipment = new ConcurrentHashMap<>();
    private final AtomicBoolean failureSimulated = new AtomicBoolean(false);

    public static InMemoryEquipmentRepository demo() {
        InMemoryEquipmentRepository r = new InMemoryEquipmentRepository();
        r.put(Equipment.now("333333334444440", EirEquipmentStatus.WHITELISTED));
        r.put(Equipment.now("490154203237518", EirEquipmentStatus.WHITELISTED));
        r.put(Equipment.now("333333334444442", EirEquipmentStatus.BLACKLISTED));
        return r;
    }

    @Override
    public void save(Equipment value) {
        equipment.put(value.imei(), value);
    }

    /**
     * Stores equipment identity in memory (simulates prepared statement execution).
     * Thread-safe via ConcurrentHashMap.putIfAbsent semantics.
     */
    public void put(Equipment value) {
        save(value);
    }

    public void allow(String imei) {
        put(Equipment.now(imei, EirEquipmentStatus.WHITELISTED));
    }

    public void blacklist(String imei) {
        put(Equipment.now(imei, EirEquipmentStatus.BLACKLISTED));
    }

    public void greylist(String imei) {
        put(Equipment.now(imei, EirEquipmentStatus.GREYLISTED));
    }

    @Override
    public void delete(String imei) {
       equipment.remove(imei);
    }

    public void remove(String imei) {
       delete(imei);
    }

    @Override
    public java.util.List<Equipment> findAll() {
       return java.util.List.copyOf(equipment.values());
    }

    /**
     * Query equipment by IMEI (in-memory analog to SQL prepared statement).
     * Throws EquipmentRepositoryException if failure simulation is active (testing scenario).
     * EquipmentService catches this and returns EquipmentDecision.databaseUnavailable().
     *
     * @param imei the IMEI to look up
     * @return Equipment record if found, null if IMEI not in database
     * @throws EquipmentRepositoryException if failure simulation is enabled
     */
    @Override
    public Equipment findByImei(String imei) {
        if (failureSimulated.get()) {
            throw new EquipmentRepositoryException(
                    "In-memory repository failure simulated for testing",
                    new RuntimeException("Simulated I/O failure")
            );
        }
        return equipment.get(imei);
    }

    /**
     * Enable failure simulation for testing fail-closed behavior.
     * This simulates a repository outage (e.g., IO errors, connection failures).
     * EquipmentService will return databaseUnavailable() decision.
     * All subsequent findByImei() calls will throw EquipmentRepositoryException.
     */
    public void simulateFailure() {
        failureSimulated.set(true);
    }

    /**
     * Disable failure simulation and return to normal operation.
     */
    public void clearFailure() {
        failureSimulated.set(false);
    }

    /**
     * Check if failure simulation is currently active.
     */
    public boolean isFailureSimulated() {
        return failureSimulated.get();
    }
}
