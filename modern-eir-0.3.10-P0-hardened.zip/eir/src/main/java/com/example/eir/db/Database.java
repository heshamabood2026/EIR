package com.example.eir.db;

import com.example.eir.exception.EquipmentRepositoryException;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import javax.sql.DataSource;
import java.time.Duration;

/**
 * Application database boundary.
 *
 * Owns exactly one HikariCP data source for the EIR process. The data source
 * is created once at application startup and closed once during shutdown.
 */
public final class Database implements AutoCloseable {
    private final HikariDataSource dataSource;

    public Database(String jdbcUrl,
                    String username,
                    String password,
                    int maximumPoolSize,
                    long connectionTimeoutMs,
                    long validationTimeoutMs,
                    int queryTimeoutSeconds) {
        if (jdbcUrl == null || jdbcUrl.isBlank()) {
            throw new IllegalArgumentException("JDBC URL must not be blank");
        }
        if (maximumPoolSize < 1) {
            throw new IllegalArgumentException("maximumPoolSize must be >= 1");
        }
        if (connectionTimeoutMs < 250) {
            throw new IllegalArgumentException("connectionTimeoutMs must be >= 250");
        }
        if (validationTimeoutMs < 250) {
            throw new IllegalArgumentException("validationTimeoutMs must be >= 250");
        }
        if (validationTimeoutMs >= connectionTimeoutMs) {
            throw new IllegalArgumentException("validationTimeoutMs must be less than connectionTimeoutMs");
        }
        if (queryTimeoutSeconds < 0) {
            throw new IllegalArgumentException("queryTimeoutSeconds must be >= 0");
        }

        HikariConfig config = new HikariConfig();
        config.setJdbcUrl(jdbcUrl);
        config.setUsername(username == null ? "" : username);
        config.setPassword(password == null ? "" : password);
        config.setMaximumPoolSize(maximumPoolSize);
        config.setConnectionTimeout(connectionTimeoutMs);
        config.setValidationTimeout(validationTimeoutMs);
        config.setPoolName("eir-hikari");
        // Allow the application to start when the database is temporarily unavailable;
        // repository calls will surface the outage through EquipmentRepositoryException.
        config.setInitializationFailTimeout(-1);

        // Keep JDBC query timeout as an explicit repository concern while
        // retaining the configured operational value in the data source.
        config.addDataSourceProperty("socketTimeout", Math.max(0, queryTimeoutSeconds) * 1000);

        try {
            this.dataSource = new HikariDataSource(config);
        } catch (RuntimeException e) {
            throw new EquipmentRepositoryException("EIR database pool initialization failed", e);
        }
    }

    public DataSource dataSource() {
        return dataSource;
    }

    @Override
    public void close() {
        if (!dataSource.isClosed()) {
            dataSource.close();
        }
    }
}
