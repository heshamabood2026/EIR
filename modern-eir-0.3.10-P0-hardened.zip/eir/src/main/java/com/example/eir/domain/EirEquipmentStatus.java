package com.example.eir.domain;

/**
 * Business status of an equipment identity in the EIR.
 *
 * INVALID is intentionally not a persisted equipment status. Invalid input is
 * represented by an UNKNOWN decision and a validation reason by the service.
 */
public enum EirEquipmentStatus {
    WHITELISTED,
    BLACKLISTED,
    GREYLISTED,
    UNKNOWN
}
