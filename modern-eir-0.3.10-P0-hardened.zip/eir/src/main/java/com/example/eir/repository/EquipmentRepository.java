package com.example.eir.repository;

import com.example.eir.domain.Equipment;
import java.util.List;

/**
 * Persistence boundary for equipment identities.
 */
public interface EquipmentRepository {

    /**
     * Returns the stored equipment, or null when no identity exists.
     */
    Equipment findByImei(String imei);

    /**
     * Save or update an equipment record.
     */
    default void save(Equipment equipment) {
        throw new UnsupportedOperationException("Repository does not support save() yet");
    }

    /**
     * Delete a stored equipment record.
     */
    default void delete(String imei) {
        throw new UnsupportedOperationException("Repository does not support delete() yet");
    }

    /**
     * Return all equipment records.
     */
    default List<Equipment> findAll() {
        return List.of();
    }

    /**
     * Compatibility helper retained for existing callers.
     */
    default boolean isAllowed(String imei) {
        Equipment equipment = findByImei(imei);
        return equipment != null && equipment.status() ==
                com.example.eir.domain.EirEquipmentStatus.WHITELISTED;
    }
}
