package com.example.eir;

import org.apache.log4j.Logger;

/** Starts the EIR listener using RestComm jSS7 with SCTP or Windows TCP test transport. */
public final class EirServerMain {
    private static final Logger log = Logger.getLogger(EirServerMain.class);
    private EirServerMain() {}

    public static void main(String[] args) throws Exception {
        String transport = EirConfig.parseCommandLineType(args);
        EirConfig cfg = EirConfig.load("EIR", transport);

        EirStack stack = new EirStack(cfg);
        Runtime.getRuntime().addShutdownHook(new Thread(stack::stop, "eir-shutdown"));
        stack.start();

        log.info("EIR started over " + cfg.channelType.toUpperCase(java.util.Locale.ROOT)
                + " with " + cfg.associations.size() + " association(s)"
                + ". localSPC=" + cfg.localSpc + " localSSN=" + cfg.localSsn);
        for (AssociationConfig association : cfg.associations) {
            log.info("EIR association " + association.name() + " mode=" + association.mode()
                    + " local=" + association.localAddress() + ":" + association.localPort()
                    + (association.backupLocalAddress() != null ? " backupLocal=" + association.backupLocalAddress() + ":" + association.backupLocalPort() : "")
                    + " peer=" + association.peerAddress() + ":" + association.peerPort()
                    + (association.hasBackupPeer() ? " backup=" + association.backupPeerAddress() + ":" + association.backupPeerPort() : "")
                    + " AS=" + association.asName() + " DPC=" + association.routeDpc());
        }
        Thread.currentThread().join();
    }
}
