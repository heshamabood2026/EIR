package com.example.eir;

import org.restcomm.protocols.ss7.transport.Management;
import org.restcomm.protocols.ss7.transport.RestCommSctpManagement;
import org.restcomm.protocols.ss7.transport.RestCommTcpManagement;

/** Creates the selected RestComm transport. TCP is a Windows/local test transport; SCTP uses the JDK SCTP implementation. */
public final class TransportFactory {
    private TransportFactory() {}

    public static Management create(String transport, String name) {
        if ("tcp".equalsIgnoreCase(transport)) {
            return new RestCommTcpManagement(name);
        }
        if ("sctp".equalsIgnoreCase(transport)) {
            return new RestCommSctpManagement(name);
        }
        throw new IllegalArgumentException("Unsupported transport: " + transport);
    }
}
