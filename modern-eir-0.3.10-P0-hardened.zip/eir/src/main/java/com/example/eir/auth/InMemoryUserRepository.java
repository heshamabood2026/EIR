package com.example.eir.auth;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * In-memory user repository for equipment management authentication.
 * 
 * Stores users and provides login functionality.
 * Production should use database-backed repository.
 */
public final class InMemoryUserRepository implements UserRepository {
    
    private final Map<String, User> users = new ConcurrentHashMap<>();
    
    /**
     * Create an in-memory repository using optional deployment-provided bootstrap credentials.
     * No users are created when bootstrap passwords are not supplied.
     */
    public static InMemoryUserRepository demo() {
        InMemoryUserRepository repo = new InMemoryUserRepository();
        String adminPassword = System.getenv("EIR_BOOTSTRAP_ADMIN_PASSWORD");
        String viewerPassword = System.getenv("EIR_BOOTSTRAP_VIEWER_PASSWORD");
        if (adminPassword != null && !adminPassword.isBlank()) {
            repo.save(User.create("admin", PasswordHasher.hash(adminPassword), Role.SUPER_ADMIN));
        }
        if (viewerPassword != null && !viewerPassword.isBlank()) {
            repo.save(User.create("viewer", PasswordHasher.hash(viewerPassword), Role.VIEWER));
        }
        return repo;
    }

    @Override
    public void save(User user) {
        users.put(user.getUsername(), user);
    }
    
    @Override
    public Optional<User> findByUsername(String username) {
        return Optional.ofNullable(users.get(username));
    }

    @Override
    public java.util.List<User> findAll() {
        return new java.util.ArrayList<>(users.values());
    }

    @Override
    public void deleteByUsername(String username) {
        users.remove(username);
    }
    
    @Override
    public boolean existsByUsername(String username) {
        return users.containsKey(username);
    }
    
    /**
     * Find user by username and verify password.
     * Returns user if credentials are valid, empty otherwise.
     */
    @Override
    public Optional<User> authenticate(String username, String password) {
        User user = users.get(username);
        if (user == null || !user.isEnabled()) {
            return Optional.empty();
        }
        
        if (PasswordHasher.verify(password, user.getPasswordHash())) {
            return Optional.of(user);
        }
        
        return Optional.empty();
    }
    

}
