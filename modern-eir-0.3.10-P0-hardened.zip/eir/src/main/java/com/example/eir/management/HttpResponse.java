package com.example.eir.management;

import java.util.*;
import com.sun.net.httpserver.HttpExchange;

/**
 * Wrapper for HTTP response building and sending.
 * Provides convenient methods for JSON, status codes, and headers.
 */
public final class HttpResponse {
    
    private final HttpExchange exchange;
    private final Map<String, String> headers;
    private int statusCode = 200;
    private String body = "";
    private boolean sent = false;
    
    public HttpResponse(HttpExchange exchange) {
        this.exchange = exchange;
        this.headers = new HashMap<>();
        this.headers.put("Content-Type", "application/json");
        this.headers.put("Access-Control-Allow-Origin", "*");
    }
    
    /**
     * Set HTTP status code.
     */
    public HttpResponse status(int code) {
        this.statusCode = code;
        return this;
    }
    
    /**
     * Set response header.
     */
    public HttpResponse header(String name, String value) {
        headers.put(name, value);
        return this;
    }
    
    /**
     * Set JSON body.
     */
    public HttpResponse json(String json) {
        this.body = json;
        return this;
    }
    
    /**
     * Set plain text body.
     */
    public HttpResponse text(String text) {
        this.headers.put("Content-Type", "text/plain");
        this.body = text;
        return this;
    }
    
    /**
     * Set JSON body from error.
     */
    public HttpResponse error(int status, String message) {
        this.statusCode = status;
        this.body = String.format("{\"error\":\"%s\"}", escapeJson(message));
        return this;
    }
    
    /**
     * Send response and flush.
     */
    public void send() throws Exception {
        if (sent) {
            return;
        }
        
        byte[] responseBytes = body.getBytes("UTF-8");
        
        // Set headers
        for (Map.Entry<String, String> entry : headers.entrySet()) {
            exchange.getResponseHeaders().set(entry.getKey(), entry.getValue());
        }
        
        // Send response
        exchange.sendResponseHeaders(statusCode, responseBytes.length);
        if (responseBytes.length > 0) {
            exchange.getResponseBody().write(responseBytes);
        }
        exchange.getResponseBody().close();
        
        sent = true;
    }
    
    /**
     * Escape JSON special characters.
     */
    private static String escapeJson(String text) {
        if (text == null) return "";
        return text
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }
    
    public boolean isSent() {
        return sent;
    }
}
