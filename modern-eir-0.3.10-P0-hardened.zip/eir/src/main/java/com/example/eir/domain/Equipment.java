package com.example.eir.domain;

import java.time.Instant;
import java.util.Map;
import java.util.Objects;

/**
 * Domain representation of an equipment identity.
 *
 * Audit metadata is optional and immutable from the caller's perspective.
 */
public record Equipment(
        String imei,
        EirEquipmentStatus status,
        Instant createdAt,
        Instant updatedAt,
        Map<String, String> auditMetadata
) {
    public Equipment {
        Objects.requireNonNull(imei, "imei");
        Objects.requireNonNull(status, "status");
        Objects.requireNonNull(createdAt, "createdAt");
        Objects.requireNonNull(updatedAt, "updatedAt");

        if (imei.isBlank()) {
            throw new IllegalArgumentException("imei must not be blank");
        }
        if (updatedAt.isBefore(createdAt)) {
            throw new IllegalArgumentException("updatedAt must not be before createdAt");
        }

        auditMetadata = auditMetadata == null
                ? Map.of()
                : Map.copyOf(auditMetadata);
    }

    public Equipment(
            String imei,
            EirEquipmentStatus status,
            Instant createdAt,
            Instant updatedAt
    ) {
        this(imei, status, createdAt, updatedAt, Map.of());
    }

    public static Equipment now(String imei, EirEquipmentStatus status) {
        Instant now = Instant.now();
        return new Equipment(imei, status, now, now, Map.of());
    }
}
