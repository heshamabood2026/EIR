package com.example.eir;

import com.example.eir.domain.EquipmentDecision;
import com.example.eir.domain.EirMapResponse;
import com.example.eir.domain.EirResponsePolicy;
import com.example.eir.service.EquipmentService;

import org.apache.log4j.Logger;

import org.restcomm.protocols.ss7.map.api.MAPDialog;
import org.restcomm.protocols.ss7.map.api.MAPDialogListener;
import org.restcomm.protocols.ss7.map.api.MAPException;
import org.restcomm.protocols.ss7.map.api.MAPMessage;
import org.restcomm.protocols.ss7.map.api.dialog.*;
import org.restcomm.protocols.ss7.map.api.errors.MAPErrorMessage;
import org.restcomm.protocols.ss7.map.api.primitives.*;
import org.restcomm.protocols.ss7.map.api.service.mobility.MAPDialogMobility;
import org.restcomm.protocols.ss7.map.api.service.mobility.MAPServiceMobilityListener;
import org.restcomm.protocols.ss7.map.api.service.mobility.authentication.*;
import org.restcomm.protocols.ss7.map.api.service.mobility.faultRecovery.*;
import org.restcomm.protocols.ss7.map.api.service.mobility.imei.*;
import org.restcomm.protocols.ss7.map.api.service.mobility.locationManagement.*;
import org.restcomm.protocols.ss7.map.api.service.mobility.oam.*;
import org.restcomm.protocols.ss7.map.api.service.mobility.subscriberInformation.*;
import org.restcomm.protocols.ss7.map.api.service.mobility.subscriberManagement.*;
import org.restcomm.protocols.ss7.tcap.asn.ApplicationContextName;
import org.restcomm.protocols.ss7.tcap.asn.comp.Problem;

public final class EirMapListener
        implements MAPDialogListener, MAPServiceMobilityListener {

    private static final Logger log =
            Logger.getLogger(EirMapListener.class);

    private final EquipmentService equipmentService;

    public EirMapListener(EquipmentService equipmentService) {
        this.equipmentService = equipmentService;
    }

    @Override
    public void onCheckImeiRequest(CheckImeiRequest request) {
        String imei =
                request.getIMEI() == null
                        ? null
                        : request.getIMEI().getIMEI();

        log.info("CheckIMEI request imei=" + imei);

        EquipmentDecision decision =
                equipmentService.checkImei(imei);

        EquipmentStatus mapStatus =
                EirMapResponse.WHITELISTED.equals(
                        EirResponsePolicy.responseFor(decision))
                        ? EquipmentStatus.whiteListed
                        : EquipmentStatus.blackListed;

        try {
            MAPDialogMobility dialog =
                    (MAPDialogMobility) request.getMAPDialog();

            dialog.addCheckImeiResponse(
                    request.getInvokeId(),
                    mapStatus,
                    null,
                    null
            );

            dialog.close(false);

            log.info(
                    "CheckIMEI response imei=" + imei +
                    " status=" + mapStatus +
                    " source=" + decision.source()
            );

        } catch (MAPException e) {
            log.error(
                    "Unable to send CheckIMEI response for imei=" + imei,
                    e
            );
        }
    }

    @Override public void onCheckImeiResponse(CheckImeiResponse response) {
        log.warn("Unexpected CheckIMEI response received by EIR");
    }

    @Override public void onErrorComponent(MAPDialog d, Long id, MAPErrorMessage e) { log.error("MAP error " + e); }
    @Override public void onInvokeTimeout(MAPDialog d, Long id) { log.error("MAP invoke timeout dialog=" + d.getLocalDialogId() + " invoke=" + id); }
    @Override public void onMAPMessage(MAPMessage m) { }

@Override public void onRejectComponent(MAPDialog d, Long id, Problem p, boolean isLocalOriginated) { log.error("MAP reject " + p); }

    @Override public void onDialogAccept(MAPDialog d, MAPExtensionContainer e) { }
    @Override public void onDialogClose(MAPDialog d) { log.debug("Dialog close " + d.getLocalDialogId()); }
    @Override public void onDialogDelimiter(MAPDialog d) { }
    @Override public void onDialogNotice(MAPDialog d, MAPNoticeProblemDiagnostic p) { log.error("Dialog notice " + p); }
    @Override public void onDialogProviderAbort(MAPDialog d, MAPAbortProviderReason r, MAPAbortSource s, MAPExtensionContainer e) { log.error("Provider abort " + r); }
    @Override public void onDialogRelease(MAPDialog d) { }
    @Override public void onDialogRequest(MAPDialog d, AddressString dest, AddressString orig, MAPExtensionContainer e) { }

    @Override
    public void onDialogRequestEricsson(MAPDialog mapDialog, AddressString destReference, AddressString origReference,
                                        AddressString eriImsi, AddressString eriVlrNo) {}

    @Override public void onDialogTimeout(MAPDialog d) { log.error("Dialog timeout " + d.getLocalDialogId()); }
    @Override public void onDialogUserAbort(MAPDialog d, MAPUserAbortChoice r, MAPExtensionContainer e) { log.error("User abort " + r); }

    @Override
    public void onDialogReject(
            MAPDialog d,
            MAPRefuseReason r,
            ApplicationContextName a,
            MAPExtensionContainer e) {
        log.error("Dialog reject " + r);
    }
    @Override
    public void onAnyTimeSubscriptionInterrogationRequest(
            org.restcomm.protocols.ss7.map.api.service.mobility.subscriberInformation.AnyTimeSubscriptionInterrogationRequest r) {
    }

    @Override
    public void onAnyTimeSubscriptionInterrogationResponse(
            org.restcomm.protocols.ss7.map.api.service.mobility.subscriberInformation.AnyTimeSubscriptionInterrogationResponse r) {
    }
    @Override public void onAnyTimeInterrogationRequest(AnyTimeInterrogationRequest r) { }
    @Override public void onAnyTimeInterrogationResponse(AnyTimeInterrogationResponse r) { }
    @Override public void onAuthenticationFailureReportRequest(AuthenticationFailureReportRequest r) { }
    @Override public void onAuthenticationFailureReportResponse(AuthenticationFailureReportResponse r) { }
    @Override public void onSendAuthenticationInfoRequest(SendAuthenticationInfoRequest r) { }
    @Override public void onSendAuthenticationInfoResponse(SendAuthenticationInfoResponse r) { }
    @Override public void onForwardCheckSSIndicationRequest(ForwardCheckSSIndicationRequest r) { }
    @Override public void onResetRequest(ResetRequest r) { }
    @Override public void onRestoreDataRequest(RestoreDataRequest r) { }
    @Override public void onRestoreDataResponse(RestoreDataResponse r) { }
    @Override public void onCancelLocationRequest(CancelLocationRequest r) { }
    @Override public void onCancelLocationResponse(CancelLocationResponse r) { }
    @Override public void onPurgeMSRequest(PurgeMSRequest r) { }
    @Override public void onPurgeMSResponse(PurgeMSResponse r) { }
    @Override public void onSendIdentificationRequest(SendIdentificationRequest r) { }
    @Override public void onSendIdentificationResponse(SendIdentificationResponse r) { }
    @Override public void onUpdateGprsLocationRequest(UpdateGprsLocationRequest r) { }
    @Override public void onUpdateGprsLocationResponse(UpdateGprsLocationResponse r) { }
    @Override public void onUpdateLocationRequest(UpdateLocationRequest r) { }
    @Override public void onUpdateLocationResponse(UpdateLocationResponse r) { }
    @Override public void onActivateTraceModeRequest_Mobility(ActivateTraceModeRequest_Mobility r) { }
    @Override public void onActivateTraceModeResponse_Mobility(ActivateTraceModeResponse_Mobility r) { }
    @Override public void onProvideSubscriberInfoRequest(ProvideSubscriberInfoRequest r) { }
    @Override public void onProvideSubscriberInfoResponse(ProvideSubscriberInfoResponse r) { }
    @Override public void onInsertSubscriberDataRequest(InsertSubscriberDataRequest r) { }
    @Override public void onInsertSubscriberDataResponse(InsertSubscriberDataResponse r) { }
    @Override public void onDeleteSubscriberDataRequest(DeleteSubscriberDataRequest r) { }
    @Override public void onDeleteSubscriberDataResponse(DeleteSubscriberDataResponse r) { }
}
