package com.example.eir.auth;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.security.Keys;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Collections;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

/**
 * Standards-compliant JWT provider for the management API.
 *
 * Uses HS256, includes subject/role/iat/exp/jti claims, validates expiration
 * and signature, and supports in-memory token revocation for the lifetime of
 * the process.
 */
public final class JwtTokenProvider {
    private static final int MIN_SECRET_BYTES = 32;

    private final SecretKey signingKey;
    private final int expiryMinutes;
    private final Set<String> blacklistedTokens;

    public JwtTokenProvider(String secret, int expiryMinutes) {
        Objects.requireNonNull(secret, "secret");
        if (secret.getBytes(StandardCharsets.UTF_8).length < MIN_SECRET_BYTES) {
            throw new IllegalArgumentException("JWT secret must be at least 32 UTF-8 bytes");
        }
        if (expiryMinutes <= 0) {
            throw new IllegalArgumentException("expiryMinutes must be > 0");
        }
        this.signingKey = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
        this.expiryMinutes = expiryMinutes;
        this.blacklistedTokens = Collections.synchronizedSet(new HashSet<>());
    }

    public String generateToken(User user) {
        Objects.requireNonNull(user, "user");
        Instant now = Instant.now();
        Instant expiry = now.plusSeconds(expiryMinutes * 60L);

        return Jwts.builder()
                .id(UUID.randomUUID().toString())
                .subject(user.getUsername())
                .claim("role", user.getRole().name())
                .issuedAt(java.util.Date.from(now))
                .expiration(java.util.Date.from(expiry))
                .signWith(signingKey, Jwts.SIG.HS256)
                .compact();
    }

    /** @return username if valid, otherwise null. */
    public String validateToken(String token) {
        Claims claims = parseClaims(token);
        return claims == null ? null : claims.getSubject();
    }

    public int getExpirySeconds() {
        return expiryMinutes * 60;
    }

    /** Extract role only from a fully valid token. */
    public Role extractRole(String token) {
        Claims claims = parseClaims(token);
        if (claims == null) {
            return null;
        }
        try {
            return Role.valueOf(claims.get("role", String.class));
        } catch (Exception e) {
            return null;
        }
    }

    public void revokeToken(String token) {
        if (token != null && !token.isBlank()) {
            // Validate before blacklisting so malformed input cannot grow the set.
            if (parseClaims(token) != null) {
                blacklistedTokens.add(token);
            }
        }
    }

    private Claims parseClaims(String token) {
        if (token == null || token.isBlank() || blacklistedTokens.contains(token)) {
            return null;
        }
        try {
            return Jwts.parser()
                    .verifyWith(signingKey)
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();
        } catch (JwtException | IllegalArgumentException e) {
            return null;
        }
    }
}
