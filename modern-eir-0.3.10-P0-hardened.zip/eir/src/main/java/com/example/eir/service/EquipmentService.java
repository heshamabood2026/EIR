package com.example.eir.service;

import com.example.eir.domain.Equipment;
import com.example.eir.domain.EquipmentDecision;
import com.example.eir.domain.EirEquipmentStatus;
import com.example.eir.exception.EquipmentRepositoryException;
import com.example.eir.repository.EquipmentRepository;
import java.time.Instant;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class EquipmentService {
    private static final String IMEI_PATTERN = "\\d{14,16}";

    private final EquipmentRepository repository;

    public EquipmentService(EquipmentRepository repository) {
        this.repository = repository;
    }

    public EquipmentDecision checkImei(String imei) {
        if (imei == null || !imei.matches(IMEI_PATTERN)) {
            return EquipmentDecision.invalidImei(imei);
        }

        try {
            Equipment equipment = repository.findByImei(imei);

            if (equipment == null) {
                return new EquipmentDecision(
                        imei,
                        EirEquipmentStatus.UNKNOWN,
                        repository.getClass().getSimpleName(),
                        "EQUIPMENT_NOT_FOUND",
                        null
                );
            }

            return EquipmentDecision.forEquipment(
                    equipment,
                    repository.getClass().getSimpleName()
            );
        } catch (EquipmentRepositoryException e) {
            return EquipmentDecision.databaseUnavailable(
                    imei,
                    repository.getClass().getSimpleName()
            );
        }
    }

    public Equipment createEquipment(String imei, String statusText) {
        EirEquipmentStatus status = parseStatus(statusText);
        String normalizedImei = normalizeImei(imei);
        if (repository.findByImei(normalizedImei) != null) {
            throw new IllegalArgumentException("Equipment already exists: " + normalizedImei);
        }
        Equipment equipment = Equipment.now(normalizedImei, status);
        repository.save(equipment);
        return equipment;
    }

    public Equipment updateEquipment(String imei, String statusText) {
        String normalizedImei = normalizeImei(imei);
        Equipment existing = repository.findByImei(normalizedImei);
        if (existing == null) {
            throw new IllegalArgumentException("Equipment not found: " + normalizedImei);
        }

        EirEquipmentStatus status = parseStatus(statusText);
        Equipment updated = new Equipment(
                normalizedImei,
                status,
                existing.createdAt(),
                Instant.now(),
                existing.auditMetadata()
        );
        repository.save(updated);
        return updated;
    }

    public Equipment getEquipment(String imei) {
        return repository.findByImei(normalizeImei(imei));
    }

    public List<Equipment> listEquipment() {
        return repository.findAll();
    }

    public void deleteEquipment(String imei) {
        String normalizedImei = normalizeImei(imei);
        if (repository.findByImei(normalizedImei) == null) {
            throw new IllegalArgumentException("Equipment not found: " + normalizedImei);
        }
        repository.delete(normalizedImei);
    }

    public List<Equipment> bulkImport(List<Equipment> items) {
        if (items == null || items.isEmpty()) {
            return List.of();
        }

        for (Equipment item : items) {
            if (item == null) {
                continue;
            }
            String imei = normalizeImei(item.imei());
            EirEquipmentStatus status = item.status() == null ? EirEquipmentStatus.UNKNOWN : item.status();
            Equipment normalized = new Equipment(
                    imei,
                    status,
                    item.createdAt() != null ? item.createdAt() : Instant.now(),
                    item.updatedAt() != null ? item.updatedAt() : Instant.now(),
                    item.auditMetadata() != null ? item.auditMetadata() : Map.of()
            );
            repository.save(normalized);
        }
        return items;
    }

    private static String normalizeImei(String imei) {
        if (imei == null) {
            throw new IllegalArgumentException("IMEI is required");
        }
        String normalized = imei.trim();
        if (!normalized.matches(IMEI_PATTERN)) {
            throw new IllegalArgumentException("Invalid IMEI: " + imei);
        }
        return normalized;
    }

    private static EirEquipmentStatus parseStatus(String statusText) {
        if (statusText == null || statusText.isBlank()) {
            throw new IllegalArgumentException("status is required");
        }
        try {
            return EirEquipmentStatus.valueOf(statusText.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException("Unsupported equipment status: " + statusText, ex);
        }
    }
}
