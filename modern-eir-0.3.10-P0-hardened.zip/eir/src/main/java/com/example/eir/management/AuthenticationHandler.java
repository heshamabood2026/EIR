package com.example.eir.management;

import com.example.eir.auth.*;
import org.apache.log4j.Logger;
import com.sun.net.httpserver.HttpExchange;

/**
 * HTTP handler for authentication endpoints.
 * Handles: login, token refresh, logout.
 */
public final class AuthenticationHandler {
    private static final Logger log = Logger.getLogger(AuthenticationHandler.class);
    
    private final UserRepository userRepository;
    private final JwtTokenProvider tokenProvider;
    
    public AuthenticationHandler(UserRepository userRepository, JwtTokenProvider tokenProvider) {
        this.userRepository = userRepository;
        this.tokenProvider = tokenProvider;
    }
    
    /**
     * Handle POST /api/auth/login
     * 
     * Request body: {"username":"<username>","password":"<password>"}
     * Response: {"token":"...","expiresIn":<seconds>,"role":"ADMIN"}
     */
    public void handleLogin(HttpExchange exchange) throws Exception {
        HttpRequest request = new HttpRequest(exchange);
        HttpResponse response = new HttpResponse(exchange);
        
        try {
            if (!"POST".equals(request.getMethod())) {
                response.error(405, "Method not allowed").send();
                return;
            }
            
            String body = request.getBody();
            if (body.isBlank()) {
                response.error(400, "Request body required").send();
                return;
            }
            
            // Simple JSON parsing (no library)
            String username = extractJsonField(body, "username");
            String password = extractJsonField(body, "password");
            
            if (username == null || username.isBlank() || password == null || password.isBlank()) {
                response.error(400, "username and password required").send();
                return;
            }
            
            // Authenticate through the repository so DB and in-memory stores use
            // the same password verification implementation.
            User user = userRepository.authenticate(username, password).orElse(null);
            if (user == null) {
                log.warn("Failed login attempt for user: " + username);
                response.error(401, "Invalid credentials").send();
                return;
            }
            
            // Generate token
            String token = tokenProvider.generateToken(user);
            String responseJson = String.format(
                    "{\"token\":\"%s\",\"expiresIn\":%d,\"role\":\"%s\"}",
                    token, tokenProvider.getExpirySeconds(), user.getRole().name()
            );
            
            response.status(200).json(responseJson).send();
            log.info("User logged in: " + username);
            
        } catch (Exception e) {
            log.error("Login handler error", e);
            response.error(500, "Internal server error").send();
        }
    }
    
    /**
     * Handle POST /api/auth/refresh
     * 
     * Request header: Authorization: Bearer <token>
     * Response: {"token":"...","expiresIn":<seconds>}
     */
    public void handleRefresh(HttpExchange exchange) throws Exception {
        HttpRequest request = new HttpRequest(exchange);
        HttpResponse response = new HttpResponse(exchange);
        
        try {
            if (!"POST".equals(request.getMethod())) {
                response.error(405, "Method not allowed").send();
                return;
            }
            
            String token = request.getAuthToken();
            if (token == null) {
                response.error(401, "Missing authorization header").send();
                return;
            }
            
            // Validate existing token
            String username = tokenProvider.validateToken(token);
            if (username == null) {
                response.error(401, "Invalid or expired token").send();
                return;
            }
            
            // Get user and generate new token
            User user = userRepository.findByUsername(username).orElse(null);
            if (user == null || !user.isEnabled()) {
                response.error(401, "User not found or disabled").send();
                return;
            }
            
            String newToken = tokenProvider.generateToken(user);
            String responseJson = String.format(
                    "{\"token\":\"%s\",\"expiresIn\":%d}",
                    newToken, tokenProvider.getExpirySeconds()
            );
            
            response.status(200).json(responseJson).send();
            log.info("Token refreshed for user: " + username);
            
        } catch (Exception e) {
            log.error("Refresh handler error", e);
            response.error(500, "Internal server error").send();
        }
    }
    
    /**
     * Handle POST /api/auth/logout
     * 
     * Request header: Authorization: Bearer <token>
     * Response: {"message":"Logged out successfully"}
     */
    public void handleLogout(HttpExchange exchange) throws Exception {
        HttpRequest request = new HttpRequest(exchange);
        HttpResponse response = new HttpResponse(exchange);
        
        try {
            if (!"POST".equals(request.getMethod())) {
                response.error(405, "Method not allowed").send();
                return;
            }
            
            String token = request.getAuthToken();
            if (token == null) {
                response.error(401, "Missing authorization header").send();
                return;
            }
            
            // Revoke token
            tokenProvider.revokeToken(token);
            
            String responseJson = "{\"message\":\"Logged out successfully\"}";
            response.status(200).json(responseJson).send();
            
            log.info("User logged out");
            
        } catch (Exception e) {
            log.error("Logout handler error", e);
            response.error(500, "Internal server error").send();
        }
    }
    
    /**
     * Extract JSON field value (simple parsing, no library).
     */
    private static String extractJsonField(String json, String fieldName) {
        String pattern = "\"" + fieldName + "\":\"";
        int start = json.indexOf(pattern);
        if (start == -1) {
            return null;
        }
        
        start += pattern.length();
        int end = json.indexOf("\"", start);
        if (end == -1) {
            return null;
        }
        
        return json.substring(start, end);
    }
    
}
