package com.example.eir.management;

import com.sun.net.httpserver.HttpExchange;
import org.apache.log4j.Logger;

/**
 * HTTP handler for serving the Management Dashboard HTML.
 */
public final class DashboardHandler {
    private static final Logger log = Logger.getLogger(DashboardHandler.class);

    private static final String HTML_CONTENT = """
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Modern EIR Management</title>
  <style>
    :root {
      --bg: #0f172a;
      --panel: #ffffff;
      --muted: #64748b;
      --accent: #2563eb;
      --accent2: #7c3aed;
      --success: #166534;
      --danger: #b91c1c;
      --warning: #a16207;
      --border: #e2e8f0;
    }
    * { box-sizing: border-box; }
    body { margin: 0; font-family: Arial, sans-serif; background: linear-gradient(135deg, #0f172a, #1e293b); color: #111827; min-height: 100vh; }
    .container { max-width: 1300px; margin: 0 auto; padding: 24px; }
    .header { text-align: center; color: white; margin-bottom: 24px; }
    .header h1 { margin: 0 0 8px; font-size: 2.4rem; }
    .header p { opacity: 0.9; margin: 0; }
    .login-box, .panel, .tab-panel { background: var(--panel); border-radius: 12px; box-shadow: 0 10px 30px rgba(15,23,42,0.2); padding: 20px; }
    .login-box { max-width: 420px; margin: 0 auto 24px; }
    .form-row { margin-bottom: 14px; }
    label { display: block; font-weight: 600; margin-bottom: 6px; color: #334155; }
    input, select, textarea, button { width: 100%; border: 1px solid var(--border); border-radius: 8px; padding: 10px 12px; font-size: 1rem; }
    textarea { min-height: 180px; resize: vertical; }
    button { cursor: pointer; }
    .primary-btn { background: linear-gradient(90deg, var(--accent), var(--accent2)); color: white; border: none; }
    .secondary-btn { background: #e2e8f0; color: #0f172a; border: none; }
    .danger-btn { background: #ef4444; color: white; border: none; }
    .message { display: none; padding: 10px 12px; border-radius: 8px; margin-bottom: 12px; }
    .message.error { display: block; background: #fee2e2; color: #991b1b; }
    .message.success { display: block; background: #dcfce7; color: #166534; }
    .hidden { display: none !important; }
    .topbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
    .user-badge { background: #dbeafe; color: #1d4ed8; padding: 8px 12px; border-radius: 999px; font-weight: 700; }
    .tabs { display: flex; flex-wrap: wrap; gap: 8px; margin: 12px 0 18px; }
    .tab-btn { flex: 1 1 180px; min-width: 140px; background: white; color: #0f172a; border: 1px solid var(--border); }
    .tab-btn.active { background: linear-gradient(90deg, var(--accent), var(--accent2)); color: white; border: none; }
    .tab-panel { display: none; }
    .tab-panel.active { display: block; }
    .stack { display: flex; flex-direction: column; gap: 12px; }
    .toolbar { display: flex; flex-wrap: wrap; gap: 10px; align-items: center; margin: 12px 0; }
    .compact { width: auto; min-width: 80px; }
    .inline { display: inline-flex; align-items: center; gap: 8px; }
    .code { font-family: Consolas, monospace; white-space: pre-wrap; }
    .table-wrap { overflow-x: auto; }
    table { width: 100%; border-collapse: collapse; margin-top: 12px; }
    th, td { border-bottom: 1px solid var(--border); padding: 10px 8px; text-align: left; }
    th { background: #f8fafc; }
    @media (max-width: 760px) { .container { padding: 12px; } .header h1 { font-size: 1.8rem; } .tabs { display: block; } .tab-btn { width: 100%; margin-bottom: 8px; } }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Modern EIR Management</h1>
      <p>Health, Equipment, DB, Audit, Config and User Administration</p>
    </div>

    <div id="loginBox" class="login-box">
      <h2>Dashboard Login</h2>
      <div id="loginMessage" class="message"></div>
      <div class="form-row">
        <label for="username">Username</label>
        <input id="username" type="text" autocomplete="username" />
      </div>
      <div class="form-row">
        <label for="password">Password</label>
        <input id="password" type="password" autocomplete="current-password" />
      </div>
      <button class="primary-btn" onclick="login()">Login</button>
      <div style="margin-top: 14px; color: #475569; font-size: 0.92rem;">
        <strong>Authentication:</strong><br />Use credentials provisioned by the deployment administrator.
      </div>
    </div>

    <div id="dashboard" class="hidden">
      <div class="topbar">
        <div class="user-badge" id="userBadge">User</div>
        <button class="danger-btn" style="width:auto;" onclick="logout()">Logout</button>
      </div>

      <div class="panel" style="margin-bottom: 16px;">
        <h3 style="margin-top:0;">JWT Token</h3>
        <div id="tokenBox" class="code" style="background:#f8fafc;border:1px solid var(--border);padding:12px;border-radius:8px;word-break:break-all;min-height:56px;">--</div>
      </div>

      <div class="tabs">
        <button class="tab-btn active" data-tab="health">Health</button>
        <button class="tab-btn" data-tab="equipment">Equipment</button>
        <button class="tab-btn" data-tab="database">Database Metrics</button>
        <button class="tab-btn" data-tab="pool">Pool</button>
        <button class="tab-btn" data-tab="audit">Audit</button>
        <button class="tab-btn" data-tab="accounts">Accounts_Management</button>
        <button class="tab-btn" data-tab="eirconf">EIRConf</button>
        <button class="tab-btn" data-tab="remoteconf">RemoteNEsConf</button>
        <button class="tab-btn" data-tab="settings">global settings</button>
      </div>

      <div id="health" class="tab-panel active">
        <div class="panel">
          <div class="toolbar"><button class="secondary-btn compact" onclick="refreshHealth()">Refresh</button></div>
          <div id="healthContent" class="code">Loading...</div>
        </div>
      </div>

      <div id="equipment" class="tab-panel">
        <div class="panel">
          <div class="toolbar"><button class="secondary-btn compact" onclick="refreshEquipment()">Refresh</button></div>
          <div id="equipmentContent" class="code">Loading...</div>
        </div>
      </div>

      <div id="database" class="tab-panel">
        <div class="panel">
          <div class="toolbar"><button class="secondary-btn compact" onclick="refreshDatabase()">Refresh</button></div>
          <div id="databaseContent" class="code">Loading...</div>
        </div>
      </div>

      <div id="pool" class="tab-panel">
        <div class="panel">
          <div class="toolbar"><button class="secondary-btn compact" onclick="refreshPool()">Refresh</button></div>
          <div id="poolContent" class="code">Loading...</div>
        </div>
      </div>

      <div id="audit" class="tab-panel">
        <div class="panel">
          <div class="toolbar">
            <button class="secondary-btn compact" onclick="refreshAudit()">Refresh</button>
            <label class="inline">Limit <input id="auditLimit" type="number" value="10" min="1" max="100" class="compact" /></label>
          </div>
          <div id="auditContent" class="code">Loading...</div>
        </div>
      </div>

      <div id="accounts" class="tab-panel">
        <div class="panel stack">
          <h3 style="margin:0;">Accounts_Management</h3>
          <div class="toolbar"><button class="secondary-btn compact" onclick="loadUsers()">Refresh users</button></div>
          <div class="form-row"><label>Username</label><input id="newUserName" type="text" placeholder="newuser" /></div>
          <div class="form-row"><label>Password</label><input id="newUserPassword" type="password" placeholder="Password" /></div>
          <div class="form-row"><label>Role</label><select id="newUserRole"><option value="VIEWER">VIEWER</option><option value="USER">USER</option><option value="ADMIN">ADMIN</option><option value="SUPER_ADMIN">SUPER_ADMIN</option></select></div>
          <button class="primary-btn" onclick="createUser()">Add user</button>
          <div id="accountMessage" class="message"></div>
          <div id="userTable" class="table-wrap"></div>
        </div>
      </div>

      <div id="eirconf" class="tab-panel">
        <div class="panel stack">
          <h3 style="margin:0;">EIRConf</h3>
          <div class="toolbar"><select id="eirConfigFile"></select><button class="secondary-btn compact" onclick="loadConfigFile('EIR')">Load</button></div>
          <textarea id="eirConfigText"></textarea>
          <button class="primary-btn" onclick="saveConfigFile('EIR')">Save</button>
        </div>
      </div>

      <div id="remoteconf" class="tab-panel">
        <div class="panel stack">
          <h3 style="margin:0;">RemoteNEsConf</h3>
          <div class="toolbar"><select id="mscConfigFile"></select><button class="secondary-btn compact" onclick="loadConfigFile('MSC')">Load</button></div>
          <textarea id="mscConfigText"></textarea>
          <button class="primary-btn" onclick="saveConfigFile('MSC')">Save</button>
        </div>
      </div>

      <div id="settings" class="tab-panel">
        <div class="panel stack">
          <h3 style="margin:0;">global settings</h3>
          <div class="toolbar"><button class="secondary-btn compact" onclick="loadGlobalSettings()">Refresh</button></div>
          <textarea id="globalSettingsText"></textarea>
          <button class="primary-btn" onclick="saveGlobalSettings()">Save</button>
        </div>
      </div>
    </div>
  </div>

  <script>
    var tokenKey = 'managementToken';
    var userKey = 'managementUser';
    var roleKey = 'managementRole';

    document.addEventListener('DOMContentLoaded', function() {
      bindTabs();
      var token = localStorage.getItem(tokenKey);
      if (token) {
        showDashboard(localStorage.getItem(userKey) || 'user', localStorage.getItem(roleKey) || 'ROLE', token);
        refreshHealth();
      }
      loadConfigList('EIR');
      loadConfigList('MSC');
    });

    function bindTabs() {
      var buttons = document.querySelectorAll('.tab-btn');
      buttons.forEach(function(btn) {
        btn.addEventListener('click', function() {
          var tab = btn.getAttribute('data-tab');
          buttons.forEach(function(b) {
            b.classList.toggle('active', b === btn);
          });
          document.querySelectorAll('.tab-panel').forEach(function(panel) {
            panel.classList.toggle('active', panel.id === tab);
          });
        });
      });
    }

    async function login() {
      var username = document.getElementById('username').value.trim();
      var password = document.getElementById('password').value;
      var msg = document.getElementById('loginMessage');
      msg.className = 'message';
      try {
        var res = await fetch('/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username: username, password: password })
        });
        var data = await res.json();
        if (!res.ok) { throw new Error(data.error || 'Login failed'); }
        localStorage.setItem(tokenKey, data.token);
        localStorage.setItem(userKey, username);
        localStorage.setItem(roleKey, data.role);
        showDashboard(username, data.role, data.token);
        refreshHealth();
      } catch (err) {
        msg.classList.add('error');
        msg.textContent = err.message;
      }
    }

    function showDashboard(username, role, token) {
      document.getElementById('loginBox').classList.add('hidden');
      document.getElementById('dashboard').classList.remove('hidden');
      document.getElementById('userBadge').textContent = (username || 'user') + ' / ' + (role || 'ROLE');
      document.getElementById('tokenBox').textContent = token || '--';
    }

    function logout() {
      localStorage.removeItem(tokenKey);
      localStorage.removeItem(userKey);
      localStorage.removeItem(roleKey);
      document.getElementById('dashboard').classList.add('hidden');
      document.getElementById('loginBox').classList.remove('hidden');
    }

    function authHeaders() {
      var token = localStorage.getItem(tokenKey);
      return { 'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json' };
    }

    async function apiGet(path) {
      var response = await fetch(path, { headers: authHeaders() });
      var text = await response.text();
      try {
        return { ok: response.ok, data: JSON.parse(text), status: response.status, raw: text };
      } catch (e) {
        return { ok: response.ok, data: text, status: response.status, raw: text };
      }
    }

    async function refreshHealth() {
      var r = await apiGet('/api/metrics/health');
      document.getElementById('healthContent').textContent = JSON.stringify(r.data, null, 2);
    }

    async function refreshEquipment() {
      var r = await apiGet('/api/metrics/equipment');
      document.getElementById('equipmentContent').textContent = JSON.stringify(r.data, null, 2);
    }

    async function refreshDatabase() {
      var r = await apiGet('/api/metrics/database');
      document.getElementById('databaseContent').textContent = JSON.stringify(r.data, null, 2);
    }

    async function refreshPool() {
      var r = await apiGet('/api/metrics/pool');
      document.getElementById('poolContent').textContent = JSON.stringify(r.data, null, 2);
    }

    async function refreshAudit() {
      var limit = document.getElementById('auditLimit').value || 10;
      var r = await apiGet('/api/audit/logs?limit=' + limit);
      document.getElementById('auditContent').textContent = JSON.stringify(r.data, null, 2);
    }

    async function loadUsers() {
      var result = await apiGet('/api/accounts/users');
      var table = document.getElementById('userTable');
      if (!result.ok || !Array.isArray(result.data)) {
        table.innerHTML = '<div class="message error">Unable to load users</div>';
        return;
      }
      if (!result.data.length) {
        table.innerHTML = '<p>No users defined.</p>';
        return;
      }
      table.innerHTML = '<table><thead><tr><th>Username</th><th>Role</th><th>Enabled</th><th>Action</th></tr></thead><tbody>' + result.data.map(function(u) {
        return '<tr><td>' + u.username + '</td><td>' + u.role + '</td><td>' + u.enabled + '</td><td><button class="danger-btn" style="width:auto;" onclick="deleteUser(\\'' + u.username + '\\')">Delete</button></td></tr>';
      }).join('') + '</tbody></table>';
    }

    async function createUser() {
      var message = document.getElementById('accountMessage');
      var username = document.getElementById('newUserName').value.trim();
      var password = document.getElementById('newUserPassword').value;
      var role = document.getElementById('newUserRole').value;
      if (!username || !password) {
        message.className = 'message error';
        message.textContent = 'Username and password are required';
        return;
      }
      var response = await fetch('/api/accounts/users', { method: 'POST', headers: authHeaders(), body: JSON.stringify({ username: username, password: password, role: role }) });
      var data = await response.json().catch(function() { return {}; });
      message.className = 'message ' + (response.ok ? 'success' : 'error');
      message.textContent = response.ok ? 'User created' : (data.error || 'Create failed');
      if (response.ok) {
        document.getElementById('newUserName').value = '';
        document.getElementById('newUserPassword').value = '';
        loadUsers();
      }
    }

    async function deleteUser(username) {
      if (!confirm('Delete user ' + username + '?')) return;
      var response = await fetch('/api/accounts/users/' + encodeURIComponent(username), { method: 'DELETE', headers: authHeaders() });
      var data = await response.json().catch(function() { return {}; });
      var msg = document.getElementById('accountMessage');
      msg.className = 'message ' + (response.ok ? 'success' : 'error');
      msg.textContent = response.ok ? 'User deleted' : (data.error || 'Delete failed');
      loadUsers();
    }

    async function loadGlobalSettings() {
      var result = await apiGet('/api/config/properties');
      var text = document.getElementById('globalSettingsText');
      if (result.ok && result.data && result.data.content) {
        text.value = result.data.content;
      } else {
        text.value = JSON.stringify(result.data, null, 2);
      }
    }

    async function saveGlobalSettings() {
      var content = document.getElementById('globalSettingsText').value;
      var response = await fetch('/api/config/properties', { method: 'PUT', headers: authHeaders(), body: JSON.stringify({ content: content }) });
      var data = await response.json().catch(function() { return {}; });
      alert(response.ok ? 'Settings saved' : (data.error || 'Save failed'));
    }

    async function loadConfigList(role) {
      var result = await apiGet('/api/config/' + role.toLowerCase());
      var select = document.getElementById(role === 'EIR' ? 'eirConfigFile' : 'mscConfigFile');
      var values = Array.isArray(result.data) ? result.data : [];
      select.innerHTML = values.map(function(v) {
        return '<option value="' + v + '">' + v + '</option>';
      }).join('');
      if (values[0]) {
        if (role === 'EIR') {
          document.getElementById('eirConfigText').value = 'Loading...';
        } else {
          document.getElementById('mscConfigText').value = 'Loading...';
        }
      }
    }

    async function loadConfigFile(role) {
      var select = document.getElementById(role === 'EIR' ? 'eirConfigFile' : 'mscConfigFile');
      var file = select.value;
      if (!file) return;
      var result = await apiGet('/api/config/file?role=' + role + '&path=' + encodeURIComponent(file));
      if (role === 'EIR') {
        document.getElementById('eirConfigText').value = result.data && result.data.content ? result.data.content : JSON.stringify(result.data, null, 2);
      } else {
        document.getElementById('mscConfigText').value = result.data && result.data.content ? result.data.content : JSON.stringify(result.data, null, 2);
      }
    }

    async function saveConfigFile(role) {
      var select = document.getElementById(role === 'EIR' ? 'eirConfigFile' : 'mscConfigFile');
      var file = select.value;
      if (!file) return alert('Select a file first');
      var content = role === 'EIR' ? document.getElementById('eirConfigText').value : document.getElementById('mscConfigText').value;
      var response = await fetch('/api/config/file?role=' + role + '&path=' + encodeURIComponent(file), { method: 'PUT', headers: authHeaders(), body: JSON.stringify({ content: content }) });
      var data = await response.json().catch(function() { return {}; });
      alert(response.ok ? 'Config saved' : (data.error || 'Save failed'));
    }
  </script>
</body>
</html>
""";

    public void handleDashboard(HttpExchange exchange) throws Exception {
        try {
            byte[] body = HTML_CONTENT.getBytes(java.nio.charset.StandardCharsets.UTF_8);
            exchange.getResponseHeaders().add("Content-Type", "text/html; charset=UTF-8");
            exchange.sendResponseHeaders(200, body.length);
            exchange.getResponseBody().write(body);
            exchange.getResponseBody().close();
        } catch (Exception e) {
            log.error("Failed to serve dashboard", e);
            throw e;
        }
    }
}