package com.example.eir.domain;

/**
 * EIR fail-closed response policy.
 *
 * Only explicitly whitelisted equipment is accepted by CheckIMEI.
 * Greylisted, blacklisted and unknown equipment are rejected. Invalid input
 * and database outages are also rejected; these are represented as UNKNOWN
 * decisions with a specific reason.
 */
public final class EirResponsePolicy {
    private EirResponsePolicy() {}

    public static EirMapResponse responseFor(EirEquipmentStatus status) {
        if (status == null) {
            return EirMapResponse.BLACKLISTED;
        }

        return status == EirEquipmentStatus.WHITELISTED
                ? EirMapResponse.WHITELISTED
                : EirMapResponse.BLACKLISTED;
    }

    public static EirMapResponse responseFor(EquipmentDecision decision) {
        if (decision == null) {
            return EirMapResponse.BLACKLISTED;
        }

        return responseFor(decision.status());
    }
}
