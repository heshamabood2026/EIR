package com.example.eir.auth;

/**
 * User roles for equipment management API.
 * 
 * VIEWER: Read-only access to equipment and metrics
 * USER: Read + Create equipment records
 * ADMIN: Full access including delete and user management
 */
public enum Role {
    VIEWER(1, "View only"),
    USER(2, "View and create"),
    HEALTHCHECK(2, "Health endpoint access"),
    EQUIPMENT(2, "Equipment management"),
    DATABASE_METRICS(2, "Database metrics"),
    POOL(2, "Pool metrics"),
    AUDIT(2, "Audit access"),
    ACCOUNTS_MANAGEMENT(3, "User/account management"),
    EIRCONF(3, "EIR config read/write"),
    REMOTE_NES_CONF(3, "Remote NE config read/write"),
    GLOBAL_SETTINGS(3, "Global settings access"),
    ADMIN(4, "Administration"),
    SUPER_ADMIN(5, "Full access");
    
    private final int level;
    private final String description;
    
    Role(int level, String description) {
        this.level = level;
        this.description = description;
    }
    
    public int getLevel() { return level; }
    public String getDescription() { return description; }
    
    /**
     * Check if this role can perform an action required by minRole.
     */
    public boolean canAccess(Role requiredRole) {
        return this.level >= requiredRole.level;
    }

    public static Role fromValue(String value) {
        if (value == null || value.isBlank()) {
            return VIEWER;
        }
        String normalized = value.trim().toUpperCase(java.util.Locale.ROOT).replace('-', '_');
        try {
            return Role.valueOf(normalized);
        } catch (IllegalArgumentException e) {
            return VIEWER;
        }
    }
}
