package com.example.eir.auth;

import java.time.Instant;
import java.util.Objects;

/**
 * User entity for equipment management API authentication.
 * 
 * Stores username, password hash, and role-based access control.
 * Passwords should always be stored hashed, never in plain text.
 */
public final class User {
    private final String username;
    private final String passwordHash;
    private final Role role;
    private final boolean enabled;
    private final Instant createdAt;
    private final Instant lastLogin;
    
    public User(
            String username, String passwordHash, Role role,
            boolean enabled, Instant createdAt, Instant lastLogin) {
        this.username = Objects.requireNonNull(username, "username");
        this.passwordHash = Objects.requireNonNull(passwordHash, "passwordHash");
        this.role = Objects.requireNonNull(role, "role");
        this.enabled = enabled;
        this.createdAt = Objects.requireNonNull(createdAt, "createdAt");
        this.lastLogin = lastLogin;
        
        if (username.isBlank()) {
            throw new IllegalArgumentException("username must not be blank");
        }
        if (passwordHash.isBlank()) {
            throw new IllegalArgumentException("passwordHash must not be blank");
        }
    }
    
    /**
     * Create a new user with initial defaults.
     */
    public static User create(String username, String passwordHash, Role role) {
        Instant now = Instant.now();
        return new User(username, passwordHash, role, true, now, null);
    }
    
    public String getUsername() { return username; }
    public String getPasswordHash() { return passwordHash; }
    public Role getRole() { return role; }
    public boolean isEnabled() { return enabled; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getLastLogin() { return lastLogin; }
    
    /**
     * Check if user can perform action requiring specified role.
     */
    public boolean canAccess(Role requiredRole) {
        return enabled && role.canAccess(requiredRole);
    }
}
