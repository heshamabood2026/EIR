package com.example.eir;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilderFactory;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

/**
 * EIR/MSC configuration loader.
 *
 * <p>The protocol stack is transport-neutral. Use {@code sctp} on a platform
 * with JDK SCTP support, or {@code tcp} for Windows/local integration tests.
 * TCP mode uses the project's RestComm transport adapter and does not add a
 * Mobicents SCTP dependency.</p>
 */
public final class EirConfig {
    public final String role;
    public final String channelType;
    public final int connectDelay;
    public final List<AssociationConfig> associations;

    public final String sctpName;
    public final String serverName;
    public final String associationName;
    public final String localIp;
    public final int localPort;
    public final String peerIp;
    public final int peerPort;

    public final String m3uaName;
    public final String asName;
    public final String aspName;
    public final String functionality;
    public final String exchangeType;
    public final String ipspType;
    public final long routingContext;
    public final int trafficMode;
    public final int minAspActiveForLb;
    public final int routeDpc;

    public final int localSpc;
    public final int remoteSpcId;
    public final int remoteSsnId;
    public final int remoteSpc;
    public final int remoteSsn;
    public final int localSsn;
    public final int networkIndicator;
    public final int mtp3Id;
    public final int sapId;
    public final int sapNetworkId;
    public final int destinationFirstDpc;
    public final int destinationLastDpc;
    public final int destinationFirstSls;
    public final int destinationLastSls;
    public final int destinationSlsMask;
    public final String sapLocalGtDigits;

    public final int tcapDialogIdleTimeout;
    public final int tcapInvokeTimeout;
    public final int tcapMaxDialogs;

    public final String localGt;
    public final String remoteGt;
    public final boolean dbEnabled;
    public final String dbUrl;
    public final String dbUser;
    public final String dbPassword;
    public final int dbPoolSize;
    public final long dbConnectionTimeoutMs;
    public final long dbValidationTimeoutMs;
    public final int dbQueryTimeoutSeconds;

    private EirConfig(String role, File baseDir, String transport) throws Exception {
        this.role = role.toUpperCase(Locale.ROOT);
        this.channelType = normalizeTransport(transport);

        this.sctpName = this.role + "-SCTP";
        List<AssociationConfig> loadedAssociations = loadAssociations(baseDir, this.role);
        if ("sctp".equals(this.channelType)) validateSctpMultihoming(loadedAssociations);
        this.associations = Collections.unmodifiableList(loadedAssociations);
        prepareRuntimeM3ua(baseDir, this.role, this.associations);
        prepareRuntimeSccp(baseDir, this.role, this.associations);
        Document sctp = xml(baseDir, this.role + "-SCTP_sctp.xml");
        Document m3ua = xml(baseDir, this.role + "-M3UA_m3ua1.xml");
        Document resource = xml(baseDir, this.role + "-SCCP_sccpresource2.xml");
        Document router = xml(baseDir, this.role + "-SCCP_sccprouter3.xml");
        Document tcap = xml(baseDir, this.role + "-TCAP_management.xml");
        Document app = xml(baseDir, this.role + "-application.xml");

        Element server = first(sctp, "server");
        Element assoc = first(sctp, "association");
        this.connectDelay = attrInt(first(sctp, "connectdelay"), "value", 10000);
        AssociationConfig firstAssociation = this.associations.get(0);
        this.serverName = firstAssociation.serverName();
        this.associationName = firstAssociation.name();
        this.localIp = firstAssociation.localAddress();
        this.localPort = firstAssociation.localPort();
        this.peerIp = firstAssociation.peerAddress();
        this.peerPort = firstAssociation.peerPort();

        Element as = first(m3ua, "as");
        Element asp = first(m3ua, "aspFactory");
        Element rc = first(m3ua, "rc");
        Element tm = first(m3ua, "trafficMode");
        Element routeKey = first(m3ua, "key");

        this.m3uaName = this.role + "-M3UA";
        this.asName = attr(as, "name", this.role + "_AS");
        this.aspName = attr(asp, "name", this.role + "_ASP");
        this.functionality = attr(as, "functionality", "AS");
        this.exchangeType = attr(as, "exchangeType", "SE");
        this.ipspType = attr(as, "ipspType", "CLIENT");
        this.routingContext = attrLong(rc, "value", 100L);
        this.trafficMode = attrInt(tm, "mode", 2);
        this.minAspActiveForLb = attrInt(as, "minAspActiveForLb", 1);
        this.routeDpc = parseRouteDpc(attr(routeKey, "value", "0:-1:-1"));

        Element remoteSpcIdElement = first(resource, "remoteSpcs/id");
        Element remoteSsnIdElement = first(resource, "remoteSsns/id");
        Element remoteSpc = first(resource, "remoteSpcs/value");
        Element remoteSsn = first(resource, "remoteSsns/value");
        this.remoteSpcId = attrInt(remoteSpcIdElement, "value", 0);
        this.remoteSsnId = attrInt(remoteSsnIdElement, "value", 0);
        this.remoteSpc = attrInt(remoteSpc, "remoteSpc", this.role.equals("EIR") ? 1 : 2);
        this.remoteSsn = attrInt(remoteSsn, "remoteSsn", this.role.equals("EIR") ? 8 : 146);

        Element sap = first(router, "sap/value");
        Element dest = first(router, "mtp3DestinationMap/value");
        this.mtp3Id = attrInt(sap, "mtp3Id", 1);
        this.sapId = attrInt(first(router, "sap/id"), "value", 1);
        this.sapNetworkId = attrInt(sap, "networkId", 0);
        this.localSpc = attrInt(sap, "opc", this.role.equals("EIR") ? 2 : 1);
        this.networkIndicator = attrInt(sap, "ni", 2);
        this.sapLocalGtDigits = attr(sap, "localGtDigits", "SAP_1");
        this.destinationFirstDpc = attrInt(dest, "firstDpc", this.remoteSpc);
        this.destinationLastDpc = attrInt(dest, "lastDpc", this.remoteSpc);
        this.destinationFirstSls = attrInt(dest, "firstSls", 0);
        this.destinationLastSls = attrInt(dest, "lastSls", 255);
        this.destinationSlsMask = attrInt(dest, "slsMask", 255);

        this.localSsn = attrInt(first(app, "localSsn"), "value", this.role.equals("EIR") ? 146 : 8);
        this.localGt = attr(first(app, "localGt"), "value", this.role.equals("EIR") ? "2222222222" : "1111111111");
        this.remoteGt = attr(first(app, "remoteGt"), "value", this.role.equals("EIR") ? "1111111111" : "2222222222");

        this.tcapDialogIdleTimeout = attrInt(first(tcap, "dialogidletimeout"), "value", 60000);
        this.tcapInvokeTimeout = attrInt(first(tcap, "invoketimeout"), "value", 30000);
        this.tcapMaxDialogs = attrInt(first(tcap, "maxdialogs"), "value", 25000);

        Properties properties = loadApplicationProperties();
        this.dbEnabled = booleanSetting(properties, "eir.database.enabled", "EIR_DB_ENABLED", false);
        this.dbUrl = stringSetting(properties, "eir.database.url", "EIR_DB_URL",
                "jdbc:mysql://127.0.0.1:3306/eir?useSSL=false&serverTimezone=UTC");
        this.dbUser = stringSetting(properties, "eir.database.user", "EIR_DB_USER", "eir");
        this.dbPassword = stringSetting(properties, "eir.database.password", "EIR_DB_PASSWORD", "");
        this.dbPoolSize = intSetting(properties, "eir.database.pool-size", "EIR_DB_POOL_SIZE", 10);
        this.dbConnectionTimeoutMs = longSetting(properties, "eir.database.connection-timeout-ms",
                "EIR_DB_CONNECTION_TIMEOUT_MS", 3000L);
        this.dbValidationTimeoutMs = longSetting(properties, "eir.database.validation-timeout-ms",
                "EIR_DB_VALIDATION_TIMEOUT_MS", 1000L);
        this.dbQueryTimeoutSeconds = intSetting(properties, "eir.database.query-timeout-seconds",
                "EIR_DB_QUERY_TIMEOUT_SECONDS", 5);
    }

    public static EirConfig load(String role, String transport) throws Exception {
        String normalizedTransport = normalizeTransport(transport);
        return load(role, normalizedTransport, true);
    }

    public static EirConfig load(String role) throws Exception {
        return load(role, "sctp");
    }

    public static EirConfig load(String role, File projectDir) throws Exception {
        return load(role, projectDir, "sctp");
    }

    private static EirConfig load(String role, String transport, boolean ignored) throws Exception {
        File projectDir = new File(System.getProperty("user.dir")).getCanonicalFile();
        return load(role, projectDir, transport);
    }

    public static EirConfig load(String role, File projectDir, String transport) throws Exception {
        String normalizedRole = role.toUpperCase(Locale.ROOT);
        File initialDir = new File(projectDir, "config" + File.separator + "initial"
                + File.separator + normalizedRole);
        File runtimeDir = new File(projectDir, "config" + File.separator + "runtime"
                + File.separator + normalizedRole);

        prepareRuntimeDirectory(initialDir, runtimeDir);
        System.setProperty("user.dir", runtimeDir.getCanonicalPath());
        return new EirConfig(normalizedRole, runtimeDir, transport);
    }

    private static String normalizeTransport(String transport) {
        if (transport == null || transport.isBlank()) return "sctp";
        if (transport.equalsIgnoreCase("sctp")) return "sctp";
        if (transport.equalsIgnoreCase("tcp")) return "tcp";
        throw new IllegalArgumentException("Transport must be sctp or tcp: " + transport);
    }

    private static void prepareRuntimeDirectory(File initialDir, File runtimeDir) throws Exception {
        if (!initialDir.isDirectory()) {
            throw new IllegalStateException("Missing initial XML configuration directory: " + initialDir.getCanonicalPath());
        }
        Files.createDirectories(runtimeDir.toPath());
        File[] files = initialDir.listFiles((dir, name) -> name.toLowerCase(Locale.ROOT).endsWith(".xml"));
        if (files == null || files.length == 0) {
            throw new IllegalStateException("No XML configuration files found in " + initialDir.getCanonicalPath());
        }
        for (File source : files) {
            File target = new File(runtimeDir, source.getName());
            Files.copy(source.toPath(), target.toPath(),
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                    java.nio.file.StandardCopyOption.COPY_ATTRIBUTES);
        }
    }



    private static void validateSctpMultihoming(List<AssociationConfig> associations) {
        for (AssociationConfig a : associations) {
            if (a.hasBackupLocal() && a.backupLocalPort() != a.localPort()) {
                throw new IllegalArgumentException("SCTP association " + a.name()
                        + " backupLocalPort must equal localPort; SCTP multihoming uses one transport port");
            }
            if (a.hasBackupPeer() && a.backupPeerPort() != a.peerPort()) {
                throw new IllegalArgumentException("SCTP association " + a.name()
                        + " backupPeerPort must equal peerPort; SCTP multihoming uses one transport port");
            }
        }
    }
    private static List<AssociationConfig> loadAssociations(File dir, String role) throws Exception {
        String prefix = role.toUpperCase(Locale.ROOT);
        File f = new File(dir, prefix + "-associations.xml");
        if (!f.isFile()) {
            // Backward-compatible single-association configuration for each role.
            Document sctp = xml(dir, prefix + "-SCTP_sctp.xml");
            Element server = first(sctp, "server");
            Element assoc = first(sctp, "association");
            String serverName = attr(server, "name", "EIR_SERVER");
            String name = attr(assoc, "name", "EIR_ASSOC");
            boolean serverMode = "SERVER".equalsIgnoreCase(attr(assoc, "assoctype", "SERVER"));
            String localAddress = serverMode ? attr(server, "hostAddress", "127.0.0.1") : attr(assoc, "hostAddress", "127.0.0.1");
            int localPort = serverMode ? attrInt(server, "hostPort", 2906) : attrInt(assoc, "hostPort", 2905);
            String peerAddress = attr(assoc, "peerAddress", "127.0.0.1");
            int peerPort = attrInt(assoc, "peerPort", serverMode ? 2905 : 2906);
            int remoteSpc = 1;
            int remoteSsn = 8;
            Document resource = xml(dir, prefix + "-SCCP_sccpresource2.xml");
            remoteSpc = attrInt(first(resource, "remoteSpcs/value"), "remoteSpc", remoteSpc);
            remoteSsn = attrInt(first(resource, "remoteSsns/value"), "remoteSsn", remoteSsn);
            return new ArrayList<>(List.of(new AssociationConfig(name, serverMode ? "server" : "client",
                    localAddress, localPort, null, 0, peerAddress, peerPort, null, 0, serverName,
                    "EIR_ASP", "EIR_AS", 100L, 3, remoteSpc, remoteSpc, remoteSsn, true)));
        }
        Document d = xml(dir, prefix + "-associations.xml");
        List<AssociationConfig> result = new ArrayList<>();
        NodeList nodes = d.getElementsByTagName("association");
        for (int i = 0; i < nodes.getLength(); i++) {
            Element e = (Element) nodes.item(i);
            String name = attr(e, "name", "MSC" + (i + 1));
            String mode = attr(e, "mode", "server");
            String localAddress = attr(e, "localAddress", "127.0.0.1");
            int localPort = attrInt(e, "localPort", 2906 + i);
            String backupLocalAddress = attr(e, "backupLocalAddress", null);
            int backupLocalPort = attrInt(e, "backupLocalPort", 0);
            String peerAddress = attr(e, "peerAddress", attr(e, "primaryPeerAddress", "127.0.0.1"));
            int peerPort = attrInt(e, "peerPort", attrInt(e, "primaryPeerPort", 2905));
            String backupPeerAddress = attr(e, "backupPeerAddress", null);
            int backupPeerPort = attrInt(e, "backupPeerPort", 0);
            String serverName = attr(e, "serverName", name + "_SERVER");
            String aspName = attr(e, "aspName", name + "_ASP");
            String asName = attr(e, "asName", name + "_AS");
            long rc = attrLong(e, "routingContext", 100L + i);
            int aspid = attrInt(e, "aspid", 3 + i);
            int routeDpc = attrInt(e, "routeDpc", attrInt(e, "remoteSpc", 1 + i));
            int remoteSpc = attrInt(e, "remoteSpc", routeDpc);
            int remoteSsn = attrInt(e, "remoteSsn", 8);
            boolean started = Boolean.parseBoolean(attr(e, "started", "true"));
            result.add(new AssociationConfig(name, mode, localAddress, localPort, backupLocalAddress, backupLocalPort,
                    peerAddress, peerPort, backupPeerAddress, backupPeerPort, serverName, aspName, asName, rc, aspid, routeDpc, remoteSpc, remoteSsn, started));
        }
        if (result.isEmpty()) throw new IllegalStateException(prefix + "-associations.xml contains no association elements");
        Set<String> names = new LinkedHashSet<>();
        for (AssociationConfig a : result) if (!names.add(a.name())) throw new IllegalArgumentException("Duplicate association name: " + a.name());
        return result;
    }

    private static void prepareRuntimeM3ua(File dir, String role, List<AssociationConfig> associations) throws Exception {
        if (!"EIR".equalsIgnoreCase(role)) return;
        File f = new File(dir, "EIR-M3UA_m3ua1.xml");
        String text = Files.readString(f.toPath(), StandardCharsets.UTF_8);
        text = text.replaceFirst("(?s)<aspFactoryList>.*?</aspFactoryList>",
                "<aspFactoryList>" + buildAspFactories(associations) + "</aspFactoryList>");
        text = text.replaceFirst("(?s)<asList>.*?</asList>", "<asList>" + buildAsList(associations) + "</asList>");
        text = text.replaceFirst("(?s)<route>.*?</route>", buildRoutes(associations));
        Files.writeString(f.toPath(), text, StandardCharsets.UTF_8);
    }

    private static String buildAspFactories(List<AssociationConfig> associations) {
        StringBuilder b = new StringBuilder();
        for (AssociationConfig a : associations) {
            b.append("<aspFactory name=\"").append(a.aspName()).append("\" assocName=\"")
                    .append(a.name()).append("\" started=\"").append(a.started())
                    .append("\" maxseqnumber=\"256\" aspid=\"").append(a.aspid())
                    .append("\" heartbeat=\"false\"/>\n");
        }
        return b.toString();
    }

    private static String buildAsList(List<AssociationConfig> associations) {
        Map<String, List<AssociationConfig>> groups = new LinkedHashMap<>();
        for (AssociationConfig a : associations) groups.computeIfAbsent(a.asName(), k -> new ArrayList<>()).add(a);
        StringBuilder b = new StringBuilder();
        for (List<AssociationConfig> group : groups.values()) {
            AssociationConfig first = group.get(0);
            b.append("<as name=\"").append(first.asName()).append("\" minAspActiveForLb=\"1\" functionality=\"SGW\" exchangeType=\"SE\" ipspType=\"SERVER\">\n")
                    .append("<routingContext size=\"1\"><rc value=\"").append(first.routingContext()).append("\"/></routingContext>\n")
                    .append("<trafficMode mode=\"2\"/><defTrafficMode mode=\"2\"/><asps>\n");
            for (AssociationConfig a : group) b.append("<asp name=\"").append(a.aspName()).append("\"/>\n");
            b.append("</asps></as>\n");
        }
        return b.toString();
    }

    private static String buildRoutes(List<AssociationConfig> associations) {
        Map<Integer, String> routes = new LinkedHashMap<>();
        for (AssociationConfig a : associations) routes.putIfAbsent(a.routeDpc(), a.asName());
        StringBuilder b = new StringBuilder();
        for (Map.Entry<Integer, String> e : routes.entrySet()) {
            b.append("<route><key value=\"").append(e.getKey()).append(":-1:-1\"/><routeAs trafficModeType=\"2\" as=\"")
                    .append(e.getValue()).append("\"/></route>\n");
        }
        return b.toString();
    }

    private static void prepareRuntimeSccp(File dir, String role, List<AssociationConfig> associations) throws Exception {
        if (!"EIR".equalsIgnoreCase(role)) return;
        File resource = new File(dir, "EIR-SCCP_sccpresource2.xml");
        StringBuilder r = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n<remoteSsns>\n");
        int id = 0;
        Set<String> ssnKeys = new LinkedHashSet<>();
        for (AssociationConfig a : associations) {
            String key = a.remoteSpc() + ":" + a.remoteSsn();
            if (!ssnKeys.add(key)) continue;
            r.append("<id value=\"").append(id++).append("\"/><value remoteSpc=\"").append(a.remoteSpc())
                    .append("\" remoteSsn=\"").append(a.remoteSsn()).append("\" remoteSsnFlag=\"0\" markProhibitedWhenSpcResuming=\"false\"/>\n");
        }
        r.append("</remoteSsns>\n<remoteSpcs>\n");
        id = 0;
        Set<Integer> spcs = new LinkedHashSet<>();
        for (AssociationConfig a : associations) if (spcs.add(a.remoteSpc())) {
            r.append("<id value=\"").append(id++).append("\"/><value remoteSpc=\"").append(a.remoteSpc()).append("\" remoteSpcFlag=\"0\" mask=\"0\"/>\n");
        }
        r.append("</remoteSpcs>\n<concernedSpcs/>\n");
        Files.writeString(resource.toPath(), r.toString(), StandardCharsets.UTF_8);

        File router = new File(dir, "EIR-SCCP_sccprouter3.xml");
        StringBuilder q = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n<longMessageRule/>\n<sap>\n<id value=\"1\"/><value mtp3Id=\"1\" opc=\"2\" ni=\"2\" networkId=\"0\">\n<mtp3DestinationMap>\n");
        id = 1;
        Set<Integer> routeDpcs = new LinkedHashSet<>();
        for (AssociationConfig a : associations) {
            if (!routeDpcs.add(a.routeDpc())) continue;
            q.append("<id value=\"").append(id++).append("\"/><value firstDpc=\"").append(a.routeDpc()).append("\" lastDpc=\"")
                    .append(a.routeDpc()).append("\" firstSls=\"0\" lastSls=\"255\" slsMask=\"255\"/>\n");
        }
        q.append("</mtp3DestinationMap>\n</value>\n</sap>\n");
        Files.writeString(router.toPath(), q.toString(), StandardCharsets.UTF_8);
    }

    public static String parseCommandLineType(String[] args) {
        if (args == null || args.length == 0 || args[0] == null || args[0].isBlank()) return "sctp";
        return parseCommandLineType(args[0]);
    }

    public static String parseCommandLineType(String value) {
        return normalizeTransport(value);
    }

    private static Properties loadApplicationProperties() throws Exception {
        Properties p = new Properties();
        try (InputStream in = EirConfig.class.getClassLoader().getResourceAsStream("application.properties")) {
            if (in == null) throw new IllegalStateException("Missing application.properties");
            p.load(in);
        }
        return p;
    }

    private static String stringSetting(Properties p, String key, String env, String defaultValue) {
        String value = System.getenv(env);
        return value == null || value.isBlank() ? p.getProperty(key, defaultValue) : value;
    }
    private static boolean booleanSetting(Properties p, String key, String env, boolean defaultValue) {
        return Boolean.parseBoolean(stringSetting(p, key, env, Boolean.toString(defaultValue)));
    }
    private static int intSetting(Properties p, String key, String env, int defaultValue) {
        try { return Integer.parseInt(stringSetting(p, key, env, Integer.toString(defaultValue)).trim()); }
        catch (NumberFormatException e) { throw new IllegalArgumentException("Invalid integer setting " + key, e); }
    }
    private static long longSetting(Properties p, String key, String env, long defaultValue) {
        try { return Long.parseLong(stringSetting(p, key, env, Long.toString(defaultValue)).trim()); }
        catch (NumberFormatException e) { throw new IllegalArgumentException("Invalid long setting " + key, e); }
    }

    private static int parseRouteDpc(String value) {
        try { return Integer.parseInt(value.split(":")[0]); }
        catch (Exception e) { throw new IllegalArgumentException("Invalid M3UA route key: " + value, e); }
    }

    private static Document xml(File dir, String name) throws Exception {
        File f = new File(dir, name);
        if (!f.isFile()) throw new IllegalStateException("Missing XML configuration: " + f.getAbsolutePath());
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        dbf.setFeature("http://xml.org/sax/features/external-general-entities", false);
        dbf.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
        dbf.setExpandEntityReferences(false);
        String text = Files.readString(f.toPath(), StandardCharsets.UTF_8);
        text = text.replaceFirst("^\\s*<\\?xml[^>]*>\\s*", "");
        return dbf.newDocumentBuilder().parse(
                new ByteArrayInputStream(("<configuration>" + text + "</configuration>").getBytes(StandardCharsets.UTF_8)));
    }

    private static Element first(Document d, String path) {
        String[] parts = path.split("/");
        if (parts.length == 1) {
            NodeList all = d.getElementsByTagName(parts[0]);
            return all.getLength() == 0 ? null : (Element) all.item(0);
        }
        Node node = d;
        for (String part : parts) {
            NodeList children = node instanceof Document ? node.getChildNodes() : node.getChildNodes();
            Node found = null;
            for (int i = 0; i < children.getLength(); i++) {
                Node n = children.item(i);
                if (n.getNodeType() == Node.ELEMENT_NODE && n.getNodeName().equals(part)) { found = n; break; }
            }
            if (found == null) return null;
            node = found;
        }
        return node instanceof Element ? (Element) node : null;
    }

    private static String attr(Element e, String name, String fallback) {
        return e == null || !e.hasAttribute(name) || e.getAttribute(name).isBlank() ? fallback : e.getAttribute(name).trim();
    }
    private static int attrInt(Element e, String name, int fallback) { return Integer.parseInt(attr(e, name, Integer.toString(fallback))); }
    private static long attrLong(Element e, String name, long fallback) { return Long.parseLong(attr(e, name, Long.toString(fallback))); }
}
