package com.example.eir.audit;

import java.time.Instant;
import java.util.Objects;

/**
 * Structured audit log record for equipment identity checks.
 * 
 * Captures every equipment decision: timestamp, IMEI, status, reason,
 * source (repository type), user, and API request ID for correlation.
 */
public final class AuditLog {
    
    private final long id;
    private final Instant timestamp;
    private final String imei;
    private final String status;
    private final String reason;
    private final String source;
    private final String userId;
    private final String requestId;
    
    public AuditLog(
            long id, Instant timestamp, String imei, String status,
            String reason, String source, String userId, String requestId) {
        this.id = id;
        this.timestamp = Objects.requireNonNull(timestamp, "timestamp");
        this.imei = Objects.requireNonNull(imei, "imei");
        this.status = Objects.requireNonNull(status, "status");
        this.reason = Objects.requireNonNull(reason, "reason");
        this.source = Objects.requireNonNull(source, "source");
        this.userId = userId;
        this.requestId = requestId;
        
        if (imei.isBlank()) {
            throw new IllegalArgumentException("imei must not be blank");
        }
    }
    
    /**
     * Create audit log from equipment decision.
     */
    public static AuditLog fromDecision(
            com.example.eir.domain.EquipmentDecision decision,
            String userId, String requestId) {
        return new AuditLog(
                0, // ID auto-assigned on save
                Instant.now(),
                decision.imei(),
                decision.status().name(),
                decision.reason(),
                decision.source(),
                userId,
                requestId
        );
    }
    
    public long getId() { return id; }
    public Instant getTimestamp() { return timestamp; }
    public String getImei() { return imei; }
    public String getStatus() { return status; }
    public String getReason() { return reason; }
    public String getSource() { return source; }
    public String getUserId() { return userId; }
    public String getRequestId() { return requestId; }
}
