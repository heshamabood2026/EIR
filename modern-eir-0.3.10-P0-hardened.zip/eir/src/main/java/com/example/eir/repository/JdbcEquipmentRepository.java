package com.example.eir.repository;

import com.example.eir.domain.Equipment;
import com.example.eir.domain.EirEquipmentStatus;
import com.example.eir.exception.EquipmentRepositoryException;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class JdbcEquipmentRepository implements EquipmentRepository {
    private final DataSource dataSource;
    private final int queryTimeoutSeconds;

    public JdbcEquipmentRepository(DataSource dataSource, int queryTimeoutSeconds) {
        if (dataSource == null) {
            throw new IllegalArgumentException("dataSource must not be null");
        }
        if (queryTimeoutSeconds < 0) {
            throw new IllegalArgumentException("queryTimeoutSeconds must be >= 0");
        }
        this.dataSource = dataSource;
        this.queryTimeoutSeconds = queryTimeoutSeconds;
    }

    @Override
    public void save(Equipment equipment) {
        String sql = "INSERT INTO equipment_identity (imei, status, created_at, updated_at, description, reason, source) "
               + "VALUES (?, ?, ?, ?, ?, ?, ?) "
               + "ON DUPLICATE KEY UPDATE status = VALUES(status), updated_at = VALUES(updated_at), "
               + "description = COALESCE(VALUES(description), description), "
               + "reason = COALESCE(VALUES(reason), reason), source = COALESCE(VALUES(source), source)";

        try (Connection c = dataSource.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            if (queryTimeoutSeconds > 0) {
               ps.setQueryTimeout(queryTimeoutSeconds);
            }
            ps.setString(1, equipment.imei());
            ps.setString(2, equipment.status().name());
            ps.setTimestamp(3, Timestamp.from(equipment.createdAt()));
            ps.setTimestamp(4, Timestamp.from(equipment.updatedAt()));
            ps.setString(5, equipment.auditMetadata().get("description"));
            ps.setString(6, equipment.auditMetadata().get("reason"));
            ps.setString(7, equipment.auditMetadata().get("source"));
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new EquipmentRepositoryException("EIR database write failed", e);
        }
    }

    @Override
    public void delete(String imei) {
        String sql = "DELETE FROM equipment_identity WHERE imei = ?";

        try (Connection c = dataSource.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            if (queryTimeoutSeconds > 0) {
               ps.setQueryTimeout(queryTimeoutSeconds);
            }
            ps.setString(1, imei);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new EquipmentRepositoryException("EIR database delete failed", e);
        }
    }

    @Override
    public List<Equipment> findAll() {
        String sql = "SELECT imei, status, created_at, updated_at, description, reason, source FROM equipment_identity";
        List<Equipment> results = new ArrayList<>();

        try (Connection c = dataSource.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            if (queryTimeoutSeconds > 0) {
               ps.setQueryTimeout(queryTimeoutSeconds);
            }

            try (ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
               results.add(readEquipment(rs));
            }
            return results;
            }
        } catch (SQLException e) {
            throw new EquipmentRepositoryException("EIR database list failed", e);
        }
    }

    @Override
    public Equipment findByImei(String imei) {
        String sql = "SELECT imei, status, created_at, updated_at, "
               + "description, reason, source "
               + "FROM equipment_identity WHERE imei = ?";

        try (Connection c = dataSource.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            if (queryTimeoutSeconds > 0) {
               ps.setQueryTimeout(queryTimeoutSeconds);
            }
            ps.setString(1, imei);

            try (ResultSet rs = ps.executeQuery()) {
               if (!rs.next()) {
                   return null;
               }
               return readEquipment(rs);
            }
        } catch (SQLException e) {
            throw new EquipmentRepositoryException("EIR database lookup failed", e);
        }
    }

    private Equipment readEquipment(ResultSet rs) throws SQLException {
        Timestamp created = rs.getTimestamp("created_at");
        Timestamp updated = rs.getTimestamp("updated_at");

        Map<String, String> audit = new HashMap<>();
        putIfNotNull(audit, "description", rs.getString("description"));
        putIfNotNull(audit, "reason", rs.getString("reason"));
        putIfNotNull(audit, "source", rs.getString("source"));

        Instant now = Instant.now();
        return new Equipment(
               rs.getString("imei"),
               parseStatus(rs.getString("status")),
               created == null ? now : created.toInstant(),
               updated == null ? now : updated.toInstant(),
               audit
        );
    }

    private static EirEquipmentStatus parseStatus(String value) {
        if (value == null) {
            return EirEquipmentStatus.UNKNOWN;
        }

        return switch (value.trim().toUpperCase()) {
            case "WHITELIST", "WHITELISTED" -> EirEquipmentStatus.WHITELISTED;
            case "BLACKLIST", "BLACKLISTED" -> EirEquipmentStatus.BLACKLISTED;
            case "GREYLIST", "GREYLISTED" -> EirEquipmentStatus.GREYLISTED;
            default -> EirEquipmentStatus.UNKNOWN;
        };
    }

    private static void putIfNotNull(Map<String, String> map, String key, String value) {
        if (value != null && !value.isBlank()) {
            map.put(key, value);
        }
    }
}
