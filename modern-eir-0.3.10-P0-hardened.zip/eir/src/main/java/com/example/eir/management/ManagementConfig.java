package com.example.eir.management;

/**
 * Configuration for EIR management API server.
 * Can be initialized from application.properties or environment variables.
 */
public final class ManagementConfig {
    private final boolean enabled;
    private final String host;
    private final int port;
    private final String jwtSecret;
    private final int jwtExpiryMinutes;
    private final String imeiMaskMode;
    private final boolean auditEnabled;
    
    public ManagementConfig(
            boolean enabled, String host, int port,
            String jwtSecret, int jwtExpiryMinutes,
            String imeiMaskMode, boolean auditEnabled) {
        this.enabled = enabled;
        this.host = host;
        this.port = port;
        this.jwtSecret = jwtSecret;
        this.jwtExpiryMinutes = jwtExpiryMinutes;
        this.imeiMaskMode = imeiMaskMode;
        this.auditEnabled = auditEnabled;
    }
    
    public static ManagementConfig fromEnvironment() {
        String enabled = System.getenv("EIR_MANAGEMENT_ENABLED");
        String host = System.getenv("EIR_MANAGEMENT_HOST");
        String port = System.getenv("EIR_MANAGEMENT_PORT");
        String jwtSecret = System.getenv("EIR_JWT_SECRET");
        String jwtExpiry = System.getenv("EIR_JWT_EXPIRY_MINUTES");
        String maskMode = System.getenv("EIR_IMEI_MASK_MODE");
        String auditEnabled = System.getenv("EIR_AUDIT_ENABLED");
        
        boolean managementEnabled = parseBoolean(enabled, true);
        String resolvedSecret = jwtSecret;
        if (managementEnabled && (resolvedSecret == null || resolvedSecret.isBlank())) {
            throw new IllegalStateException(
                    "EIR_JWT_SECRET must be set when management API is enabled");
        }
        if (managementEnabled && resolvedSecret.getBytes(java.nio.charset.StandardCharsets.UTF_8).length < 32) {
            throw new IllegalStateException(
                    "EIR_JWT_SECRET must be at least 32 UTF-8 bytes");
        }

        return new ManagementConfig(
                managementEnabled,
                host != null ? host : "127.0.0.1",
                port != null ? Integer.parseInt(port) : 8080,
                resolvedSecret,
                jwtExpiry != null ? Integer.parseInt(jwtExpiry) : 60,
                maskMode != null ? maskMode : "partial",
                parseBoolean(auditEnabled, true)
        );
    }
    
    private static boolean parseBoolean(String value, boolean defaultValue) {
        if (value == null) return defaultValue;
        return value.equalsIgnoreCase("true") || value.equalsIgnoreCase("1");
    }
    
    public boolean isEnabled() { return enabled; }
    public String getHost() { return host; }
    public int getPort() { return port; }
    public String getJwtSecret() { return jwtSecret; }
    public int getJwtExpiryMinutes() { return jwtExpiryMinutes; }
    public String getImeiMaskMode() { return imeiMaskMode; }
    public boolean isAuditEnabled() { return auditEnabled; }
}
