package com.example.eir.exception;

/** Repository failure. */
public class EquipmentRepositoryException extends RuntimeException {
    public EquipmentRepositoryException(String message, Throwable cause) {
        super(message, cause);
    }
}
