package com.example.eir.domain;

import java.util.Objects;

/**
 * Result of an EIR equipment check before the MAP adapter applies its
 * protocol-specific response mapping.
 */
public record EquipmentDecision(
        String imei,
        EirEquipmentStatus status,
        String source,
        String reason,
        Equipment equipment
) {
    public EquipmentDecision {
        Objects.requireNonNull(status, "status");
        Objects.requireNonNull(source, "source");
        Objects.requireNonNull(reason, "reason");
    }

    public boolean approved() {
        return status == EirEquipmentStatus.WHITELISTED;
    }

    public static EquipmentDecision forEquipment(Equipment equipment, String source) {
        return new EquipmentDecision(
                equipment.imei(),
                equipment.status(),
                source,
                "EQUIPMENT_STATUS",
                equipment
        );
    }

    public static EquipmentDecision invalidImei(String imei) {
        return new EquipmentDecision(
                imei,
                EirEquipmentStatus.UNKNOWN,
                "validation",
                "INVALID_IMEI",
                null
        );
    }

    public static EquipmentDecision databaseUnavailable(String imei, String source) {
        return new EquipmentDecision(
                imei,
                EirEquipmentStatus.UNKNOWN,
                source,
                "DATABASE_UNAVAILABLE",
                null
        );
    }
}
