package org.restcomm.protocols.ss7.transport;

import io.netty.buffer.ByteBufAllocator;
import io.netty.buffer.Unpooled;
import org.apache.log4j.Logger;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * TCP implementation of the RestComm transport Association contract.
 *
 * <p>The wire format is deliberately internal to the EIR/MSC simulator:
 * a fixed header carries payload length, virtual stream number, PPID and
 * unordered flag, followed by the M3UA payload. This preserves the transport
 * information M3UA needs while allowing testing on Windows without SCTP.</p>
 */
final class RestCommTcpAssociation implements Association {
    private static final Logger log = Logger.getLogger(RestCommTcpAssociation.class);
    private static final int MAGIC = 0x52535443; // RSTC
    private static final short VERSION = 1;
    private static final int MAX_FRAME_SIZE = 16 * 1024 * 1024;
    private static final int VIRTUAL_STREAMS = 32;

    private final RestCommTcpManagement management;
    private final String name;
    private final String hostAddress;
    private final int hostPort;
    private final String peerAddress;
    private final int peerPort;
    private final String backupPeerAddress;
    private final int backupPeerPort;
    private volatile int activePeerIndex;
    private final boolean serverSide;

    private volatile boolean started;
    private volatile boolean connected;
    private volatile Socket socket;
    private volatile DataInputStream input;
    private volatile DataOutputStream output;
    private volatile AssociationListener listener;
    private Thread readerThread;
    private final AtomicBoolean closing = new AtomicBoolean(false);
    private final AtomicBoolean upNotified = new AtomicBoolean(false);

    RestCommTcpAssociation(RestCommTcpManagement management, String name,
                           String hostAddress, int hostPort,
                           String peerAddress, int peerPort,
                           String backupPeerAddress, int backupPeerPort,
                           boolean serverSide) {
        this.management = management;
        this.name = name;
        this.hostAddress = hostAddress;
        this.hostPort = hostPort;
        this.peerAddress = peerAddress;
        this.peerPort = peerPort;
        this.backupPeerAddress = backupPeerAddress;
        this.backupPeerPort = backupPeerPort;
        this.serverSide = serverSide;
    }

    @Override public String getName() { return name; }
    @Override public boolean isStarted() { return started; }
    @Override public boolean isConnected() { return connected; }
    @Override public AssociationListener getAssociationListener() { return listener; }
    @Override public void setAssociationListener(AssociationListener listener) { this.listener = listener; }
    @Override public String getHostAddress() { return hostAddress; }
    @Override public int getHostPort() { return hostPort; }
    @Override public String getPeerAddress() { return peerAddress; }
    @Override public int getPeerPort() { return peerPort; }
    String getBackupPeerAddress() { return backupPeerAddress; }
    int getBackupPeerPort() { return backupPeerPort; }
    boolean hasBackupPeer() { return backupPeerAddress != null && !backupPeerAddress.isBlank() && backupPeerPort > 0; }
    @Override public ByteBufAllocator getByteBufAllocator() { return ByteBufAllocator.DEFAULT; }
    @Override public int getCongestionLevel() { return 0; }

    void start() {
        if (started) return;
        if (listener == null) throw new IllegalStateException("No AssociationListener registered for " + name);
        started = true;
        closing.set(false);
        upNotified.set(false);
        if (!serverSide) {
            Thread connector = new Thread(this::clientConnectLoop, "jss7-tcp-connect-" + name);
            connector.setDaemon(true);
            connector.start();
        }
    }

    void attachAcceptedSocket(Socket accepted) throws Exception {
        if (!started) {
            accepted.close();
            return;
        }
        closeCurrentSocket();
        accepted.setTcpNoDelay(true);
        accepted.setKeepAlive(true);
        this.socket = accepted;
        this.input = new DataInputStream(accepted.getInputStream());
        this.output = new DataOutputStream(accepted.getOutputStream());
        this.connected = true;
        upNotified.set(false);
        notifyUp();
        startReader();
    }

    private void clientConnectLoop() {
        while (started && !closing.get() && !connected) {
            boolean attempted = false;
            for (int offset = 0; offset < endpointCount() && started && !closing.get() && !connected; offset++) {
                int index = (activePeerIndex + offset) % endpointCount();
                attempted = true;
                try {
                    connectClient(index);
                    activePeerIndex = index;
                    return;
                } catch (Exception e) {
                    if (started && !closing.get()) {
                        log.warn("Unable to connect TCP association " + name + " to "
                                + endpointAddress(index) + "; "
                                + (index == 0 && hasBackupPeer() ? "trying backup endpoint" : "endpoint failed"), e);
                    }
                }
            }
            if (attempted && started && !closing.get()) {
                log.warn("All TCP endpoints unavailable for association " + name
                        + "; retrying primary endpoint after " + management.getConnectDelay() + " ms");
                try { Thread.sleep(management.getConnectDelay()); }
                catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); return; }
                activePeerIndex = 0;
            }
        }
    }

    private int endpointCount() { return hasBackupPeer() ? 2 : 1; }

    private String endpointAddress(int index) {
        return (index == 0 ? peerAddress : backupPeerAddress) + ":"
                + (index == 0 ? peerPort : backupPeerPort);
    }

    private void connectClient(int endpointIndex) throws Exception {
        Socket newSocket = new Socket();
        try {
            newSocket.setTcpNoDelay(true);
            newSocket.setKeepAlive(true);
            newSocket.setReuseAddress(true);
            if (hostPort > 0) newSocket.bind(new InetSocketAddress(hostAddress, hostPort));
            String address = endpointIndex == 0 ? peerAddress : backupPeerAddress;
            int port = endpointIndex == 0 ? peerPort : backupPeerPort;
            newSocket.connect(new InetSocketAddress(address, port), Math.max(1000, management.getConnectDelay()));
        } catch (Exception e) {
            try { newSocket.close(); } catch (Exception ignored) {}
            throw e;
        }
        this.socket = newSocket;
        this.input = new DataInputStream(newSocket.getInputStream());
        this.output = new DataOutputStream(newSocket.getOutputStream());
        this.connected = true;
        notifyUp();
        startReader();
        log.info("TCP association " + name + " connected to " + endpointAddress(endpointIndex));
    }

    private void startReader() {
        readerThread = new Thread(this::readLoop, "jss7-tcp-" + name);
        readerThread.setDaemon(true);
        readerThread.start();
    }

    private void readLoop() {
        try {
            while (started && !closing.get() && connected) {
                int magic = input.readInt();
                short version = input.readShort();
                int flags = input.readUnsignedByte();
                int ppid = input.readInt();
                int stream = input.readInt();
                int length = input.readInt();

                if (magic != MAGIC || version != VERSION) {
                    throw new IOException("Invalid TCP transport frame header for " + name);
                }
                if (length < 0 || length > MAX_FRAME_SIZE) {
                    throw new IOException("Invalid TCP transport frame length=" + length + " for " + name);
                }

                byte[] bytes = new byte[length];
                input.readFully(bytes);
                AssociationListener current = listener;
                if (current != null) {
                    PayloadData payload = new PayloadData(
                            length,
                            Unpooled.wrappedBuffer(bytes),
                            true,
                            (flags & 1) != 0,
                            ppid,
                            stream);
                    current.onPayload(this, payload);
                }
            }
        } catch (EOFException eof) {
            handleConnectionLost("peer closed TCP connection", eof);
        } catch (Exception e) {
            handleConnectionLost("TCP association " + name + " lost", e);
        }
    }

    private void handleConnectionLost(String message, Exception cause) {
        boolean wasConnected = connected;
        connected = false;
        closeCurrentSocket();
        if (!started || closing.get()) return;
        upNotified.set(false);
        if (wasConnected) {
            log.warn(message, cause);
            AssociationListener current = listener;
            if (current != null) current.onCommunicationLost(this);
        }
        if (!serverSide) {
            Thread connector = new Thread(this::clientConnectLoop, "jss7-tcp-reconnect-" + name);
            connector.setDaemon(true);
            connector.start();
        }
    }

    private void notifyUp() {
        AssociationListener current = listener;
        if (current != null && upNotified.compareAndSet(false, true)) {
            // TCP has no SCTP stream negotiation. The transport exposes a
            // stable set of virtual streams for M3UA's SLS-to-stream table.
            current.onCommunicationUp(this, VIRTUAL_STREAMS, VIRTUAL_STREAMS);
        }
    }

    @Override
    public void send(PayloadData payloadData) throws Exception {
        DataOutputStream out = output;
        if (!started || !connected || out == null || socket == null || socket.isClosed()) {
            throw new IllegalStateException("TCP association is not connected: " + name);
        }
        byte[] data = payloadData.getData();
        if (data.length > MAX_FRAME_SIZE) throw new IOException("Payload too large: " + data.length);

        synchronized (out) {
            out.writeInt(MAGIC);
            out.writeShort(VERSION);
            out.writeByte(payloadData.isUnordered() ? 1 : 0);
            out.writeInt(payloadData.getPayloadProtocolId());
            out.writeInt(payloadData.getStreamNumber());
            out.writeInt(data.length);
            out.write(data);
            out.flush();
        }
    }

    void stop() {
        boolean wasStarted = started;
        started = false;
        closing.set(true);
        connected = false;
        upNotified.set(false);
        closeCurrentSocket();
        AssociationListener current = listener;
        if (wasStarted && current != null) current.onCommunicationShutdown(this);
    }

    private void closeCurrentSocket() {
        Socket current = socket;
        socket = null;
        input = null;
        output = null;
        if (current != null) {
            try { current.close(); } catch (Exception e) { log.debug("TCP socket close failed for " + name, e); }
        }
    }
}
