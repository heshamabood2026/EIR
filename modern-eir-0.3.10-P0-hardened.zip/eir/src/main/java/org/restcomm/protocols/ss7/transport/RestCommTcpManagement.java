package org.restcomm.protocols.ss7.transport;

import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Lightweight TCP transport for Windows/local integration testing.
 *
 * <p>This class implements the same RestComm transport contract as the JDK
 * SCTP implementation, but uses ordinary TCP sockets. It is intended for
 * EIR/MSC simulator testing when the host operating system does not expose
 * SCTP. It is not a standards-compliant replacement for SIGTRAN SCTP.</p>
 */
public final class RestCommTcpManagement implements Management {
    private static final Logger log = Logger.getLogger(RestCommTcpManagement.class);

    private final String name;
    private final Map<String, RestCommTcpAssociation> associations = new ConcurrentHashMap<>();
    private final Map<String, RestCommTcpServer> servers = new ConcurrentHashMap<>();
    private volatile boolean started;
    private volatile int connectDelay = 10000;
    private volatile boolean singleThread;

    public RestCommTcpManagement(String name) {
        this.name = name;
    }

    @Override public String getName() { return name; }

    @Override
    public void start() {
        started = true;
    }

    @Override
    public void stop() {
        for (String server : new ArrayList<>(servers.keySet())) {
            try { stopServer(server); } catch (Exception e) { log.warn("Unable to stop TCP server " + server, e); }
        }
        for (RestCommTcpAssociation association : associations.values()) {
            association.stop();
        }
        associations.clear();
        started = false;
    }

    @Override
    public void addServer(String serverName, String hostAddress, int port) throws Exception {
        requireStarted();
        if (servers.containsKey(serverName)) {
            throw new IllegalArgumentException("TCP server already exists: " + serverName);
        }
        String endpoint = endpoint(hostAddress, port);
        for (Map.Entry<String, RestCommTcpServer> entry : servers.entrySet()) {
            RestCommTcpServer existing = entry.getValue();
            if (endpoint.equals(endpoint(existing.hostAddress(), existing.port()))) {
                throw new IllegalArgumentException("TCP listener endpoint already assigned to server "
                        + entry.getKey() + ": " + endpoint);
            }
        }
        servers.put(serverName, new RestCommTcpServer(this, serverName, hostAddress, port));
    }

    @Override
    public void startServer(String serverName) throws Exception {
        requireStarted();
        RestCommTcpServer server = servers.get(serverName);
        if (server == null) throw new IllegalArgumentException("Unknown TCP server: " + serverName);
        server.start();
    }

    @Override
    public void stopServer(String serverName) throws Exception {
        RestCommTcpServer server = servers.get(serverName);
        if (server != null) server.stop();
    }

    @Override
    public Association addServerAssociation(String peerAddress, int peerPort,
                                             String serverName, String associationName) throws Exception {
        return addServerAssociation(peerAddress, peerPort, null, 0, serverName, associationName);
    }

    /** Adds a server-side logical association with an optional backup peer address.
     * For inbound TCP, the peer source port is ephemeral and therefore is not used
     * to select the association; the primary/backup addresses are used as allow-list
     * identities. */
    public Association addServerAssociation(String peerAddress, int peerPort,
                                             String backupPeerAddress, int backupPeerPort,
                                             String serverName, String associationName) throws Exception {
        requireStarted();
        RestCommTcpServer server = servers.get(serverName);
        if (server == null) throw new IllegalArgumentException("Unknown TCP server: " + serverName);
        if (associations.containsKey(associationName)) {
            throw new IllegalArgumentException("TCP association already exists: " + associationName);
        }
        RestCommTcpAssociation association = new RestCommTcpAssociation(
                this, associationName, server.hostAddress(), server.port(),
                peerAddress, peerPort, backupPeerAddress, backupPeerPort, true);
        associations.put(associationName, association);
        server.registerAssociation(association);
        return association;
    }


    /** Binds an already-created logical association to an additional TCP server listener.
     * This is used for server-side primary/backup local endpoints. */
    public void bindAssociationToServer(String associationName, String serverName) throws Exception {
        requireStarted();
        RestCommTcpAssociation association = associations.get(associationName);
        if (association == null) throw new IllegalArgumentException("Unknown TCP association: " + associationName);
        RestCommTcpServer server = servers.get(serverName);
        if (server == null) throw new IllegalArgumentException("Unknown TCP server: " + serverName);
        server.registerAssociation(association);
    }
    @Override
    public Association addAssociation(String hostAddress, int hostPort,
                                       String peerAddress, int peerPort,
                                       String associationName) throws Exception {
        return addAssociation(hostAddress, hostPort, peerAddress, peerPort, null, 0, associationName);
    }

    /** Adds a TCP client association with primary and optional backup endpoints. */
    public Association addAssociation(String hostAddress, int hostPort,
                                       String peerAddress, int peerPort,
                                       String backupPeerAddress, int backupPeerPort,
                                       String associationName) throws Exception {
        requireStarted();
        if (associations.containsKey(associationName)) {
            throw new IllegalArgumentException("TCP association already exists: " + associationName);
        }
        RestCommTcpAssociation association = new RestCommTcpAssociation(
                this, associationName, hostAddress, hostPort,
                peerAddress, peerPort, backupPeerAddress, backupPeerPort, false);
        associations.put(associationName, association);
        return association;
    }

    @Override public Association getAssociation(String associationName) { return associations.get(associationName); }

    @Override
    public Map<String, Association> getAssociations() {
        Map<String, Association> result = new LinkedHashMap<>();
        result.putAll(associations);
        return Collections.unmodifiableMap(result);
    }

    @Override
    public void startAssociation(String associationName) throws Exception {
        requireStarted();
        RestCommTcpAssociation association = associations.get(associationName);
        if (association == null) throw new IllegalArgumentException("Unknown TCP association: " + associationName);
        association.start();
    }

    @Override
    public void stopAssociation(String associationName) {
        RestCommTcpAssociation association = associations.get(associationName);
        if (association != null) association.stop();
    }

    @Override public int getConnectDelay() { return connectDelay; }
    @Override public void setConnectDelay(int connectDelay) { this.connectDelay = Math.max(0, connectDelay); }
    @Override public boolean isSingleThread() { return singleThread; }
    @Override public void setSingleThread(boolean singleThread) { this.singleThread = singleThread; }

    void accepted(RestCommTcpAssociation association, java.net.Socket socket) throws Exception {
        association.attachAcceptedSocket(socket);
    }

    private static String endpoint(String hostAddress, int port) {
        return hostAddress + ":" + port;
    }

    private void requireStarted() {
        if (!started) throw new IllegalStateException("TCP management is not started: " + name);
    }
}

final class RestCommTcpServer {
    private static final Logger log = Logger.getLogger(RestCommTcpServer.class);

    private final RestCommTcpManagement management;
    private final String name;
    private final String hostAddress;
    private final int port;
    private final Map<String, RestCommTcpAssociation> associations = new ConcurrentHashMap<>();
    private volatile boolean started;
    private volatile java.net.ServerSocket serverSocket;
    private Thread acceptThread;

    RestCommTcpServer(RestCommTcpManagement management, String name, String hostAddress, int port) {
        this.management = management;
        this.name = name;
        this.hostAddress = hostAddress;
        this.port = port;
    }

    String hostAddress() { return hostAddress; }
    int port() { return port; }

    void registerAssociation(RestCommTcpAssociation association) {
        associations.put(association.getName(), association);
    }

    void start() throws Exception {
        if (started) return;
        java.net.ServerSocket socket = new java.net.ServerSocket();
        socket.setReuseAddress(true);
        socket.bind(new java.net.InetSocketAddress(hostAddress, port));
        serverSocket = socket;
        started = true;
        acceptThread = new Thread(this::acceptLoop, "jss7-tcp-server-" + name);
        acceptThread.setDaemon(true);
        acceptThread.start();
        log.info("Started TCP test server " + name + " on " + hostAddress + ":" + port);
    }

    void stop() {
        started = false;
        java.net.ServerSocket current = serverSocket;
        serverSocket = null;
        if (current != null) {
            try { current.close(); } catch (Exception e) { log.debug("TCP server close failed", e); }
        }
    }

    private void acceptLoop() {
        while (started) {
            try {
                java.net.Socket socket = serverSocket.accept();
                socket.setTcpNoDelay(true);
                socket.setKeepAlive(true);

                String peer = socket.getInetAddress() == null ? null : socket.getInetAddress().getHostAddress();
                int peerPort = socket.getPort();
                RestCommTcpAssociation selected = selectAssociation(peer);
                if (selected == null) {
                    log.warn("Rejecting unconfigured TCP peer " + peer + ":" + peerPort + " on server " + name);
                    socket.close();
                    continue;
                }
                management.accepted(selected, socket);
            } catch (Exception e) {
                if (started) log.warn("TCP accept loop failed for " + name, e);
            }
        }
    }

    private RestCommTcpAssociation selectAssociation(String peer) {
        for (RestCommTcpAssociation association : associations.values()) {
            // TCP source ports are not an identity guarantee. For this local
            // test transport the configured peer address is the stable match;
            // the peerPort is used by the client when it connects.
            boolean primaryMatches = association.getPeerAddress() == null
                    || association.getPeerAddress().isBlank()
                    || association.getPeerAddress().equals(peer);
            // A blank backup means "not configured" rather than a wildcard.
            boolean matches = primaryMatches;
            if (association.hasBackupPeer()) {
                matches = association.getPeerAddress().equals(peer)
                        || association.getBackupPeerAddress().equals(peer);
            }
            if (matches && association.isStarted()) return association;
        }
        return null;
    }
}
