package com.example.eir;

import org.junit.jupiter.api.Test;
import org.restcomm.protocols.ss7.transport.Association;
import org.restcomm.protocols.ss7.transport.AssociationListener;
import org.restcomm.protocols.ss7.transport.PayloadData;
import org.restcomm.protocols.ss7.transport.RestCommTcpManagement;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;

class TcpTransportFailoverTest {

    @Test
    void clientFallsBackToBackupWhenPrimaryIsUnavailable() throws Exception {
        try (ServerSocket backup = new ServerSocket(0)) {
            backup.setReuseAddress(true);
            CountDownLatch accepted = new CountDownLatch(1);
            Thread acceptor = new Thread(() -> {
                try (Socket socket = backup.accept()) {
                    accepted.countDown();
                } catch (Exception ignored) {
                }
            }, "tcp-failover-test-acceptor");
            acceptor.setDaemon(true);
            acceptor.start();

            // Bind and close the primary endpoint so it is guaranteed unavailable.
            int primaryPort;
            try (ServerSocket primary = new ServerSocket(0)) {
                primaryPort = primary.getLocalPort();
            }

            RestCommTcpManagement management = new RestCommTcpManagement("FAILOVER-TEST");
            management.setConnectDelay(100);
            management.start();
            CountDownLatch up = new CountDownLatch(1);
            try {
                Association association = management.addAssociation(
                        "127.0.0.1", 0,
                        "127.0.0.1", primaryPort,
                        "127.0.0.1", backup.getLocalPort(),
                        "FAILOVER_ASSOC");
                association.setAssociationListener(listener(up));
                management.startAssociation("FAILOVER_ASSOC");

                assertTrue(up.await(3, TimeUnit.SECONDS), "association did not reach communication-up");
                assertTrue(accepted.await(1, TimeUnit.SECONDS), "backup endpoint did not accept the connection");
            } finally {
                management.stop();
            }
        }
    }

    @Test
    void clientUsesPrimaryBeforeBackup() throws Exception {
        try (ServerSocket primary = new ServerSocket(0); ServerSocket backup = new ServerSocket(0)) {
            CountDownLatch primaryAccepted = new CountDownLatch(1);
            CountDownLatch backupAccepted = new CountDownLatch(1);
            Thread primaryAcceptor = acceptOnce(primary, primaryAccepted);
            Thread backupAcceptor = acceptOnce(backup, backupAccepted);

            RestCommTcpManagement management = new RestCommTcpManagement("PRIMARY-TEST");
            management.setConnectDelay(100);
            management.start();
            CountDownLatch up = new CountDownLatch(1);
            try {
                management.addAssociation("127.0.0.1", 0,
                        "127.0.0.1", primary.getLocalPort(),
                        "127.0.0.1", backup.getLocalPort(),
                        "PRIMARY_ASSOC").setAssociationListener(listener(up));
                management.startAssociation("PRIMARY_ASSOC");

                assertTrue(up.await(3, TimeUnit.SECONDS), "association did not reach communication-up");
                assertTrue(primaryAccepted.await(1, TimeUnit.SECONDS), "primary endpoint was not selected first");
                assertEquals(1L, backupAccepted.getCount(), "backup endpoint was used while primary was available");
            } finally {
                management.stop();
            }
            primaryAcceptor.join(500);
            backupAcceptor.join(500);
        }
    }

    @Test
    void rejectsTwoNamedServersOnTheSameLocalEndpoint() throws Exception {
        try (ServerSocket occupied = new ServerSocket(0)) {
            RestCommTcpManagement management = new RestCommTcpManagement("SERVER-ENDPOINT-TEST");
            management.start();
            try {
                int port = occupied.getLocalPort();
                // The endpoint is occupied by the test socket, so addServer itself should
                // still be able to register it; the management layer rejects duplicate
                // endpoints before a second ServerSocket can be created.
                occupied.close();
                management.addServer("SERVER_A", "127.0.0.1", port);
                IllegalArgumentException error = assertThrows(IllegalArgumentException.class,
                        () -> management.addServer("SERVER_B", "127.0.0.1", port));
                assertTrue(error.getMessage().contains("already assigned"));
            } finally {
                management.stop();
            }
        }
    }

    private static Thread acceptOnce(ServerSocket server, CountDownLatch accepted) {
        Thread thread = new Thread(() -> {
            try (Socket socket = server.accept()) {
                accepted.countDown();
            } catch (Exception ignored) {
            }
        }, "tcp-failover-test-acceptor");
        thread.setDaemon(true);
        thread.start();
        return thread;
    }

    private static AssociationListener listener(CountDownLatch up) {
        return new AssociationListener() {
            @Override public void onCommunicationUp(Association association, int maxInboundStreams, int maxOutboundStreams) { up.countDown(); }
            @Override public void onCommunicationShutdown(Association association) {}
            @Override public void onCommunicationLost(Association association) {}
            @Override public void onCommunicationRestart(Association association) {}
            @Override public void onPayload(Association association, PayloadData payloadData) {}
            @Override public void inValidStreamId(PayloadData payloadData) {}
        };
    }
}
