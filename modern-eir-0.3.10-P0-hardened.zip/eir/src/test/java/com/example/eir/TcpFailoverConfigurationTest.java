package com.example.eir;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

class TcpFailoverConfigurationTest {
    @TempDir Path tempDir;

    @Test
    void loadsPrimaryAndBackupEndpoints() throws Exception {
        Path project = prepareProject();
        writeAssociations(project, """
            <?xml version="1.0" encoding="UTF-8"?>
            <associations>
              <association name="MSC01_ASSOC" mode="client"
                localAddress="127.0.0.1" localPort="2905"
                peerAddress="10.20.0.10" peerPort="2905"
                backupPeerAddress="10.20.0.11" backupPeerPort="2905"
                serverName="MSC01_SERVER" aspName="MSC01_ASP" asName="MSC01_AS"
                routingContext="100" aspid="2" remoteSpc="2" remoteSsn="146"
                routeDpc="2" started="true"/>
            </associations>
            """);

        EirConfig cfg = EirConfig.load("EIR", project.toFile(), "tcp");
        AssociationConfig a = cfg.associations.get(0);
        assertEquals("10.20.0.10", a.peerAddress());
        assertEquals(2905, a.peerPort());
        assertEquals("10.20.0.11", a.backupPeerAddress());
        assertEquals(2905, a.backupPeerPort());
        assertTrue(a.hasBackupPeer());
    }

    @Test
    void loadsServerPrimaryAndBackupLocalEndpoints() throws Exception {
        Path project = prepareProject();
        writeAssociations(project, """
            <?xml version="1.0" encoding="UTF-8"?>
            <associations>
              <association name="MSC01_ASSOC" mode="server"
                localAddress="127.0.0.1" localPort="2906"
                backupLocalAddress="127.0.0.1" backupLocalPort="2907"
                peerAddress="10.20.0.10" peerPort="2905"
                serverName="MSC01_SERVER" aspName="MSC01_ASP" asName="MSC01_AS"
                routingContext="100" aspid="3" remoteSpc="1" remoteSsn="8" routeDpc="1" started="true"/>
            </associations>
            """);
        AssociationConfig a = EirConfig.load("EIR", project.toFile(), "tcp").associations.get(0);
        assertEquals("127.0.0.1", a.backupLocalAddress());
        assertEquals(2907, a.backupLocalPort());
        assertTrue(a.hasBackupLocal());
    }

    @Test
    void preservesSingleEndpointBackwardCompatibility() throws Exception {
        Path project = prepareProject();
        writeAssociations(project, """
            <?xml version="1.0" encoding="UTF-8"?>
            <associations>
              <association name="MSC01_ASSOC" mode="client"
                localAddress="127.0.0.1" localPort="2905"
                peerAddress="10.20.0.10" peerPort="2905"
                serverName="MSC01_SERVER" aspName="MSC01_ASP" asName="MSC01_AS"
                routingContext="100" aspid="2" remoteSpc="2" remoteSsn="146"
                routeDpc="2" started="true"/>
            </associations>
            """);

        EirConfig cfg = EirConfig.load("EIR", project.toFile(), "tcp");
        assertFalse(cfg.associations.get(0).hasBackupPeer());
        assertNull(cfg.associations.get(0).backupPeerAddress());
        assertEquals(0, cfg.associations.get(0).backupPeerPort());
    }

    private Path prepareProject() throws IOException {
        Path project = tempDir.resolve("project");
        Path source = Path.of("config", "initial", "EIR");
        Path target = project.resolve("config").resolve("initial").resolve("EIR");
        Files.createDirectories(target);
        try (Stream<Path> files = Files.list(source)) {
            files.filter(Files::isRegularFile).forEach(path -> {
                try { Files.copy(path, target.resolve(path.getFileName()), StandardCopyOption.REPLACE_EXISTING); }
                catch (IOException e) { throw new RuntimeException(e); }
            });
        }
        return project;
    }

    private void writeAssociations(Path project, String xml) throws IOException {
        Files.writeString(project.resolve("config/initial/EIR/EIR-associations.xml"), xml);
    }
}
