package com.example.eir;

import com.example.eir.domain.EquipmentDecision;
import com.example.eir.domain.EirEquipmentStatus;
import com.example.eir.repository.InMemoryEquipmentRepository;
import com.example.eir.service.EquipmentService;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EquipmentServiceTest {

    @Test
    void returnsWhitelistedForKnownWhitelistedImei() {
        EquipmentService service =
                new EquipmentService(InMemoryEquipmentRepository.demo());

        EquipmentDecision result = service.checkImei("490154203237518");

        assertEquals(EirEquipmentStatus.WHITELISTED, result.status());
        assertTrue(result.approved());
        assertNotNull(result.equipment());
        assertTrue(result.equipment().createdAt() != null);
        assertTrue(result.equipment().updatedAt() != null);
    }

    @Test
    void returnsBlacklistedForKnownBlacklistedImei() {
        EquipmentService service =
                new EquipmentService(InMemoryEquipmentRepository.demo());

        EquipmentDecision result = service.checkImei("333333334444442");

        assertEquals(EirEquipmentStatus.BLACKLISTED, result.status());
        assertFalse(result.approved());
    }

    @Test
    void returnsUnknownForUnregisteredImei() {
        EquipmentService service =
                new EquipmentService(InMemoryEquipmentRepository.demo());

        EquipmentDecision result = service.checkImei("111111111111111");

        assertEquals(EirEquipmentStatus.UNKNOWN, result.status());
        assertEquals("EQUIPMENT_NOT_FOUND", result.reason());
        assertFalse(result.approved());
    }

    @Test
    void rejectsMalformedImeiBeforeRepositoryLookup() {
        EquipmentService service =
                new EquipmentService(InMemoryEquipmentRepository.demo());

        EquipmentDecision result = service.checkImei("not-an-imei");

        assertEquals(EirEquipmentStatus.UNKNOWN, result.status());
        assertEquals("INVALID_IMEI", result.reason());
        assertEquals("validation", result.source());
        assertFalse(result.approved());
    }
}
