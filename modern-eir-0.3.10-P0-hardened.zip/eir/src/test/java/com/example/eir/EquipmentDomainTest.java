package com.example.eir;

import com.example.eir.domain.Equipment;
import com.example.eir.domain.EirEquipmentStatus;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class EquipmentDomainTest {

    @Test
    void equipmentCarriesIdentityStatusTimestampsAndAuditMetadata() {
        Instant created = Instant.parse("2026-01-01T00:00:00Z");
        Instant updated = Instant.parse("2026-01-02T00:00:00Z");

        Equipment equipment = new Equipment(
                "490154203237518",
                EirEquipmentStatus.WHITELISTED,
                created,
                updated,
                Map.of("source", "test", "reason", "approved")
        );

        assertEquals("490154203237518", equipment.imei());
        assertEquals(EirEquipmentStatus.WHITELISTED, equipment.status());
        assertEquals(created, equipment.createdAt());
        assertEquals(updated, equipment.updatedAt());
        assertEquals("test", equipment.auditMetadata().get("source"));
        assertEquals("approved", equipment.auditMetadata().get("reason"));
    }

    @Test
    void auditMetadataIsOptional() {
        Equipment equipment = new Equipment(
                "490154203237518",
                EirEquipmentStatus.UNKNOWN,
                Instant.now(),
                Instant.now()
        );

        assertTrue(equipment.auditMetadata().isEmpty());
    }

    @Test
    void updatedTimestampCannotPrecedeCreatedTimestamp() {
        Instant created = Instant.parse("2026-01-02T00:00:00Z");
        Instant updated = Instant.parse("2026-01-01T00:00:00Z");

        assertThrows(IllegalArgumentException.class, () ->
                new Equipment(
                        "490154203237518",
                        EirEquipmentStatus.WHITELISTED,
                        created,
                        updated
                )
        );
    }
}
