package com.example.eir.auth;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PasswordHasherTest {
    @Test
    void hashesWithUniqueSaltAndVerifies() {
        String a = PasswordHasher.hash("correct horse battery staple");
        String b = PasswordHasher.hash("correct horse battery staple");

        assertNotEquals(a, b);
        assertTrue(PasswordHasher.verify("correct horse battery staple", a));
        assertTrue(PasswordHasher.verify("correct horse battery staple", b));
        assertFalse(PasswordHasher.verify("wrong password", a));
    }

    @Test
    void malformedHashIsRejected() {
        assertFalse(PasswordHasher.verify("password", "not-a-password-hash"));
    }
}
