package com.example.eir;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

class SctpMultihomingConfigurationTest {
    @TempDir Path tempDir;

    @Test
    void acceptsTwoLocalAddressesOnOneSctpAssociation() throws Exception {
        Path project = prepareProject();
        writeAssociations(project, """
            <?xml version="1.0" encoding="UTF-8"?>
            <associations>
              <association name="MSC01_ASSOC" mode="client"
                localAddress="10.10.10.20" localPort="2905"
                backupLocalAddress="10.10.10.21" backupLocalPort="2905"
                peerAddress="10.20.20.20" peerPort="2905"
                backupPeerAddress="10.20.20.21" backupPeerPort="2905"
                serverName="MSC01_SERVER" aspName="MSC01_ASP" asName="MSC01_AS"
                routingContext="100" aspid="2" remoteSpc="2" remoteSsn="146"
                routeDpc="2" started="true"/>
            </associations>
            """);

        AssociationConfig a = EirConfig.load("EIR", project.toFile(), "sctp").associations.get(0);
        assertTrue(a.hasBackupLocal());
        assertEquals(a.localPort(), a.backupLocalPort());
        assertTrue(a.hasBackupPeer());
        assertEquals(a.peerPort(), a.backupPeerPort());
    }

    @Test
    void rejectsDifferentPortsForSctpMultihoming() throws Exception {
        Path project = prepareProject();
        writeAssociations(project, """
            <?xml version="1.0" encoding="UTF-8"?>
            <associations>
              <association name="MSC01_ASSOC" mode="client"
                localAddress="10.10.10.20" localPort="2905"
                backupLocalAddress="10.10.10.21" backupLocalPort="2906"
                peerAddress="10.20.20.20" peerPort="2905"
                serverName="MSC01_SERVER" aspName="MSC01_ASP" asName="MSC01_AS"
                routingContext="100" aspid="2" remoteSpc="2" remoteSsn="146"
                routeDpc="2" started="true"/>
            </associations>
            """);

        assertThrows(IllegalArgumentException.class,
                () -> EirConfig.load("EIR", project.toFile(), "sctp"));
    }

    private Path prepareProject() throws IOException {
        Path project = tempDir.resolve("project");
        Path source = Path.of("config", "initial", "EIR");
        Path target = project.resolve("config").resolve("initial").resolve("EIR");
        Files.createDirectories(target);
        try (Stream<Path> files = Files.list(source)) {
            files.filter(Files::isRegularFile).forEach(path -> {
                try { Files.copy(path, target.resolve(path.getFileName()), StandardCopyOption.REPLACE_EXISTING); }
                catch (IOException e) { throw new RuntimeException(e); }
            });
        }
        return project;
    }

    private void writeAssociations(Path project, String xml) throws IOException {
        Files.writeString(project.resolve("config/initial/EIR/EIR-associations.xml"), xml);
    }
}
