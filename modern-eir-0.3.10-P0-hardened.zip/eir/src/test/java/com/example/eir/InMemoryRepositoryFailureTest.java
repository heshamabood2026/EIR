package com.example.eir;

import com.example.eir.domain.EquipmentDecision;
import com.example.eir.domain.EirEquipmentStatus;
import com.example.eir.repository.InMemoryEquipmentRepository;
import com.example.eir.service.EquipmentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests in-memory repository failure behavior and EquipmentService fail-closed policy.
 *
 * STEP 6: In-Memory Database for Equipment Identity (IMEI + Status)
 *
 * Requirement: Wrap SQL exceptions in EquipmentRepositoryException;
 *              let EquipmentService apply fail-closed or MAP-error policy.
 *
 * This test verifies:
 * 1. Repository throws EquipmentRepositoryException on simulated failure
 * 2. EquipmentService catches exception and returns databaseUnavailable() decision
 * 3. Fail-closed behavior: unknown equipment treated as UNKNOWN status (safe default)
 * 4. EirMapListener receives decision and applies MAP protocol policy
 */
class InMemoryRepositoryFailureTest {
    private InMemoryEquipmentRepository repository;
    private EquipmentService service;

    @BeforeEach
    void setUp() {
        repository = InMemoryEquipmentRepository.demo();
        service = new EquipmentService(repository);
    }

    /**
     * Test 1: Normal operation - repository returns equipment without exception
     */
    @Test
    void testNormalOperation_Whitelisted() {
        EquipmentDecision decision = service.checkImei("333333334444440");

        assertNotNull(decision, "Decision must not be null");
        assertEquals(EirEquipmentStatus.WHITELISTED, decision.status(), "Status must be WHITELISTED");
        assertEquals("EQUIPMENT_STATUS", decision.reason(), "Reason must be EQUIPMENT_STATUS");
        assertTrue(decision.approved(), "Decision should be approved");
        assertNotNull(decision.equipment(), "Equipment data must be present");
        assertEquals("InMemoryEquipmentRepository", decision.source(), "Source must be InMemoryEquipmentRepository");
    }

    /**
     * Test 2: Normal operation - repository returns equipment not found (null)
     * Result: UNKNOWN status (fail-closed safety - assume dangerous equipment)
     */
    @Test
    void testNormalOperation_NotFound() {
        EquipmentDecision decision = service.checkImei("999999999999999");

        assertNotNull(decision, "Decision must not be null");
        assertEquals(EirEquipmentStatus.UNKNOWN, decision.status(), "Status must be UNKNOWN");
        assertEquals("EQUIPMENT_NOT_FOUND", decision.reason(), "Reason must be EQUIPMENT_NOT_FOUND");
        assertFalse(decision.approved(), "Decision should not be approved");
        assertNull(decision.equipment(), "Equipment data must be null");
    }

    /**
     * Test 3: Repository failure - simulateFailure() throws EquipmentRepositoryException
     * EquipmentService catches exception and returns databaseUnavailable() (fail-closed)
     */
    @Test
    void testRepositoryFailure_DatabaseUnavailable() {
        repository.simulateFailure();
        EquipmentDecision decision = service.checkImei("333333334444440");

        assertNotNull(decision, "Decision must not be null");
        assertEquals(EirEquipmentStatus.UNKNOWN, decision.status(), "Status must be UNKNOWN (fail-closed)");
        assertEquals("DATABASE_UNAVAILABLE", decision.reason(), "Reason must be DATABASE_UNAVAILABLE");
        assertFalse(decision.approved(), "Decision should not be approved");
        assertNull(decision.equipment(), "Equipment data must be null");
        assertEquals("InMemoryEquipmentRepository", decision.source(), "Source must be InMemoryEquipmentRepository");
    }

    /**
     * Test 4: Failure recovery - clearFailure() restores normal operation
     */
    @Test
    void testFailureRecovery() {
        // Simulate failure
        repository.simulateFailure();
        EquipmentDecision failureDecision = service.checkImei("333333334444440");
        assertEquals("DATABASE_UNAVAILABLE", failureDecision.reason());

        // Recover from failure
        repository.clearFailure();
        EquipmentDecision recoveryDecision = service.checkImei("333333334444440");
        assertEquals("EQUIPMENT_STATUS", recoveryDecision.reason());
        assertEquals(EirEquipmentStatus.WHITELISTED, recoveryDecision.status());
        assertTrue(recoveryDecision.approved());
    }

    /**
     * Test 5: Blacklisted equipment even during normal operation
     */
    @Test
    void testBlacklist_NormalOperation() {
        EquipmentDecision decision = service.checkImei("333333334444442");

        assertNotNull(decision, "Decision must not be null");
        assertEquals(EirEquipmentStatus.BLACKLISTED, decision.status());
        assertEquals("EQUIPMENT_STATUS", decision.reason());
        assertFalse(decision.approved());
        assertNotNull(decision.equipment());
    }

    /**
     * Test 6: Invalid IMEI (validation layer, no repository access)
     * Fail-closed: invalid format always returns UNKNOWN without querying repository
     */
    @Test
    void testInvalidImei_NoRepositoryAccess() {
        EquipmentDecision decision = service.checkImei("invalid");

        assertNotNull(decision, "Decision must not be null");
        assertEquals(EirEquipmentStatus.UNKNOWN, decision.status());
        assertEquals("INVALID_IMEI", decision.reason());
        assertFalse(decision.approved());
        assertNull(decision.equipment());
        assertEquals("validation", decision.source());
    }

    /**
     * Test 7: Concurrent failure simulation doesn't affect other threads
     * InMemoryEquipmentRepository uses AtomicBoolean for thread-safe failure state
     */
    @Test
    void testFailureSimulation_ThreadSafe() throws InterruptedException {
        repository.simulateFailure();
        EquipmentDecision decision1 = service.checkImei("333333334444440");
        assertEquals("DATABASE_UNAVAILABLE", decision1.reason());

        repository.clearFailure();
        EquipmentDecision decision2 = service.checkImei("333333334444440");
        assertEquals("EQUIPMENT_STATUS", decision2.reason());
    }

    /**
     * Test 8: Multiple repositories can operate independently
     * Each repository has its own failure state
     */
    @Test
    void testMultipleRepositories_IndependentFailureStates() {
        InMemoryEquipmentRepository repo1 = InMemoryEquipmentRepository.demo();
        InMemoryEquipmentRepository repo2 = InMemoryEquipmentRepository.demo();
        EquipmentService service1 = new EquipmentService(repo1);
        EquipmentService service2 = new EquipmentService(repo2);

        // Repo1 fails, Repo2 normal
        repo1.simulateFailure();
        EquipmentDecision decision1 = service1.checkImei("333333334444440");
        EquipmentDecision decision2 = service2.checkImei("333333334444440");

        assertEquals("DATABASE_UNAVAILABLE", decision1.reason());
        assertEquals("EQUIPMENT_STATUS", decision2.reason());

        // Repo1 recovers
        repo1.clearFailure();
        EquipmentDecision recoveredDecision1 = service1.checkImei("333333334444440");
        assertEquals("EQUIPMENT_STATUS", recoveredDecision1.reason());
    }

    /**
     * Test 9: Failure state query for monitoring
     */
    @Test
    void testFailureStateQuery() {
        assertFalse(repository.isFailureSimulated(), "Should not be simulating failure initially");

        repository.simulateFailure();
        assertTrue(repository.isFailureSimulated(), "Should be simulating failure");

        repository.clearFailure();
        assertFalse(repository.isFailureSimulated(), "Should not be simulating failure after clear");
    }
}
