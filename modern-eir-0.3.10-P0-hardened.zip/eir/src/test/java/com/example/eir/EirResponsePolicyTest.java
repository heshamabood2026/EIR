package com.example.eir;

import com.example.eir.domain.EirEquipmentStatus;
import com.example.eir.domain.EirMapResponse;
import com.example.eir.domain.EirResponsePolicy;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class EirResponsePolicyTest {

    @Test
    void whitelistedIsAccepted() {
        assertEquals(
                EirMapResponse.WHITELISTED,
                EirResponsePolicy.responseFor(EirEquipmentStatus.WHITELISTED)
        );
    }

    @Test
    void blacklistedIsRejected() {
        assertEquals(
                EirMapResponse.BLACKLISTED,
                EirResponsePolicy.responseFor(EirEquipmentStatus.BLACKLISTED)
        );
    }

    @Test
    void greylistedIsRejected() {
        assertEquals(
                EirMapResponse.BLACKLISTED,
                EirResponsePolicy.responseFor(EirEquipmentStatus.GREYLISTED)
        );
    }

    @Test
    void unknownIsRejected() {
        assertEquals(
                EirMapResponse.BLACKLISTED,
                EirResponsePolicy.responseFor(EirEquipmentStatus.UNKNOWN)
        );
    }

    @Test
    void invalidImeiDecisionIsRejected() {
        assertEquals(
                EirMapResponse.BLACKLISTED,
                EirResponsePolicy.responseFor(
                        com.example.eir.domain.EquipmentDecision.invalidImei("bad-imei")
                )
        );
    }

    @Test
    void nullStatusFailsClosed() {
        assertEquals(
                EirMapResponse.BLACKLISTED,
                EirResponsePolicy.responseFor((EirEquipmentStatus) null)
        );
    }
}
