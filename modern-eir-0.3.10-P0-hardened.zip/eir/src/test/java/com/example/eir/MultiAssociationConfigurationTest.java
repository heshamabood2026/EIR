package com.example.eir;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Configuration-level tests for the EIR multi-association model.
 *
 * <p>These tests deliberately do not open sockets. They exercise the same
 * EirConfig loading and runtime XML generation used by EirServerMain, which
 * makes them deterministic unit/integration-boundary tests for the two
 * supported topologies:</p>
 *
 * <ul>
 *   <li>two transport associations terminating on different ports of the same MSC;</li>
 *   <li>one association to each of two different MSC point codes.</li>
 * </ul>
 */
class MultiAssociationConfigurationTest {

    @TempDir
    Path tempDir;

    @Test
    void supportsMultiplePortsToTheSameMsc() throws Exception {
        Path project = prepareProject();
        writeAssociations(project,
                """
                <?xml version="1.0" encoding="UTF-8"?>
                <associations>
                    <association name="MSC01_ASSOC_A" mode="server"
                        localAddress="127.0.0.1" localPort="2906"
                        peerAddress="10.20.0.10" peerPort="2905"
                        serverName="MSC01_SERVER_A" aspName="MSC01_ASP_A"
                        asName="MSC01_AS" routingContext="100" aspid="3"
                        remoteSpc="1" remoteSsn="8" routeDpc="1" started="true"/>
                    <association name="MSC01_ASSOC_B" mode="server"
                        localAddress="127.0.0.1" localPort="2907"
                        peerAddress="10.20.0.10" peerPort="2906"
                        serverName="MSC01_SERVER_B" aspName="MSC01_ASP_B"
                        asName="MSC01_AS" routingContext="100" aspid="4"
                        remoteSpc="1" remoteSsn="8" routeDpc="1" started="true"/>
                </associations>
                """);

        EirConfig cfg = load(project);

        assertEquals(2, cfg.associations.size());
        assertEquals(2906, cfg.associations.get(0).localPort());
        assertEquals(2907, cfg.associations.get(1).localPort());
        assertEquals("10.20.0.10", cfg.associations.get(0).peerAddress());
        assertEquals("10.20.0.10", cfg.associations.get(1).peerAddress());
        assertEquals(1, cfg.associations.get(0).remoteSpc());
        assertEquals(1, cfg.associations.get(1).remoteSpc());
        assertEquals("MSC01_AS", cfg.associations.get(0).asName());
        assertEquals("MSC01_AS", cfg.associations.get(1).asName());

        Path runtime = project.resolve("config/runtime/EIR");
        String m3ua = Files.readString(runtime.resolve("EIR-M3UA_m3ua1.xml"));
        String sccp = Files.readString(runtime.resolve("EIR-SCCP_sccprouter3.xml"));
        String resource = Files.readString(runtime.resolve("EIR-SCCP_sccpresource2.xml"));

        // Same MSC: two ASPs in one AS, one DPC route, one remote SPC entry.
        assertEquals(2, count(m3ua, "<aspFactory "));
        assertEquals(2, count(m3ua, "<asp name=\"MSC01_ASP_"));
        assertEquals(1, count(m3ua, "<as name=\"MSC01_AS\""));
        assertEquals(1, count(m3ua, "<route>"));
        assertEquals(1, count(sccp, "firstDpc=\"1\""));
        assertEquals(1, count(resource, "<value remoteSpc=\"1\" remoteSpcFlag="));
    }

    @Test
    void supportsSimultaneousConnectionsToDifferentMscNodes() throws Exception {
        Path project = prepareProject();
        writeAssociations(project,
                """
                <?xml version="1.0" encoding="UTF-8"?>
                <associations>
                    <association name="MSC01_ASSOC" mode="server"
                        localAddress="127.0.0.1" localPort="2906"
                        peerAddress="10.20.0.10" peerPort="2905"
                        serverName="MSC01_SERVER" aspName="MSC01_ASP"
                        asName="MSC01_AS" routingContext="100" aspid="3"
                        remoteSpc="1" remoteSsn="8" routeDpc="1" started="true"/>
                    <association name="MSC02_ASSOC" mode="server"
                        localAddress="127.0.0.1" localPort="2907"
                        peerAddress="10.20.0.20" peerPort="2905"
                        serverName="MSC02_SERVER" aspName="MSC02_ASP"
                        asName="MSC02_AS" routingContext="101" aspid="4"
                        remoteSpc="2" remoteSsn="8" routeDpc="2" started="true"/>
                </associations>
                """);

        EirConfig cfg = load(project);

        assertEquals(2, cfg.associations.size());
        assertEquals("MSC01_AS", cfg.associations.get(0).asName());
        assertEquals("MSC02_AS", cfg.associations.get(1).asName());
        assertEquals(1, cfg.associations.get(0).remoteSpc());
        assertEquals(2, cfg.associations.get(1).remoteSpc());
        assertEquals(1, cfg.associations.get(0).routeDpc());
        assertEquals(2, cfg.associations.get(1).routeDpc());

        Path runtime = project.resolve("config/runtime/EIR");
        String m3ua = Files.readString(runtime.resolve("EIR-M3UA_m3ua1.xml"));
        String sccp = Files.readString(runtime.resolve("EIR-SCCP_sccprouter3.xml"));
        String resource = Files.readString(runtime.resolve("EIR-SCCP_sccpresource2.xml"));

        // Different MSCs: separate ASP/AS pairs and separate DPC routes.
        assertEquals(2, count(m3ua, "<aspFactory "));
        assertEquals(2, count(m3ua, "<as name="));
        assertTrue(m3ua.contains("<as name=\"MSC01_AS\""));
        assertTrue(m3ua.contains("<as name=\"MSC02_AS\""));
        assertEquals(2, count(m3ua, "<route>"));
        assertTrue(m3ua.contains("key value=\"1:-1:-1\""));
        assertTrue(m3ua.contains("key value=\"2:-1:-1\""));
        assertEquals(1, count(sccp, "firstDpc=\"1\""));
        assertEquals(1, count(sccp, "firstDpc=\"2\""));
        assertEquals(1, count(resource, "<value remoteSpc=\"1\" remoteSpcFlag="));
        assertEquals(1, count(resource, "<value remoteSpc=\"2\" remoteSpcFlag="));
    }

    private Path prepareProject() throws IOException {
        Path project = tempDir.resolve("project");
        Path source = Path.of("config", "initial", "EIR");
        Path target = project.resolve("config").resolve("initial").resolve("EIR");
        Files.createDirectories(target);
        try (Stream<Path> files = Files.list(source)) {
            files.filter(Files::isRegularFile).forEach(path -> {
                try {
                    Files.copy(path, target.resolve(path.getFileName()), StandardCopyOption.REPLACE_EXISTING);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            });
        }
        return project;
    }

    private void writeAssociations(Path project, String xml) throws IOException {
        Path file = project.resolve("config/initial/EIR/EIR-associations.xml");
        Files.writeString(file, xml);
    }

    private EirConfig load(Path project) throws Exception {
        String oldUserDir = System.getProperty("user.dir");
        try {
            return EirConfig.load("EIR", project.toFile(), "tcp");
        } finally {
            System.setProperty("user.dir", oldUserDir);
        }
    }

    private static int count(String text, String token) {
        int count = 0;
        int index = 0;
        while ((index = text.indexOf(token, index)) >= 0) {
            count++;
            index += token.length();
        }
        return count;
    }
}
