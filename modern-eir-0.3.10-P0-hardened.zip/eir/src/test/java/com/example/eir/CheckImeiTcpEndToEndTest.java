package com.example.eir;

import com.example.eir.domain.EirEquipmentStatus;
import com.example.eir.repository.InMemoryEquipmentRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Real protocol-path integration test:
 * MSC simulator -> TCP transport -> M3UA -> SCCP -> TCAP -> MAP CheckIMEI
 * -> EIR repository -> MAP CheckIMEI response.
 *
 * The test is opt-in because it binds the configured integration ports 2905/2906.
 * Run with -DEIR_RUN_E2E=true.
 */
class CheckImeiTcpEndToEndTest {
    private EirStack eir;
    private MscSimulatorMain msc;
    private String originalUserDir;

    @BeforeEach
    void startStacks() throws Exception {
        org.junit.jupiter.api.Assumptions.assumeTrue(
                Boolean.getBoolean("EIR_RUN_E2E"),
                "TCP SS7 E2E test is opt-in: run with -DEIR_RUN_E2E=true");

        originalUserDir = System.getProperty("user.dir");
        java.io.File projectRoot = new java.io.File(originalUserDir).getCanonicalFile();
        EirConfig eirCfg = EirConfig.load("EIR", projectRoot, "tcp");
        InMemoryEquipmentRepository repo = new InMemoryEquipmentRepository();
        repo.allow("333333334444440");
        repo.blacklist("333333334444442");
        repo.greylist("333333334444443");

        eir = new EirStack(eirCfg, repo);
        eir.start(false); // no DB or management server in protocol integration test

        EirConfig mscCfg = EirConfig.load("MSC", projectRoot, "tcp");
        msc = new MscSimulatorMain(mscCfg);
        msc.start();
        msc.m3ua.startAsp(mscCfg.aspName);

        assertTrue(msc.associationUp.await(15, TimeUnit.SECONDS),
                "MSC association did not reach communication-up");
        msc.awaitApplicationServerActive(15, TimeUnit.SECONDS);
    }

    @AfterEach
    void stopStacks() {
        if (msc != null) {
            msc.stop();
        }
        if (eir != null) {
            eir.stop();
        }
        if (originalUserDir != null) {
            System.setProperty("user.dir", originalUserDir);
        }
    }

    @Test
    void checkImeiRoundTripMapsEquipmentPolicy() throws Exception {
        assertEquals("whiteListed", msc.sendAndAwaitResponse(
                "333333334444440", 10, TimeUnit.SECONDS));
        assertEquals("blackListed", msc.sendAndAwaitResponse(
                "333333334444442", 10, TimeUnit.SECONDS));
        assertEquals("blackListed", msc.sendAndAwaitResponse(
                "333333334444443", 10, TimeUnit.SECONDS));
        assertEquals("blackListed", msc.sendAndAwaitResponse(
                "333333334444444", 10, TimeUnit.SECONDS));
    }
}
