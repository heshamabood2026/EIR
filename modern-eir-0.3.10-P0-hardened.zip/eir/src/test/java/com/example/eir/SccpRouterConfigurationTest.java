package com.example.eir;

import org.junit.jupiter.api.Test;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SccpRouterConfigurationTest {

    @Test
    void sccpSapUsesPointCodeRoutingWithoutAnUnmatchedGtConstraint() throws Exception {
        assertRouter("MSC", "opc=\"1\"", "firstDpc=\"2\"");
        assertRouter("EIR", "opc=\"2\"", "firstDpc=\"1\"");
    }

    private static void assertRouter(String role, String expectedOpc, String expectedDpc)
            throws Exception {
        Path router = Path.of("config", "initial", role, role + "-SCCP_sccprouter3.xml");
        String xml = Files.readString(router);

        assertTrue(xml.contains(expectedOpc), () -> role + " must expose its local point code");
        assertTrue(xml.contains(expectedDpc), () -> role + " must route to its peer point code");
        assertFalse(xml.contains("localGtDigits="),
                () -> role + " must not require a GT match in this DPC+SSN lab topology");
    }
}
