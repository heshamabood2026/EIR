package com.example.eir;

import com.example.eir.domain.EquipmentDecision;
import com.example.eir.domain.EirEquipmentStatus;
import com.example.eir.domain.EirMapResponse;
import com.example.eir.domain.EirResponsePolicy;
import com.example.eir.exception.EquipmentRepositoryException;
import com.example.eir.repository.EquipmentRepository;
import com.example.eir.service.EquipmentService;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EquipmentDatabaseOutagePolicyTest {

    @Test
    void databaseOutageBecomesUnknownAndFailsClosed() {
        EquipmentRepository failingRepository = imei -> {
            throw new EquipmentRepositoryException(
                    "database unavailable",
                    new RuntimeException("connection refused")
            );
        };

        EquipmentDecision result =
                new EquipmentService(failingRepository)
                        .checkImei("490154203237518");

        assertEquals(EirEquipmentStatus.UNKNOWN, result.status());
        assertEquals("DATABASE_UNAVAILABLE", result.reason());
        assertFalse(result.approved());
        assertEquals(
                EirMapResponse.BLACKLISTED,
                EirResponsePolicy.responseFor(result)
        );
    }
}
