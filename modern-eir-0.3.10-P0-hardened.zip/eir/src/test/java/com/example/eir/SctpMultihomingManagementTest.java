package com.example.eir;

import org.junit.jupiter.api.Test;
import org.restcomm.protocols.ss7.transport.Association;
import org.restcomm.protocols.ss7.transport.RestCommSctpManagement;
import org.restcomm.protocols.ss7.transport.Management;

import static org.junit.jupiter.api.Assertions.*;

class SctpMultihomingManagementTest {
    @Test
    void createsSingleLogicalAssociationForMultihomedClient() throws Exception {
        Management management = new RestCommSctpManagement("SCTP-TEST");
        management.start();
        try {
            Association association = management.addAssociation(
                    "127.0.0.1", 2905,
                    "127.0.0.2", 2905,
                    "127.0.0.3", 2905,
                    "127.0.0.4", 2905,
                    "MSC01_ASSOC");
            assertNotNull(association);
            assertEquals(1, management.getAssociations().size());
            assertSame(association, management.getAssociation("MSC01_ASSOC"));
        } finally {
            management.stop();
        }
    }
}
