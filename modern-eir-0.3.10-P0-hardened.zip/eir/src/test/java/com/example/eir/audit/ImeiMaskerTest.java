package com.example.eir.audit;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for IMEI masking in different modes.
 */
class ImeiMaskerTest {
    
    @Test
    void testMaskMode_None() {
        ImeiMasker masker = new ImeiMasker("NONE");
        assertEquals("333333334444440", masker.mask("333333334444440"));
    }
    
    @Test
    void testMaskMode_Partial() {
        ImeiMasker masker = new ImeiMasker("PARTIAL");
        String masked = masker.mask("333333334444440");
        
        assertTrue(masked.startsWith("*"));
        assertTrue(masked.endsWith("4440"));
        assertEquals(15, masked.length());
    }
    
    @Test
    void testMaskMode_Full() {
        ImeiMasker masker = new ImeiMasker("FULL");
        assertEquals("****-MASKED-****", masker.mask("333333334444440"));
    }
    
    @Test
    void testMaskMode_InvalidDefault() {
        ImeiMasker masker = new ImeiMasker("INVALID");
        String masked = masker.mask("333333334444440");
        assertTrue(masked.startsWith("*"));
    }
    
    @Test
    void testMask_NullImei() {
        ImeiMasker masker = new ImeiMasker("PARTIAL");
        assertEquals("INVALID", masker.mask(null));
    }
    
    @Test
    void testMask_ShortImei() {
        ImeiMasker masker = new ImeiMasker("PARTIAL");
        String masked = masker.mask("123");
        assertEquals("***", masked);
    }
}
