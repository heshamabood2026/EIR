package com.example.eir.metrics;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for equipment metrics collection.
 */
class EquipmentMetricsTest {
    
    private EquipmentMetrics metrics;
    
    @BeforeEach
    void setUp() {
        metrics = new EquipmentMetrics();
    }
    
    @Test
    void testRecordCheck_Whitelisted() {
        metrics.recordCheck("WHITELISTED", 5);
        
        Map<String, Object> m = metrics.toMap();
        assertEquals(1L, m.get("totalRequests"));
        assertEquals(1L, m.get("whitelisted"));
        assertEquals(0L, m.get("blacklisted"));
    }
    
    @Test
    void testRecordCheck_MultpleStatuses() {
        metrics.recordCheck("WHITELISTED", 2);
        metrics.recordCheck("BLACKLISTED", 3);
        metrics.recordCheck("GREYLISTED", 4);
        metrics.recordCheck("UNKNOWN", 5);
        
        Map<String, Object> m = metrics.toMap();
        assertEquals(4L, m.get("totalRequests"));
        assertEquals(1L, m.get("whitelisted"));
        assertEquals(1L, m.get("blacklisted"));
        assertEquals(1L, m.get("greylisted"));
        assertEquals(1L, m.get("unknown"));
    }
    
    @Test
    void testLatencyTracking() {
        metrics.recordCheck("WHITELISTED", 5);
        metrics.recordCheck("WHITELISTED", 10);
        metrics.recordCheck("WHITELISTED", 15);
        
        Map<String, Object> m = metrics.toMap();
        assertEquals(5L, m.get("minLatencyMs"));
        assertEquals(15L, m.get("maxLatencyMs"));
        assertEquals("10.00", m.get("avgLatencyMs"));
    }
    
    @Test
    void testDatabaseError() {
        metrics.recordCheck("WHITELISTED", 2);
        metrics.recordDatabaseError(100);
        
        Map<String, Object> m = metrics.toMap();
        assertEquals(2L, m.get("totalRequests"));
        assertEquals(1L, m.get("databaseErrors"));
    }
    
    @Test
    void testPoolUsage() {
        metrics.updatePoolUsage(7, 10);
        
        Map<String, Object> m = metrics.toMap();
        assertEquals(7L, m.get("poolUsed"));
        assertEquals(10L, m.get("poolMax"));
        assertEquals("70.0", m.get("poolSaturation%"));
    }
    
    @Test
    void testConcurrentRecording() throws InterruptedException {
        Thread t1 = new Thread(() -> {
            for (int i = 0; i < 100; i++) {
                metrics.recordCheck("WHITELISTED", 1);
            }
        });
        
        Thread t2 = new Thread(() -> {
            for (int i = 0; i < 100; i++) {
                metrics.recordCheck("BLACKLISTED", 2);
            }
        });
        
        t1.start();
        t2.start();
        t1.join();
        t2.join();
        
        Map<String, Object> m = metrics.toMap();
        assertEquals(200L, m.get("totalRequests"));
        assertEquals(100L, m.get("whitelisted"));
        assertEquals(100L, m.get("blacklisted"));
    }
}
