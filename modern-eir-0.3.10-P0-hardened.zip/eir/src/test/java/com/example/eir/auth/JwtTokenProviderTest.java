package com.example.eir.auth;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for JWT token generation, validation, and revocation.
 */
class JwtTokenProviderTest {
    
    private JwtTokenProvider provider;
    private User testUser;
    
    @BeforeEach
    void setUp() {
        provider = new JwtTokenProvider("test-secret-key-32-chars-minimum", 60);
        testUser = User.create("testuser", "hashedpassword", Role.USER);
    }
    
    @Test
    void testGenerateToken() {
        String token = provider.generateToken(testUser);
        
        assertNotNull(token);
        assertTrue(token.contains("."));
        String[] parts = token.split("\\.");
        assertEquals(3, parts.length);
    }
    
    @Test
    void testValidateToken_Valid() {
        String token = provider.generateToken(testUser);
        String username = provider.validateToken(token);
        
        assertEquals("testuser", username);
        assertEquals(Role.USER, provider.extractRole(token));
    }
    
    @Test
    void testTamperedTokenIsRejected() {
        String token = provider.generateToken(testUser);
        String[] parts = token.split("\\.");
        String tamperedPayload = parts[1] + "x";
        String tampered = parts[0] + "." + tamperedPayload + "." + parts[2];
        assertNull(provider.validateToken(tampered));
        assertNull(provider.extractRole(tampered));
    }

    @Test
    void testValidateToken_Invalid() {
        String username = provider.validateToken("invalid.token");
        assertNull(username);
    }
    
    @Test
    void testExtractRole() {
        String token = provider.generateToken(testUser);
        Role role = provider.extractRole(token);
        
        assertEquals(Role.USER, role);
    }
    
    @Test
    void testRevokeToken() {
        String token = provider.generateToken(testUser);
        assertNotNull(provider.validateToken(token));
        
        provider.revokeToken(token);
        assertNull(provider.validateToken(token));
    }
}
