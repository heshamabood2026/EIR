# Build notes — Modern EIR 0.3.9

## Fix for 0.3.8 SCTP multihoming compilation failure

The EIR code correctly called the 9-argument SCTP multihoming overload, but the shared RestComm transport `Management` interface exposed only the legacy 5-argument method. This caused `EirStack.java` and `MscSimulatorMain.java` to fail compilation when the variable was typed as `Management`.

The RestComm Java-SCTP fork now exposes the multihoming overload directly in `Management`:

- primary local address + port
- secondary local address + same port
- primary peer address + port
- secondary peer address + same port
- association name

The overload is a Java `default` method for compatibility with other `Management` implementations. The RestComm SCTP implementation overrides it and creates one logical SCTP association. The TCP implementation therefore remains source-compatible and unchanged.

## Expected Windows result

On Windows, `mvn clean compile -U` should no longer report the `Management.addAssociation(...)` argument-count error.

A live command such as `mvn exec:java ... -Dexec.args="sctp"` may still fail with `SCTP not supported on this platform`; that is a platform/JDK SCTP provider limitation, not a compilation or multihoming API problem.
